---
title: CkEthMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1401](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1401)

#### Properties

##### add\_ckerc20\_token

> **add\_ckerc20\_token**: `ActorMethod`\<\[[`AddCkErc20Token`](#addckerc20token)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1406](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1406)

Add a ckERC-20 token to be supported by the minter.
This call is restricted to the orchestrator ID.

##### decode\_ledger\_memo

> **decode\_ledger\_memo**: `ActorMethod`\<\[[`DecodeLedgerMemoArgs`](#decodeledgermemoargs)\], [`DecodeLedgerMemoResult`](#decodeledgermemoresult)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1410](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1410)

Decode ledger memos produced by the minter when minting (deposits) or burning (withdrawals).

##### deposit\_erc20

> **deposit\_erc20**: `ActorMethod`\<\[[`DepositErc20Arg`](#depositerc20arg)\], \{ `Ok`: [`DepositErc20Response`](#depositerc20response); \} \| \{ `Err`: [`DepositErc20Error`](#depositerc20error); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1421)

Derive and register the ckERC20 deposit address for the caller.
The account is derived from the caller's principal and the subaccount in the argument.
Returns the EIP-55 checksummed deposit address together with `valid_until`, the timestamp
(nanoseconds since the Unix epoch) until which a deposit to it is guaranteed to be noticed,
and the minimum balance of the requested token the address must hold to be noticed.

##### deposit\_eth

> **deposit\_eth**: `ActorMethod`\<\[[`DepositEthArg`](#depositetharg)\], \{ `Ok`: [`DepositEthResponse`](#depositethresponse); \} \| \{ `Err`: [`DepositEthError`](#depositetherror); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1434](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1434)

Derive and register the ETH deposit address for the caller.
The account is derived from the caller's principal and the subaccount in the argument.
Returns the EIP-55 checksummed deposit address, which is the same address as the one
derived by deposit_erc20 for the same account, whatever the ERC-20 token, together with
`valid_until`, the timestamp (nanoseconds since the Unix epoch) until which a deposit to
it is guaranteed to be noticed, and the minimum balance in wei the address must hold to
be noticed.

##### eip\_1559\_transaction\_price

> **eip\_1559\_transaction\_price**: `ActorMethod`\<\[\[\] \| \[[`Eip1559TransactionPriceArg`](#eip1559transactionpricearg)\]\], [`Eip1559TransactionPrice`](#eip1559transactionprice)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1441](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1441)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH.

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1450](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1450)

Retrieve the status of the minter canister.

This is a debug endpoint where backwards-compatibility is not guaranteed.

##### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], \{ `events`: [`Event`](#event)[]; `total_event_count`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1456)

Retrieve events from the minter's audit log.
The endpoint can return fewer events than requested to bound the response size.
IMPORTANT: this endpoint is meant as a debugging tool and is not guaranteed to be backwards-compatible.

##### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](#minterinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1463](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1463)

Returns internal minter parameters

##### is\_address\_blocked

> **is\_address\_blocked**: `ActorMethod`\<\[`string`\], `boolean`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1467](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1467)

Check if an address is blocked by the minter.

##### minter\_address

> **minter\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1475](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1475)

Retrieve the Ethereum address controlled by the minter:
* Deposits will be transferred from the helper smart contract to this address
* Withdrawals will originate from this address
IMPORTANT: Do NOT send ETH to this address directly. Use the helper smart contract instead so that the minter
knows to which IC principal the funds should be deposited.

##### retrieve\_eth\_status

> **retrieve\_eth\_status**: `ActorMethod`\<\[`bigint`\], [`RetrieveEthStatus`](#retrieveethstatus)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1479](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1479)

Retrieve the status of a Eth withdrawal request.

##### smart\_contract\_address

> **smart\_contract\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1488](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1488)

Address of the helper smart contract.
Returns "N/A" if the helper smart contract is not set.
IMPORTANT:
* Use this address to send ETH to the minter to convert it to ckETH.
* In case the smart contract needs to be updated the returned address will change!
Always check the address before making a transfer.

##### withdraw\_erc20

> **withdraw\_erc20**: `ActorMethod`\<\[[`WithdrawErc20Arg`](#withdrawerc20arg)\], \{ `Ok`: [`RetrieveErc20Request`](#retrieveerc20request); \} \| \{ `Err`: [`WithdrawErc20Error`](#withdrawerc20error); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1492](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1492)

Withdraw the specified amount of ERC-20 tokens to the given Ethereum address.

##### withdraw\_eth

> **withdraw\_eth**: `ActorMethod`\<\[[`WithdrawalArg`](#withdrawalarg)\], \{ `Ok`: [`RetrieveEthRequest`](#retrieveethrequest); \} \| \{ `Err`: [`WithdrawalError`](#withdrawalerror); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1500)

Withdraw the specified amount in Wei to the given Ethereum address.
IMPORTANT: The current gas limit is set to 21,000 for a transaction so withdrawals to smart contract addresses will likely fail.

##### withdrawal\_status

> **withdrawal\_status**: `ActorMethod`\<\[[`WithdrawalSearchParameter`](#withdrawalsearchparameter)\], [`WithdrawalDetail`](#withdrawaldetail)[]\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1507](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1507)

Return details of all withdrawals matching the given search parameter.

***

### Account

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L16)

ICRC-1 account type.

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L17)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L18)

***

### AddCkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L20)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L32)

The Ethereum address of the ERC-20 smart contract.

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L28)

Ethereum chain ID.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L24)

The ledger ID for that ckERC20 token.

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L36)

The ckERC20 token symbol on the ledger.

***

### AuthorizedSweepItem

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L48)

One deposit a sweep moves: the address the funds sit at, the account they are
credited to, the attestation binding the two, and the delegation letting the
sweeper's code run there.

#### Properties

##### attestation

> **attestation**: [`TransactionSignature`](#transactionsignature)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L54)

The attestation signed by the deposit address itself.

##### authorization

> **authorization**: \[\] \| \[[`SignedAuthorization`](#signedauthorization)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L60)

The delegation installed on the way, absent if the address is already
delegated.

##### deposit

> **deposit**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L55)

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L49)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L50)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L128)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L134)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L137)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L129)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L131)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L138)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L136)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L132)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L139)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L135)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L130)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L133)

***

### CkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L145)

#### Properties

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L148)

##### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L146)

##### ledger\_canister\_id

> **ledger\_canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L147)

***

### DecodeLedgerMemoArgs

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L150)

#### Properties

##### encoded\_memo

> **encoded\_memo**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L158)

The encoded memo from a minter transaction on the ledger

##### memo\_type

> **memo\_type**: [`MemoType`](#memotype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L154)

The encoded memo type

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L194)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L204)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L198)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L197)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L195)

##### log\_memory\_limit

> **log\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L201)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L200)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L203)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L199)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L202)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L196)

***

### DepositErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L209)

Argument for the deposit_erc20 endpoint.

#### Properties

##### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L216)

The Ethereum ERC-20 contract address of the token to deposit (e.g. USDC).
Traps if it cannot be parsed as an Ethereum address. Must be a ckERC20
token supported by the minter.

##### mode

> **mode**: [`DepositMode`](#depositmode)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L210)

***

### DepositErc20Response

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L246)

Response of the deposit_erc20 endpoint.

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L266)

The Ethereum deposit address derived for the caller, the same one whatever the asset.

##### minimum\_deposit\_amount

> **minimum\_deposit\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L262)

Minimum balance, in the token's own units, that the deposit address must hold for the
balance scan to detect it. The scan reads the address' whole balance for the token, so
several smaller transfers count together; the funds stay undetected only while their
total is below this.

A supported token with no configured minimum reports 2^256 - 1, which no real balance can
reach: a deposit of that token would never be detected. Frontends should treat such a value
as "deposits unavailable for this token" and warn the user, rather than display it as an
amount to send.

##### status

> **status**: [`DepositStatus`](#depositstatus)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L250)

Where the deposit stands in the detect-and-sweep pipeline.

***

### DepositEthArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L271)

Argument for the deposit_eth endpoint.

#### Properties

##### mode

> **mode**: [`DepositMode`](#depositmode)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L272)

***

### DepositEthResponse

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L297)

Response of the deposit_eth endpoint.

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L312)

The Ethereum deposit address derived for the caller. It is the same address as the one
derived by the deposit_erc20 endpoint for the same account, whatever the ERC-20 token.

##### minimum\_deposit\_amount

> **minimum\_deposit\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L307)

Minimum balance, in wei, that the deposit address must hold for the balance scan to
detect it. The scan reads the address' whole ETH balance, so several smaller transfers
count together; the funds stay undetected only while their total is below this.

##### status

> **status**: [`DepositEthStatus`](#depositethstatus)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L301)

Where the deposit stands in the detect-and-sweep pipeline.

***

### DetectedDeposit

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L389)

A funded token detected at a deposit address and queued for sweeping.

#### Properties

##### detected\_at\_block

> **detected\_at\_block**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L393)

The Ethereum block at which the balance was detected.

##### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L397)

The ERC-20 token contract whose balance was found.

##### scanned\_balance

> **scanned\_balance**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L401)

The balance scanned for `erc20_contract_address`; may change before the sweep.

***

### DetectedEthDeposit

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L406)

A funded ETH balance detected at a deposit address and queued for sweeping.

#### Properties

##### detected\_at\_block

> **detected\_at\_block**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L410)

The Ethereum block at which the balance was detected.

##### scanned\_balance

> **scanned\_balance**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L414)

The ETH balance scanned, in wei; may change before the sweep.

***

### Eip1559TransactionPrice

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L421)

Estimate price of an EIP-1559 transaction
when converting ckETH to ETH or ckERC20 to ERC20, see
https://eips.ethereum.org/EIPS/eip-1559

#### Properties

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L445)

Maximum amount of gas transaction is authorized to consume.

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L431)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L426)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L436)

Maximum amount of Wei that can be charged for the transaction,
computed as `max_fee_per_gas * gas_limit`

##### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L441)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### Eip1559TransactionPriceArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L452)

Argument to Eip1559TransactionPrice.
When specified, it is to lookup transaction price for a ckERC20 token withdrawal.
When not specified (null), it is for ETH withdrawal.

#### Properties

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L456)

The ledger ID for that ckERC20 token.

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1397)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1399](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1399)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1398)

***

### EthTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L458)

#### Properties

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L459)

***

### Event

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L474)

#### Properties

##### payload

> **payload**: \{ `SkippedBlock`: \{ `block_number`: `bigint`; `contract_address`: \[\] \| \[`string`\]; \}; \} \| \{ `AcceptedErc20Deposit`: \{ `block_number`: `bigint`; `erc20_contract_address`: `string`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `SignedTransaction`: \{ `raw_transaction`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \} \| \{ `AddedCkErc20Token`: \{ `address`: `string`; `chain_id`: `bigint`; `ckerc20_ledger_id`: `Principal`; `ckerc20_token_symbol`: `string`; \}; \} \| \{ `SyncedDepositWithSubaccountToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `QuarantinedDeposit`: \{ `event_source`: [`EventSource`](#eventsource); \}; \} \| \{ `SyncedToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedDeposit`: \{ `block_number`: `bigint`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `ReplacedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `QuarantinedReimbursement`: \{ `index`: [`ReimbursementIndex`](#reimbursementindex); \}; \} \| \{ `RegisteredDepositAddresses`: \{ `capacity`: `bigint`; `registrations`: `object`[]; `scan_window_nanos`: `bigint`; \}; \} \| \{ `FinalizedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); \}; \} \| \{ `MintedCkEth`: \{ `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `ReimbursedEthWithdrawal`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `FailedErc20WithdrawalRequest`: \{ `reimbursed_amount`: `bigint`; `to`: `Principal`; `to_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `AcceptedSweeperFundingRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `ReimbursedErc20Withdrawal`: \{ `burn_in_block`: `bigint`; `ledger_id`: `Principal`; `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `ReplacedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction`: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction); \}; \} \| \{ `MintedCkErc20`: \{ `ckerc20_token_symbol`: `string`; `erc20_contract_address`: `string`; `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `AttestedDepositAddress`: \{ `attestation`: [`TransactionSignature`](#transactionsignature); `chain_id`: `bigint`; `deposit_helper`: `string`; `owner`: `Principal`; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}; \} \| \{ `CreatedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction`: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction); \}; \} \| \{ `CreatedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `InvalidDeposit`: \{ `event_source`: [`EventSource`](#eventsource); `reason`: `string`; \}; \} \| \{ `SyncedErc20ToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedErc20WithdrawalRequest`: \{ `ckerc20_ledger_burn_index`: `bigint`; `ckerc20_ledger_id`: `Principal`; `cketh_ledger_burn_index`: `bigint`; `created_at`: `bigint`; `destination`: `string`; `erc20_contract_address`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `max_transaction_fee`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `AcceptedSweepRequest`: \{ `asset`: [`Asset`](#asset); `created_at`: `bigint`; `destination`: `string`; `items`: [`AuthorizedSweepItem`](#authorizedsweepitem)[]; `max_transaction_fee`: `bigint`; `sweep_id`: `bigint`; \}; \} \| \{ `AcceptedEthWithdrawalRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `AutomaticDepositReceived`: \{ `address`: `string`; `asset`: [`Asset`](#asset); `last_scanned_block`: `bigint`; `owner`: `Principal`; `scan_count`: `bigint`; `scanned_balance`: `bigint`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; \}; \} \| \{ `FinalizedTransaction`: \{ `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); `withdrawal_id`: `bigint`; \}; \} \| \{ `AuthorizedDepositAddress`: \{ `authorization`: [`SignedAuthorization`](#signedauthorization); `owner`: `Principal`; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}; \} \| \{ `SignedSweeperTransaction`: \{ `raw_transaction`: `string`; `sweep_id`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L476)

###### Type Declaration

\{ `SkippedBlock`: \{ `block_number`: `bigint`; `contract_address`: \[\] \| \[`string`\]; \}; \}

###### SkippedBlock

> **SkippedBlock**: `object`

###### SkippedBlock.block\_number

> **block\_number**: `bigint`

###### SkippedBlock.contract\_address

> **contract\_address**: \[\] \| \[`string`\]

\{ `AcceptedErc20Deposit`: \{ `block_number`: `bigint`; `erc20_contract_address`: `string`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \}

###### AcceptedErc20Deposit

> **AcceptedErc20Deposit**: `object`

###### AcceptedErc20Deposit.block\_number

> **block\_number**: `bigint`

###### AcceptedErc20Deposit.erc20\_contract\_address

> **erc20\_contract\_address**: `string`

###### AcceptedErc20Deposit.from\_address

> **from\_address**: `string`

###### AcceptedErc20Deposit.log\_index

> **log\_index**: `bigint`

###### AcceptedErc20Deposit.principal

> **principal**: `Principal`

###### AcceptedErc20Deposit.subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

###### AcceptedErc20Deposit.transaction\_hash

> **transaction\_hash**: `string`

###### AcceptedErc20Deposit.value

> **value**: `bigint`

\{ `SignedTransaction`: \{ `raw_transaction`: `string`; `withdrawal_id`: `bigint`; \}; \}

###### SignedTransaction

> **SignedTransaction**: `object`

###### SignedTransaction.raw\_transaction

> **raw\_transaction**: `string`

###### SignedTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `Upgrade`: [`UpgradeArg`](#upgradearg); \}

###### Upgrade

> **Upgrade**: [`UpgradeArg`](#upgradearg)

\{ `Init`: [`InitArg`](#initarg); \}

###### Init

> **Init**: [`InitArg`](#initarg)

\{ `AddedCkErc20Token`: \{ `address`: `string`; `chain_id`: `bigint`; `ckerc20_ledger_id`: `Principal`; `ckerc20_token_symbol`: `string`; \}; \}

###### AddedCkErc20Token

> **AddedCkErc20Token**: `object`

###### AddedCkErc20Token.address

> **address**: `string`

###### AddedCkErc20Token.chain\_id

> **chain\_id**: `bigint`

###### AddedCkErc20Token.ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

###### AddedCkErc20Token.ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

\{ `SyncedDepositWithSubaccountToBlock`: \{ `block_number`: `bigint`; \}; \}

###### SyncedDepositWithSubaccountToBlock

> **SyncedDepositWithSubaccountToBlock**: `object`

###### SyncedDepositWithSubaccountToBlock.block\_number

> **block\_number**: `bigint`

\{ `QuarantinedDeposit`: \{ `event_source`: [`EventSource`](#eventsource); \}; \}

###### QuarantinedDeposit

> **QuarantinedDeposit**: `object`

###### QuarantinedDeposit.event\_source

> **event\_source**: [`EventSource`](#eventsource)

\{ `SyncedToBlock`: \{ `block_number`: `bigint`; \}; \}

###### SyncedToBlock

> **SyncedToBlock**: `object`

###### SyncedToBlock.block\_number

> **block\_number**: `bigint`

\{ `AcceptedDeposit`: \{ `block_number`: `bigint`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \}

###### AcceptedDeposit

> **AcceptedDeposit**: `object`

###### AcceptedDeposit.block\_number

> **block\_number**: `bigint`

###### AcceptedDeposit.from\_address

> **from\_address**: `string`

###### AcceptedDeposit.log\_index

> **log\_index**: `bigint`

###### AcceptedDeposit.principal

> **principal**: `Principal`

###### AcceptedDeposit.subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

###### AcceptedDeposit.transaction\_hash

> **transaction\_hash**: `string`

###### AcceptedDeposit.value

> **value**: `bigint`

\{ `ReplacedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \}

###### ReplacedTransaction

> **ReplacedTransaction**: `object`

###### ReplacedTransaction.transaction

> **transaction**: [`UnsignedTransaction`](#unsignedtransaction)

###### ReplacedTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `QuarantinedReimbursement`: \{ `index`: [`ReimbursementIndex`](#reimbursementindex); \}; \}

###### QuarantinedReimbursement

> **QuarantinedReimbursement**: `object`

###### QuarantinedReimbursement.index

> **index**: [`ReimbursementIndex`](#reimbursementindex)

\{ `RegisteredDepositAddresses`: \{ `capacity`: `bigint`; `registrations`: `object`[]; `scan_window_nanos`: `bigint`; \}; \}

###### RegisteredDepositAddresses

> **RegisteredDepositAddresses**: `object`

###### RegisteredDepositAddresses.capacity

> **capacity**: `bigint`

###### RegisteredDepositAddresses.registrations

> **registrations**: `object`[]

###### RegisteredDepositAddresses.scan\_window\_nanos

> **scan\_window\_nanos**: `bigint`

\{ `FinalizedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); \}; \}

###### FinalizedSweeperTransaction

> **FinalizedSweeperTransaction**: `object`

###### FinalizedSweeperTransaction.sweep\_id

> **sweep\_id**: `bigint`

###### FinalizedSweeperTransaction.transaction\_receipt

> **transaction\_receipt**: [`TransactionReceipt`](#transactionreceipt)

\{ `MintedCkEth`: \{ `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \}

###### MintedCkEth

> **MintedCkEth**: `object`

###### MintedCkEth.event\_source

> **event\_source**: [`EventSource`](#eventsource)

###### MintedCkEth.mint\_block\_index

> **mint\_block\_index**: `bigint`

\{ `ReimbursedEthWithdrawal`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \}

###### ReimbursedEthWithdrawal

> **ReimbursedEthWithdrawal**: `object`

###### ReimbursedEthWithdrawal.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### ReimbursedEthWithdrawal.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

###### ReimbursedEthWithdrawal.transaction\_hash

> **transaction\_hash**: \[\] \| \[`string`\]

###### ReimbursedEthWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `FailedErc20WithdrawalRequest`: \{ `reimbursed_amount`: `bigint`; `to`: `Principal`; `to_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `withdrawal_id`: `bigint`; \}; \}

###### FailedErc20WithdrawalRequest

> **FailedErc20WithdrawalRequest**: `object`

###### FailedErc20WithdrawalRequest.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### FailedErc20WithdrawalRequest.to

> **to**: `Principal`

###### FailedErc20WithdrawalRequest.to\_subaccount

> **to\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

###### FailedErc20WithdrawalRequest.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `AcceptedSweeperFundingRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \}

###### AcceptedSweeperFundingRequest

> **AcceptedSweeperFundingRequest**: `object`

###### AcceptedSweeperFundingRequest.created\_at

> **created\_at**: \[\] \| \[`bigint`\]

###### AcceptedSweeperFundingRequest.destination

> **destination**: `string`

###### AcceptedSweeperFundingRequest.from

> **from**: `Principal`

###### AcceptedSweeperFundingRequest.from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

###### AcceptedSweeperFundingRequest.ledger\_burn\_index

> **ledger\_burn\_index**: `bigint`

###### AcceptedSweeperFundingRequest.withdrawal\_amount

> **withdrawal\_amount**: `bigint`

\{ `ReimbursedErc20Withdrawal`: \{ `burn_in_block`: `bigint`; `ledger_id`: `Principal`; `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \}

###### ReimbursedErc20Withdrawal

> **ReimbursedErc20Withdrawal**: `object`

###### ReimbursedErc20Withdrawal.burn\_in\_block

> **burn\_in\_block**: `bigint`

###### ReimbursedErc20Withdrawal.ledger\_id

> **ledger\_id**: `Principal`

###### ReimbursedErc20Withdrawal.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### ReimbursedErc20Withdrawal.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

###### ReimbursedErc20Withdrawal.transaction\_hash

> **transaction\_hash**: \[\] \| \[`string`\]

###### ReimbursedErc20Withdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `ReplacedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction`: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction); \}; \}

###### ReplacedSweeperTransaction

> **ReplacedSweeperTransaction**: `object`

###### ReplacedSweeperTransaction.sweep\_id

> **sweep\_id**: `bigint`

###### ReplacedSweeperTransaction.transaction

> **transaction**: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction)

\{ `MintedCkErc20`: \{ `ckerc20_token_symbol`: `string`; `erc20_contract_address`: `string`; `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \}

###### MintedCkErc20

> **MintedCkErc20**: `object`

###### MintedCkErc20.ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

###### MintedCkErc20.erc20\_contract\_address

> **erc20\_contract\_address**: `string`

###### MintedCkErc20.event\_source

> **event\_source**: [`EventSource`](#eventsource)

###### MintedCkErc20.mint\_block\_index

> **mint\_block\_index**: `bigint`

\{ `AttestedDepositAddress`: \{ `attestation`: [`TransactionSignature`](#transactionsignature); `chain_id`: `bigint`; `deposit_helper`: `string`; `owner`: `Principal`; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}; \}

###### AttestedDepositAddress

> **AttestedDepositAddress**: `object`

A ckERC20 deposit address attested to the account it credits. Recorded
on its own because signing costs a threshold-ECDSA signature: the
attestation outlives the sweep that needed it and every later one
reuses it.

###### AttestedDepositAddress.attestation

> **attestation**: [`TransactionSignature`](#transactionsignature)

The attestation signed by the deposit address itself.

###### AttestedDepositAddress.chain\_id

> **chain\_id**: `bigint`

###### AttestedDepositAddress.deposit\_helper

> **deposit\_helper**: `string`

The deposit helper the attestation names; it is only valid against
this deployment.

###### AttestedDepositAddress.owner

> **owner**: `Principal`

###### AttestedDepositAddress.subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

\{ `CreatedSweeperTransaction`: \{ `sweep_id`: `bigint`; `transaction`: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction); \}; \}

###### CreatedSweeperTransaction

> **CreatedSweeperTransaction**: `object`

###### CreatedSweeperTransaction.sweep\_id

> **sweep\_id**: `bigint`

###### CreatedSweeperTransaction.transaction

> **transaction**: [`UnsignedSweeperTransaction`](#unsignedsweepertransaction)

\{ `CreatedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \}

###### CreatedTransaction

> **CreatedTransaction**: `object`

###### CreatedTransaction.transaction

> **transaction**: [`UnsignedTransaction`](#unsignedtransaction)

###### CreatedTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `InvalidDeposit`: \{ `event_source`: [`EventSource`](#eventsource); `reason`: `string`; \}; \}

###### InvalidDeposit

> **InvalidDeposit**: `object`

###### InvalidDeposit.event\_source

> **event\_source**: [`EventSource`](#eventsource)

###### InvalidDeposit.reason

> **reason**: `string`

\{ `SyncedErc20ToBlock`: \{ `block_number`: `bigint`; \}; \}

###### SyncedErc20ToBlock

> **SyncedErc20ToBlock**: `object`

###### SyncedErc20ToBlock.block\_number

> **block\_number**: `bigint`

\{ `AcceptedErc20WithdrawalRequest`: \{ `ckerc20_ledger_burn_index`: `bigint`; `ckerc20_ledger_id`: `Principal`; `cketh_ledger_burn_index`: `bigint`; `created_at`: `bigint`; `destination`: `string`; `erc20_contract_address`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `max_transaction_fee`: `bigint`; `withdrawal_amount`: `bigint`; \}; \}

###### AcceptedErc20WithdrawalRequest

> **AcceptedErc20WithdrawalRequest**: `object`

###### AcceptedErc20WithdrawalRequest.ckerc20\_ledger\_burn\_index

> **ckerc20\_ledger\_burn\_index**: `bigint`

###### AcceptedErc20WithdrawalRequest.ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

###### AcceptedErc20WithdrawalRequest.cketh\_ledger\_burn\_index

> **cketh\_ledger\_burn\_index**: `bigint`

###### AcceptedErc20WithdrawalRequest.created\_at

> **created\_at**: `bigint`

###### AcceptedErc20WithdrawalRequest.destination

> **destination**: `string`

###### AcceptedErc20WithdrawalRequest.erc20\_contract\_address

> **erc20\_contract\_address**: `string`

###### AcceptedErc20WithdrawalRequest.from

> **from**: `Principal`

###### AcceptedErc20WithdrawalRequest.from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

###### AcceptedErc20WithdrawalRequest.max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

###### AcceptedErc20WithdrawalRequest.withdrawal\_amount

> **withdrawal\_amount**: `bigint`

\{ `AcceptedSweepRequest`: \{ `asset`: [`Asset`](#asset); `created_at`: `bigint`; `destination`: `string`; `items`: [`AuthorizedSweepItem`](#authorizedsweepitem)[]; `max_transaction_fee`: `bigint`; `sweep_id`: `bigint`; \}; \}

###### AcceptedSweepRequest

> **AcceptedSweepRequest**: `object`

###### AcceptedSweepRequest.asset

> **asset**: [`Asset`](#asset)

The single asset this sweep moves.

###### AcceptedSweepRequest.created\_at

> **created\_at**: `bigint`

###### AcceptedSweepRequest.destination

> **destination**: `string`

###### AcceptedSweepRequest.items

> **items**: [`AuthorizedSweepItem`](#authorizedsweepitem)[]

The deposits the sweep moves, one per account.

###### AcceptedSweepRequest.max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

###### AcceptedSweepRequest.sweep\_id

> **sweep\_id**: `bigint`

\{ `AcceptedEthWithdrawalRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \}

###### AcceptedEthWithdrawalRequest

> **AcceptedEthWithdrawalRequest**: `object`

###### AcceptedEthWithdrawalRequest.created\_at

> **created\_at**: \[\] \| \[`bigint`\]

###### AcceptedEthWithdrawalRequest.destination

> **destination**: `string`

###### AcceptedEthWithdrawalRequest.from

> **from**: `Principal`

###### AcceptedEthWithdrawalRequest.from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

###### AcceptedEthWithdrawalRequest.ledger\_burn\_index

> **ledger\_burn\_index**: `bigint`

###### AcceptedEthWithdrawalRequest.withdrawal\_amount

> **withdrawal\_amount**: `bigint`

\{ `AutomaticDepositReceived`: \{ `address`: `string`; `asset`: [`Asset`](#asset); `last_scanned_block`: `bigint`; `owner`: `Principal`; `scan_count`: `bigint`; `scanned_balance`: `bigint`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-2)\]; \}; \}

###### AutomaticDepositReceived

> **AutomaticDepositReceived**: `object`

###### AutomaticDepositReceived.address

> **address**: `string`

###### AutomaticDepositReceived.asset

> **asset**: [`Asset`](#asset)

###### AutomaticDepositReceived.last\_scanned\_block

> **last\_scanned\_block**: `bigint`

###### AutomaticDepositReceived.owner

> **owner**: `Principal`

###### AutomaticDepositReceived.scan\_count

> **scan\_count**: `bigint`

###### AutomaticDepositReceived.scanned\_balance

> **scanned\_balance**: `bigint`

###### AutomaticDepositReceived.subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

\{ `FinalizedTransaction`: \{ `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); `withdrawal_id`: `bigint`; \}; \}

###### FinalizedTransaction

> **FinalizedTransaction**: `object`

###### FinalizedTransaction.transaction\_receipt

> **transaction\_receipt**: [`TransactionReceipt`](#transactionreceipt)

###### FinalizedTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

\{ `AuthorizedDepositAddress`: \{ `authorization`: [`SignedAuthorization`](#signedauthorization); `owner`: `Principal`; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}; \}

###### AuthorizedDepositAddress

> **AuthorizedDepositAddress**: `object`

###### AuthorizedDepositAddress.authorization

> **authorization**: [`SignedAuthorization`](#signedauthorization)

The tuple the deposit address signed, delegating its code to the
sweeper contract. Its nonce is always zero: the delegation is
installed the first time the tuple is applied.

###### AuthorizedDepositAddress.owner

> **owner**: `Principal`

###### AuthorizedDepositAddress.subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

\{ `SignedSweeperTransaction`: \{ `raw_transaction`: `string`; `sweep_id`: `bigint`; \}; \}

###### SignedSweeperTransaction

> **SignedSweeperTransaction**: `object`

###### SignedSweeperTransaction.raw\_transaction

> **raw\_transaction**: `string`

###### SignedSweeperTransaction.sweep\_id

> **sweep\_id**: `bigint`

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L475)

***

### EventSource

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L721)

#### Properties

##### log\_index

> **log\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L723)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L722)

***

### GasFeeEstimate

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L725)

#### Properties

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:735](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L735)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L730)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:740](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L740)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L745)

The initialization parameters of the minter canister.

#### Properties

##### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L759)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

##### ethereum\_block\_height

> **ethereum\_block\_height**: [`BlockTag`](#blocktag)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L797)

Determine ethereum block height observed by minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:789](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L789)

Address of the helper smart contract.

##### ethereum\_network

> **ethereum\_network**: [`EthereumNetwork`](#ethereumnetwork)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L749)

The minter will interact with this Ethereum network.

##### ethereum\_sweeper\_contract\_address

> **ethereum\_sweeper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L773)

Address of the sweeper smart contract.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L769)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain. If not specified, uses the production or
staging EVM RPC canister based on the ethereum_network field.

##### last\_scraped\_block\_number

> **last\_scraped\_block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L754)

Block number to start scrapping from on the Ethereum network.
Scrapping the logs will resume at `last_scraped_block_number + 1` (inclusive).

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L785)

The principal of the ledger that handles ckETH transfers.
The default account of the ckETH minter must be configured as
the minting account of the ledger.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L793)

Minimum amount in Wei that can be withdrawn.

##### next\_sweeper\_transaction\_nonce

> **next\_sweeper\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L779)

Nonce of the next transaction to be sent from the dedicated sweeper address (its own nonce
sequence, kept separate from the main address' so a stuck sweep cannot delay a withdrawal).
Defaults to 0, which is correct for a sweeper address that has never sent a transaction.

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L763)

Nonce of the next transaction to be sent to the Ethereum network.

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L845)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L849)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L854)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L853)

##### log\_memory\_store\_size

> **log\_memory\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L847)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:851](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L851)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:850](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L850)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L846)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:848](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L848)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:852](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L852)

***

### MinterInfo

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L901)

#### Properties

##### cketh\_ledger\_id

> **cketh\_ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:955](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L955)

Canister ID of the ckETH ledger.

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L905)

Address of the ETH or ERC20 deposit with subaccount helper smart contract.

##### erc20\_balances

> **erc20\_balances**: \[\] \| \[`object`[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:973](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L973)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L927)

Address of the ERC20 helper smart contract

##### eth\_balance

> **eth\_balance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L910)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### eth\_helper\_contract\_address

> **eth\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L914)

Address of the ETH helper smart contract.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1001](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1001)

Determine ethereum block height observed by minter.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:923](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L923)

Canister ID of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:992](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L992)

Last scraped block number for logs of the deposit with subaccount helper contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L943)

Last scraped block number for logs of the ERC20 helper contract.

##### last\_eth\_scraped\_block\_number

> **last\_eth\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L964)

Last scraped block number for logs of the ETH helper contract.

##### last\_gas\_fee\_estimate

> **last\_gas\_fee\_estimate**: \[\] \| \[[`GasFeeEstimate`](#gasfeeestimate)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L951)

Last gas fee estimate.

##### last\_observed\_block\_number

> **last\_observed\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L918)

Last Ethereum block number observed by the minter.

##### minimum\_deposit\_amounts

> **minimum\_deposit\_amounts**: \[\] \| \[`object`[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L932)

Minimum balance, in each token's own units, that a deposit address must hold for the
balance scan to treat it as a deposit candidate. A smaller balance is never detected.

##### minimum\_eth\_deposit\_amount

> **minimum\_eth\_deposit\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:984](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L984)

Minimum balance, in wei, that a deposit address must hold for the
balance scan to treat it as an ETH deposit candidate. A smaller balance is never detected.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L968)

Minimum amount in Wei that can be withdrawn when converting ckETH -> ETH.

##### minter\_address

> **minter\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:979](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L979)

Ethereum address controlled by the minter via threshold ECDSA.

##### smart\_contract\_address

> **smart\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:960](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L960)

(Deprecated) Address of the ETH helper smart contract.
Use `eth_helper_contract_address`.

##### supported\_ckerc20\_tokens

> **supported\_ckerc20\_tokens**: \[\] \| \[[`CkErc20Token`](#ckerc20token)[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:947](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L947)

Information of supported ERC20 tokens.

##### sweeper\_address

> **sweeper\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:997](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L997)

Dedicated Ethereum address controlled by the minter via threshold ECDSA, whose ETH
balance is the prepaid gas available for sweeping funded deposit addresses.

##### sweeper\_contract\_address

> **sweeper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L988)

Address of the sweeper smart contract.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1003](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1003)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1006)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1005)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1007)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1004](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1004)

***

### RetrieveErc20Request

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1018](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1018)

#### Properties

##### ckerc20\_block\_index

> **ckerc20\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1022](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1022)

Burn index on the ledger handling the withdrawn ckERC20 token.

##### cketh\_block\_index

> **cketh\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1027](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1027)

Burn index on the ckETH ledger.
ckETH is needed to pay for the transaction fees.

***

### RetrieveEthRequest

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1029](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1029)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1030](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1030)

***

### SignedAuthorization

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1071](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1071)

An EIP-7702 authorization tuple: a deposit address' signed consent to delegate
its code to `delegate`, signed by the address itself.

#### Properties

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1074)

##### delegate

> **delegate**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1073)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1075)

##### signature

> **signature**: [`TransactionSignature`](#transactionsignature)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1072](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1072)

***

### TransactionReceipt

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1078)

#### Properties

##### block\_hash

> **block\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1082](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1082)

##### block\_number

> **block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1083](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1083)

##### effective\_gas\_price

> **effective\_gas\_price**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1079](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1079)

##### gas\_used

> **gas\_used**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1084](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1084)

##### status

> **status**: \{ `Success`: `null`; \} \| \{ `Failure`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1080](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1080)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1081](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1081)

***

### TransactionSignature

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1090](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1090)

A secp256k1 signature: the two 32-byte components and the parity recovering
the signing key from them.

#### Properties

##### r

> **r**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1094](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1094)

32-byte signature components.

##### s

> **s**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1095](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1095)

##### y\_parity

> **y\_parity**: `boolean`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1096](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1096)

***

### UnsignedSweeperTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1132](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1132)

A sweep transaction the minter has created but not yet signed: a transaction,
plus the delegations it installs on the way. With none it is sent as a plain
EIP-1559 (0x02) transaction, and otherwise as an EIP-7702 (0x04) one.

#### Properties

##### authorization\_list

> **authorization\_list**: [`SignedAuthorization`](#signedauthorization)[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1134](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1134)

##### transaction

> **transaction**: [`UnsignedTransaction`](#unsignedtransaction)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1133](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1133)

***

### UnsignedTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1136](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1136)

#### Properties

##### access\_list

> **access\_list**: `object`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1145](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1145)

###### address

> **address**: `string`

###### storage\_keys

> **storage\_keys**: `Uint8Array`\<`ArrayBufferLike`\>[]

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1142](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1142)

##### data

> **data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1140](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1140)

##### destination

> **destination**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1137](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1137)

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1144](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1144)

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1141](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1141)

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1139](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1139)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1143](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1143)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1138](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1138)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1147](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1147)

#### Properties

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1151](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1151)

Change the deposit with subaccount helper smart contract address.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1179](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1179)

Change the ERC-20 helper smart contract address.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1199)

Change the ethereum block height observed by the minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1187](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1187)

Change the ETH helper smart contract address.

##### ethereum\_sweeper\_contract\_address

> **ethereum\_sweeper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1164)

Change the sweeper smart contract address.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1160)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1195](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1195)

Change the last scraped block number of the deposit with subaccount helper smart contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1183](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1183)

Change the last scraped block number of the ERC-20 helper smart contract.

##### ledger\_suite\_orchestrator\_id

> **ledger\_suite\_orchestrator\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1169](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1169)

The principal of the ledger suite orchestrator that handles the ICRC1 ledger suites
for all ckERC20 tokens.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1191)

Change the minimum amount in Wei that can be withdrawn.

##### next\_sweeper\_transaction\_nonce

> **next\_sweeper\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1175](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1175)

Change the nonce of the next transaction sent from the dedicated sweeper address (its own
nonce sequence, kept separate from the main address' so a stuck sweep cannot delay a
withdrawal).

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1155)

Change the nonce of the next transaction to be sent to the Ethereum network.

***

### WithdrawalArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1262)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1274](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1274)

The amount of ckETH in Wei that the client wants to withdraw.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1270](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1270)

The subaccount to burn ckETH from.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1266)

The address to which the minter should deposit ETH.

***

### WithdrawalDetail

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1279](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1279)

Details of a withdrawal request and its status.

#### Properties

##### from

> **from**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1299](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1299)

Sender's principal.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1303](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1303)

Sender's subaccount (if given).

##### max\_transaction\_fee

> **max\_transaction\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1307)

Max transaction fee in Wei (transaction fee paid by the sender).

##### recipient\_address

> **recipient\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1311](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1311)

Address to send tokens to.

##### status

> **status**: [`WithdrawalStatus`](#withdrawalstatus)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1283](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1283)

Withdrawal status

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1287)

Symbol of the withdrawal token (either ckETH or ckERC20 token symbol).

##### withdrawal\_amount

> **withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1291)

Amount of tokens in base unit that was withdrawn.

##### withdrawal\_id

> **withdrawal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1295](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1295)

Withdrawal id (i.e. burn index on the ckETH ledger).

***

### WithdrawErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1201](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1201)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1223)

Amount of tokens to withdraw.
The amount is in the smallest unit of the token, e.g.,
ckUSDC uses 6 decimals and so to withdraw 1 ckUSDC, the amount should be 1_000_000.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1205)

The ledger ID for that ckERC20 token.

##### from\_ckerc20\_subaccount

> **from\_ckerc20\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1217](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1217)

The subaccount to burn ckERC20 from.

##### from\_cketh\_subaccount

> **from\_cketh\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1213](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1213)

The subaccount to burn ckETH from to pay for the transaction fee.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1209](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1209)

Ethereum address to withdraw to.

## Type Aliases

### Asset

> **Asset** = \{ `Eth`: `null`; \} \| \{ `Erc20`: `string`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L42)

An asset a deposit pipeline event names: ETH, or an ERC-20 token by its contract address
in EIP-55 format.

***

### BlockTag

> **BlockTag** = \{ `Safe`: `null`; \} \| \{ `Finalized`: `null`; \} \| \{ `Latest`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L62)

#### Type Declaration

\{ `Safe`: `null`; \}

##### Safe

> **Safe**: `null`

/ The latest safe head block.

\{ `Finalized`: `null`; \}

##### Finalized

> **Finalized**: `null`

/ The latest finalized block.

\{ `Latest`: `null`; \}

##### Latest

> **Latest**: `null`

/ The latest mined block.

***

### BurnMemo

> **BurnMemo** = \{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Convert`: \{ `to_address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L81)

#### Type Declaration

\{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20Convert

> **Erc20Convert**: `object`

The minter processed a ckERC20 withdrawal request.

###### Erc20Convert.ckerc20\_withdrawal\_id

> **ckerc20\_withdrawal\_id**: `bigint`

ckETH ledger burn index identifying the burn to pay for the transaction fee.

###### Erc20Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20GasFee

> **Erc20GasFee**: `object`

The minter processed a ckERC20 withdrawal request
and that burn pays the transaction fee.

###### Erc20GasFee.ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

ckERC20 token symbol of the withdrawal request.

###### Erc20GasFee.ckerc20\_withdrawal\_amount

> **ckerc20\_withdrawal\_amount**: `bigint`

The amount of the ckERC20 withdrawal request.

###### Erc20GasFee.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Convert`: \{ `to_address`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter processed a withdrawal request.

###### Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L141)

***

### DecodedMemo

> **DecodedMemo** = \{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \} \| \{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L181)

#### Type Declaration

\{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \}

##### Burn

> **Burn**: \[\] \| \[[`BurnMemo`](#burnmemo)\]

The decoded BurnMemo - `opt` since other variants of `BurnMemo` could be added in the future.

\{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

##### Mint

> **Mint**: \[\] \| \[[`MintMemo`](#mintmemo)\]

The decoded MintMemo - `opt` since other variants of `MintMemo` could be added in the future.

***

### DecodeLedgerMemoError

> **DecodeLedgerMemoError** = `object`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L160)

#### Properties

##### InvalidMemo

> **InvalidMemo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L164)

The provided memo could not be decoded.

***

### DecodeLedgerMemoResult

> **DecodeLedgerMemoResult** = \{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \} \| \{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L166)

#### Type Declaration

\{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \}

##### Ok

> **Ok**: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]

The decoded memo, if the minter was able to decode it. This field is `opt`, so that other memo types can be
added in the future.

\{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

##### Err

> **Err**: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]

An error in case the minter was not able to decode the provided memo. This field is `opt`, so that other error
types can be added in the future.

***

### DepositErc20Error

> **DepositErc20Error** = \{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `TooManyActiveDeposits`: `null`; \} \| \{ `TooManyTokensForAccount`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L218)

#### Type Declaration

\{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \}

##### TokenNotSupported

> **TokenNotSupported**: `object`

The erc20_contract_address is not a ckERC20 token supported by the minter.

###### TokenNotSupported.supported\_tokens

> **supported\_tokens**: [`CkErc20Token`](#ckerc20token)[]

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.

\{ `TooManyActiveDeposits`: `null`; \}

##### TooManyActiveDeposits

> **TooManyActiveDeposits**: `null`

The maximum number of concurrently armed deposits (account, token pairs) has been reached.

\{ `TooManyTokensForAccount`: `null`; \}

##### TooManyTokensForAccount

> **TooManyTokensForAccount**: `null`

The account already has the maximum number of ERC-20 tokens armed.

***

### DepositEthError

> **DepositEthError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `TooManyActiveDeposits`: `null`; \} \| \{ `TooManyTokensForAccount`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L274)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.

\{ `TooManyActiveDeposits`: `null`; \}

##### TooManyActiveDeposits

> **TooManyActiveDeposits**: `null`

The maximum number of concurrently armed deposits ((account, asset) pairs) has been
reached.

\{ `TooManyTokensForAccount`: `null`; \}

##### TooManyTokensForAccount

> **TooManyTokensForAccount**: `null`

The account already has the maximum number of assets armed.

***

### DepositEthStatus

> **DepositEthStatus** = \{ `Scanning`: \{ `last_scanned_block`: \[\] \| \[`bigint`\]; `scan_count`: `bigint`; `valid_until`: `bigint`; \}; \} \| \{ `AwaitingSweep`: [`DetectedEthDeposit`](#detectedethdeposit); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L317)

The stage an ETH deposit address is at.

#### Type Declaration

\{ `Scanning`: \{ `last_scanned_block`: \[\] \| \[`bigint`\]; `scan_count`: `bigint`; `valid_until`: `bigint`; \}; \}

##### Scanning

> **Scanning**: `object`

Armed and being scanned; no deposit at or above the minimum detected yet.

###### Scanning.last\_scanned\_block

> **last\_scanned\_block**: \[\] \| \[`bigint`\]

The latest Ethereum block at which the address' ETH balance was scanned,
or null if it has not been scanned yet.

###### Scanning.scan\_count

> **scan\_count**: `bigint`

How many times the address' ETH balance has been scanned so far.

###### Scanning.valid\_until

> **valid\_until**: `bigint`

Timestamp in nanoseconds since the Unix epoch until which a deposit
sent to the address is guaranteed to be noticed by the minter.

\{ `AwaitingSweep`: [`DetectedEthDeposit`](#detectedethdeposit); \}

##### AwaitingSweep

> **AwaitingSweep**: [`DetectedEthDeposit`](#detectedethdeposit)

Funds were detected at or above the minimum and queued for sweeping.

***

### DepositMode

> **DepositMode** = `object`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L348)

How the fee for a deposit address registration is settled.

#### Properties

##### Unsponsored

> **Unsponsored**: `object`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L353)

The registration fee is deducted from the deposited amount. The deposit
address is derived from the caller's principal and the given subaccount.

###### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\]

***

### DepositStatus

> **DepositStatus** = \{ `Scanning`: \{ `last_scanned_block`: \[\] \| \[`bigint`\]; `scan_count`: `bigint`; `valid_until`: `bigint`; \}; \} \| \{ `AwaitingSweep`: [`DetectedDeposit`](#detecteddeposit); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L358)

The stage a ckERC20 deposit address is at.

#### Type Declaration

\{ `Scanning`: \{ `last_scanned_block`: \[\] \| \[`bigint`\]; `scan_count`: `bigint`; `valid_until`: `bigint`; \}; \}

##### Scanning

> **Scanning**: `object`

Armed and being scanned; no deposit at or above the minimum detected yet.

###### Scanning.last\_scanned\_block

> **last\_scanned\_block**: \[\] \| \[`bigint`\]

The latest Ethereum block at which the address' balance was scanned,
or null if it has not been scanned yet.

###### Scanning.scan\_count

> **scan\_count**: `bigint`

How many times the address' balance has been scanned so far.

###### Scanning.valid\_until

> **valid\_until**: `bigint`

Timestamp in nanoseconds since the Unix epoch until which a deposit
sent to the address is guaranteed to be noticed by the minter.

\{ `AwaitingSweep`: [`DetectedDeposit`](#detecteddeposit); \}

##### AwaitingSweep

> **AwaitingSweep**: [`DetectedDeposit`](#detecteddeposit)

Funds were detected at or above the minimum and queued for sweeping.

***

### EthereumNetwork

> **EthereumNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Sepolia`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L461)

#### Type Declaration

\{ `Mainnet`: `null`; \}

##### Mainnet

> **Mainnet**: `null`

The public Ethereum mainnet.

\{ `Sepolia`: `null`; \}

##### Sepolia

> **Sepolia**: `null`

The public Ethereum Sepolia testnet.

***

### LedgerError

> **LedgerError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \} \| \{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:799](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L799)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The ledger is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

###### InsufficientAllowance.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientAllowance.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientAllowance.token\_symbol

> **token\_symbol**: `string`

\{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low and doesn't cover the ledger transaction fee.

###### AmountTooLow.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### AmountTooLow.ledger\_id

> **ledger\_id**: `Principal`

###### AmountTooLow.minimum\_burn\_amount

> **minimum\_burn\_amount**: `bigint`

###### AmountTooLow.token\_symbol

> **token\_symbol**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

###### InsufficientFunds.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientFunds.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientFunds.token\_symbol

> **token\_symbol**: `string`

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L840)

***

### MemoType

> **MemoType** = \{ `Burn`: `null`; \} \| \{ `Mint`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L844)

***

### MinterArg

> **MinterArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L900)

***

### MintMemo

> **MintMemo** = \{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L856)

#### Type Declaration

\{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \}

##### ReimburseWithdrawal

> **ReimburseWithdrawal**: `object`

The minter failed to process a withdrawal request,
so no transaction was issued, but some reimbursement was made.

###### ReimburseWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \}

##### ReimburseTransaction

> **ReimburseTransaction**: `object`

###### ReimburseTransaction.tx\_hash

> **tx\_hash**: `string`

Hash of the failed transaction.

###### ReimburseTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter received some ETH or ERC20 token.

###### Convert.from\_address

> **from\_address**: `string`

The sender of the ETH or ERC20 token.

###### Convert.log\_index

> **log\_index**: `bigint`

Integer of the log index position in the block.

###### Convert.tx\_hash

> **tx\_hash**: `string`

Hash of the transaction.

***

### ReimbursementIndex

> **ReimbursementIndex** = \{ `CkErc20`: \{ `ckerc20_ledger_burn_index`: `bigint`; `cketh_ledger_burn_index`: `bigint`; `ledger_id`: `Principal`; \}; \} \| \{ `CkEth`: \{ `ledger_burn_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1009)

***

### RetrieveEthStatus

> **RetrieveEthStatus** = \{ `NotFound`: `null`; \} \| \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1035](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1035)

Retrieve the status of a withdrawal request.

#### Type Declaration

\{ `NotFound`: `null`; \}

##### NotFound

> **NotFound**: `null`

Withdrawal request is not found.

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Ethereum transaction is finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Ethereum transaction was signed and is sent to the network.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction fees were estimated and an Ethereum transaction was created.
Transaction is not signed yet.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Withdrawal request is waiting to be processed.

***

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1077](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1077)

***

### TxFinalizedStatus

> **TxFinalizedStatus** = \{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \} \| \{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \} \| \{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1101)

Status of a finalized transaction.

#### Type Declaration

\{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \}

##### Success

> **Success**: `object`

Transaction was successful.

###### Success.effective\_transaction\_fee

> **effective\_transaction\_fee**: \[\] \| \[`bigint`\]

###### Success.transaction\_hash

> **transaction\_hash**: `string`

\{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \}

##### Reimbursed

> **Reimbursed**: `object`

Transaction failed, user got reimbursed.

###### Reimbursed.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### Reimbursed.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

###### Reimbursed.transaction\_hash

> **transaction\_hash**: `string`

\{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

##### PendingReimbursement

> **PendingReimbursement**: [`EthTransaction`](#ethtransaction)

Transaction failed and will be reimbursed,

***

### WithdrawalError

> **WithdrawalError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1313](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1313)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter or the ckETH ledger is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

###### AmountTooLow.min\_withdrawal\_amount

> **min\_withdrawal\_amount**: `bigint`

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckETH balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### WithdrawalSearchParameter

> **WithdrawalSearchParameter** = \{ `ByRecipient`: `string`; \} \| \{ `BySenderAccount`: [`Account`](#account); \} \| \{ `ByWithdrawalId`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1350](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1350)

Search parameter for withdrawals.

#### Type Declaration

\{ `ByRecipient`: `string`; \}

##### ByRecipient

> **ByRecipient**: `string`

Search by recipient's ETH address.

\{ `BySenderAccount`: [`Account`](#account); \}

##### BySenderAccount

> **BySenderAccount**: [`Account`](#account)

Search by sender's token account.

\{ `ByWithdrawalId`: `bigint`; \}

##### ByWithdrawalId

> **ByWithdrawalId**: `bigint`

Search by ckETH burn index (which is also used to index ckERC20 withdrawals).

***

### WithdrawalStatus

> **WithdrawalStatus** = \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1372](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1372)

Status of a withdrawal request.

#### Type Declaration

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Transaction already finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Transaction sent but not yet finalized.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction created byt not yet sent.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Request is pending, i.e. transaction is not yet created.

***

### WithdrawErc20Error

> **WithdrawErc20Error** = \{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1225](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1225)

#### Type Declaration

\{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \}

##### TokenNotSupported

> **TokenNotSupported**: `object`

The user provided ckERC20 token is not supported by the minter.

###### TokenNotSupported.supported\_tokens

> **supported\_tokens**: [`CkErc20Token`](#ckerc20token)[]

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkErc20LedgerError

> **CkErc20LedgerError**: `object`

The minter could not burn the requested amount of ckERC20 tokens.
The `cketh_block_index` identifies the burn that occurred on the ckETH ledger and that will be reimbursed.

###### CkErc20LedgerError.cketh\_block\_index

> **cketh\_block\_index**: `bigint`

###### CkErc20LedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkEthLedgerError

> **CkEthLedgerError**: `object`

The minter could not burn the required amount of ckETH to pay for the transaction fees.

###### CkEthLedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1512](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1512)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1513](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/minter.d.ts#L1513)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
