---
title: CkEthOrchestratorDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L340)

#### Properties

##### canister\_ids

> **canister\_ids**: `ActorMethod`\<\[[`Erc20Contract`](#erc20contract)\], \[\] \| \[[`ManagedCanisterIds`](#managedcanisterids)\]\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L344)

Managed canister IDs for a given ERC20 contract

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L348)

Retrieve the status of the canister.

##### get\_orchestrator\_info

> **get\_orchestrator\_info**: `ActorMethod`\<\[\], [`OrchestratorInfo`](#orchestratorinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L352)

Return internal orchestrator parameters

***

### AddErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L13)

#### Properties

##### contract

> **contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L14)

##### ledger\_init\_arg

> **ledger\_init\_arg**: [`LedgerInitArg`](#ledgerinitarg)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L15)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L17)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L23)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L26)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L18)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L20)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L27)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L25)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L21)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L28)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L24)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L19)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L22)

***

### ChangeArchiveOptions

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L38)

Changes the parameters used to spawn and maintain archive canisters.
Same type as `ChangeArchiveOptions` in the ICRC1 ledger's Candid file.

#### Properties

##### controller\_id

> **controller\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L46)

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L44)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L43)

##### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L40)

##### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L42)

##### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L45)

##### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L39)

##### trigger\_threshold

> **trigger\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L41)

***

### CyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L48)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L60)

Number of cycles when creating a new ICRC1 archive canister.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L64)

Number of cycles when creating a new ICRC1 index canister.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L56)

Number of cycles when creating a new ICRC1 ledger canister.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L52)

Number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L66)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L76)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L70)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L69)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L67)

##### log\_memory\_limit

> **log\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L73)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L72)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L75)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L71)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L74)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L68)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L336)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L338)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L337)

***

### Erc20Contract

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L78)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L80)

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L79)

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L82)

#### Properties

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`CyclesManagement`](#cyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L86)

Controls the cycles management of the canisters managed by the orchestrator.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L95)

Canister ID of the minter that will be notified when new ERC-20 tokens are added.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L91)

All canisters that will be spawned off by the orchestrator will be controlled by the orchestrator
and *additionally* by the following controllers.

***

### InstalledCanister

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L97)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L98)

##### installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L99)

***

### InstalledLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L101)

#### Properties

##### archives

> **archives**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L117)

List of archive canister ids

##### index

> **index**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L113)

Index canister

##### ledger

> **ledger**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L109)

Ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L105)

Token symbol on the ledger

***

### LedgerInitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L123)

ICRC1 ledger initialization argument that will be used when the orchestrator spawns a new ledger canister.
Other fields, such as `archive_options`, needed to initialize a new ledger will be set by the orchestrator.

#### Properties

##### decimals

> **decimals**: `number`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L124)

##### token\_logo

> **token\_logo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L127)

##### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L128)

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L125)

##### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L126)

***

### LedgerSuiteVersion

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L130)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L135)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"e59ec306ef67d0ec2e8919e8f6366aff31c666346e238d07d52f616bef61ccab".

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L147)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used to spawn off a new index canister when an ERC-20 token is added.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L141)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used to spawn off a new ledger canister when an ERC-20 token is added.

***

### LedgerUpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L153)

Subset of the ICRC1 ledger `UpgradeArgs` (see the ledger's Candid file) that the
orchestrator forwards to its managed ledger canisters.

#### Properties

##### change\_archive\_options

> **change\_archive\_options**: \[\] \| \[[`ChangeArchiveOptions`](#changearchiveoptions)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L154)

***

### ManagedCanisterIds

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L160)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L163)

##### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L162)

##### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L161)

***

### ManagedCanisters

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L180)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L196)

List of archive canister ids

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L200)

ckERC20 Token symbol

##### erc20\_contract

> **erc20\_contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L184)

Corresponding ERC20 contract

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L192)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L188)

Status of the ledger canister

***

### ManagedLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L202)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L218)

List of archive canister ids

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L214)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L210)

Status of the ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L206)

Token symbol

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L220)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L224)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L229)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L228)

##### log\_memory\_store\_size

> **log\_memory\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L222)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L226)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L225)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L221)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L223)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L227)

***

### OrchestratorInfo

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L235)

#### Properties

##### cycles\_management

> **cycles\_management**: [`CyclesManagement`](#cyclesmanagement)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L239)

Cycle management parameters.

##### ledger\_suite\_version

> **ledger\_suite\_version**: \[\] \| \[[`LedgerSuiteVersion`](#ledgersuiteversion)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L256)

Ledger suite version that will be used to spawn off a new ledger suite (ledger and index canisters) when an ERC-20 token is added.

##### managed\_canisters

> **managed\_canisters**: [`ManagedCanisters`](#managedcanisters)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L243)

List of managed canisters data for each ERC20 contract.

##### managed\_pre\_existing\_ledger\_suites

> **managed\_pre\_existing\_ledger\_suites**: \[\] \| \[[`ManagedLedgerSuite`](#managedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L248)

List of managed ledger suites that were not initially installed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L260)

ckETH minter canister id.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L252)

Additional controllers that new canisters will be spawned with.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L262)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L265)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L264)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L266)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L263)

***

### UpdateCyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L268)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L282)

Change the number of cycles when creating a new ICRC1 archive canister.
Previously created canisters are not affected.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L287)

Change the number of cycles when creating a new ICRC1 index canister.
Previously created canisters are not affected.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L277)

Change the number of cycles when creating a new ICRC1 ledger canister.
Previously created canisters are not affected.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L272)

Change the number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L289)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L306)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"b24812976b2cc64f12faf813cf592631f3062bfda837334f77ab807361d64e82".
This exact version will be used for upgrading all existing archive canisters managed by the orchestrator.
Leaving this field empty will not upgrade the archive canisters.

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`UpdateCyclesManagement`](#updatecyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L299)

Update the cycles management of the canisters managed by the orchestrator.

##### git\_commit\_hash

> **git\_commit\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L314)

Hexadecimal encoding of the SHA-1 git commit hash used for this upgrade, e.g.,
"51d01d3936498d4010de54505d6433e9ad5cc62b", corresponding to a git revision in the
[IC repository](https://github.com/dfinity/ic).
If this field is present, the orchestrator will register all embedded wasms (ledger, index, and archive) in its stable memory,
so that those exact wasms can be used to upgrade managed canisters as specified below.

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L328)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used for upgrading all existing index canisters managed by the orchestrator.
Leaving this field empty will not upgrade the index canisters.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L321)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used for upgrading all existing ledger canisters managed by the orchestrator.
Leaving this field empty will not upgrade the ledger canisters.

##### ledger\_upgrade\_arg

> **ledger\_upgrade\_arg**: \[\] \| \[[`LedgerUpgradeArg`](#ledgerupgradearg)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L334)

Upgrade argument forwarded to every managed ledger canister when upgrading it.
Requires `ledger_compressed_wasm_hash` to be set, since ledger canisters are only
upgraded when that field is present.

##### manage\_ledger\_suites

> **manage\_ledger\_suites**: \[\] \| \[[`InstalledLedgerSuite`](#installedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L295)

Add already installed ledger suites to the canisters managed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.
This assumes that the orchestrator is a controller of all the canisters in the list.

## Type Aliases

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L30)

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L156)

***

### ManagedCanisterStatus

> **ManagedCanisterStatus** = \{ `Created`: \{ `canister_id`: `Principal`; \}; \} \| \{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L165)

#### Type Declaration

\{ `Created`: \{ `canister_id`: `Principal`; \}; \}

##### Created

> **Created**: `object`

Canister created with the given principal but wasm module is not yet installed.

###### Created.canister\_id

> **canister\_id**: `Principal`

\{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

##### Installed

> **Installed**: `object`

Canister created and wasm module installed.
The wasm_hash reflects the installed wasm module by the orchestrator
but *may differ* from the one being currently deployed (if another controller did an upgrade)

###### Installed.canister\_id

> **canister\_id**: `Principal`

###### Installed.installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

***

### OrchestratorArg

> **OrchestratorArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \} \| \{ `AddErc20Arg`: [`AddErc20Arg`](#adderc20arg); \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L231)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L354)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L355)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
