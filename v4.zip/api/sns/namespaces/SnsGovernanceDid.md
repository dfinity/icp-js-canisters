---
title: SnsGovernanceDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L910)

#### Properties

##### claim\_swap\_neurons

> **claim\_swap\_neurons**: `ActorMethod`\<\[[`ClaimSwapNeuronsRequest`](#claimswapneuronsrequest)\], [`ClaimSwapNeuronsResponse`](#claimswapneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L911)

##### fail\_stuck\_upgrade\_in\_progress

> **fail\_stuck\_upgrade\_in\_progress**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L915)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L916)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L917)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[\{ \}\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L918)

##### get\_metadata

> **get\_metadata**: `ActorMethod`\<\[\{ \}\], [`GetMetadataResponse`](#getmetadataresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L919)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L920)

##### get\_metrics\_replicated

> **get\_metrics\_replicated**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:921](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L921)

##### get\_mode

> **get\_mode**: `ActorMethod`\<\[\{ \}\], [`GetModeResponse`](#getmoderesponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L922)

##### get\_nervous\_system\_parameters

> **get\_nervous\_system\_parameters**: `ActorMethod`\<\[`null`\], [`NervousSystemParameters`](#nervoussystemparameters)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:923](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L923)

##### get\_neuron

> **get\_neuron**: `ActorMethod`\<\[[`GetNeuron`](#getneuron)\], [`GetNeuronResponse`](#getneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:924](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L924)

##### get\_proposal

> **get\_proposal**: `ActorMethod`\<\[[`GetProposal`](#getproposal)\], [`GetProposalResponse`](#getproposalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:925](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L925)

##### get\_root\_canister\_status

> **get\_root\_canister\_status**: `ActorMethod`\<\[`null`\], [`CanisterStatusResultV2`](#canisterstatusresultv2)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L926)

##### get\_running\_sns\_version

> **get\_running\_sns\_version**: `ActorMethod`\<\[\{ \}\], [`GetRunningSnsVersionResponse`](#getrunningsnsversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L927)

##### get\_sns\_initialization\_parameters

> **get\_sns\_initialization\_parameters**: `ActorMethod`\<\[\{ \}\], [`GetSnsInitializationParametersResponse`](#getsnsinitializationparametersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L928)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L932)

##### get\_upgrade\_journal

> **get\_upgrade\_journal**: `ActorMethod`\<\[[`GetUpgradeJournalRequest`](#getupgradejournalrequest)\], [`GetUpgradeJournalResponse`](#getupgradejournalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L933)

##### list\_nervous\_system\_functions

> **list\_nervous\_system\_functions**: `ActorMethod`\<\[\], [`ListNervousSystemFunctionsResponse`](#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L937)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:941](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L941)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposals`](#listproposals)\], [`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:942](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L942)

##### list\_topics

> **list\_topics**: `ActorMethod`\<\[[`ListTopicsRequest`](#listtopicsrequest)\], [`ListTopicsResponse`](#listtopicsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L943)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuron`](#manageneuron)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:944](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L944)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:945](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L945)

##### set\_mode

> **set\_mode**: `ActorMethod`\<\[[`SetMode`](#setmode)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L946)

***

### Account

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L15)

***

### AddNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L48)

#### Properties

##### permissions\_to\_add

> **permissions\_to\_add**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L49)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L50)

***

### AdvanceSnsTargetVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L52)

#### Properties

##### new\_target

> **new\_target**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L53)

***

### AdvanceSnsTargetVersionActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L55)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L56)

***

### Amount

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L58)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L59)

***

### Ballot

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L61)

#### Properties

##### cast\_timestamp\_seconds

> **cast\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L63)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L62)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L64)

***

### CachedUpgradeSteps

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L67)

#### Properties

##### requested\_timestamp\_seconds

> **requested\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L70)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L69)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L68)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L72)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L76)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L79)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L73)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L75)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L80)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L78)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L77)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L74)

***

### CanisterUpgradeOptions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L86)

#### Properties

##### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L88)

##### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L87)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L90)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L91)

***

### ChunkedCanisterWasm

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L93)

#### Properties

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L95)

##### store\_canister\_id

> **store\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L96)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L94)

***

### ClaimedSwapNeurons

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L113)

#### Properties

##### swap\_neurons

> **swap\_neurons**: [`SwapNeuron`](#swapneuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L114)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L98)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L99)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L101)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L102)

***

### ClaimSwapNeuronsRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L104)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: \[\] \| \[[`NeuronRecipes`](#neuronrecipes)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L105)

***

### ClaimSwapNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L107)

#### Properties

##### claim\_swap\_neurons\_result

> **claim\_swap\_neurons\_result**: \[\] \| \[[`ClaimSwapNeuronsResult`](#claimswapneuronsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L108)

***

### Configure

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L160)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L161)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L163)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L164)

***

### Decimal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L166)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L167)

***

### DefaultFollowees

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L169)

#### Properties

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L170)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L172)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L178)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L175)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L173)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L177)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L176)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L174)

***

### DeregisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L180)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L181)

##### new\_controllers

> **new\_controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L182)

***

### Disburse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L184)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L186)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L185)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L188)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L190)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L189)

***

### DisburseMaturityInProgress

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L192)

#### Properties

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L195)

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L194)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L196)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L193)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L198)

#### Properties

##### amount\_deducted\_e8s

> **amount\_deducted\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L200)

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L199)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L202)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L203)

***

### ExecuteExtensionOperation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L208)

#### Properties

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L209)

##### operation\_arg

> **operation\_arg**: \[\] \| \[[`ExtensionOperationArg`](#extensionoperationarg)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L211)

##### operation\_name

> **operation\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L210)

***

### ExecuteGenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L213)

#### Properties

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L214)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L215)

***

### ExtensionInit

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L217)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L218)

***

### ExtensionOperationArg

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L220)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L221)

***

### ExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L223)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L226)

##### extension\_type

> **extension\_type**: \[\] \| \[[`ExtensionType`](#extensiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L227)

##### operation\_type

> **operation\_type**: \[\] \| \[[`ExtensionOperationType`](#extensionoperationtype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L225)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L224)

***

### ExtensionUpgradeArg

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L233)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L234)

***

### FinalizeDisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L236)

#### Properties

##### amount\_to\_be\_disbursed\_e8s

> **amount\_to\_be\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L237)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L238)

***

### Follow

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L240)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L242)

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L241)

***

### Followee

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L244)

#### Properties

##### alias

> **alias**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L245)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L246)

***

### Followees

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L248)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L249)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L251)

#### Properties

##### followees

> **followees**: [`Followee`](#followee)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L253)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L252)

***

### GenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L258)

#### Properties

##### target\_canister\_id

> **target\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L261)

##### target\_method\_name

> **target\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L263)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L259)

##### validator\_canister\_id

> **validator\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L260)

##### validator\_method\_name

> **validator\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L262)

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L265)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L266)

***

### GetMetadataResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L268)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L272)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L270)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L271)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L269)

***

### GetMetricsRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L274)

#### Properties

##### time\_window\_seconds

> **time\_window\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L275)

***

### GetMetricsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L277)

#### Properties

##### get\_metrics\_result

> **get\_metrics\_result**: \[\] \| \[[`GetMetricsResult`](#getmetricsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L278)

***

### GetModeResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L281)

#### Properties

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L282)

***

### GetNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L284)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L285)

***

### GetNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L287)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L288)

***

### GetProposal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L290)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L291)

***

### GetProposalResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L293)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L294)

***

### GetRunningSnsVersionResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L296)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L297)

##### pending\_version

> **pending\_version**: \[\] \| \[\{ `checking_upgrade_lock`: `bigint`; `mark_failed_at_seconds`: `bigint`; `proposal_id`: `bigint`; `target_version`: \[\] \| \[[`Version`](#version)\]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L298)

***

### GetSnsInitializationParametersResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L309)

#### Properties

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L310)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L312)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L313)

***

### GetUpgradeJournalRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L315)

#### Properties

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L317)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L316)

***

### GetUpgradeJournalResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L319)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L323)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L322)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L324)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L320)

##### upgrade\_journal\_entry\_count

> **upgrade\_journal\_entry\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L325)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L321)

***

### Governance

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L327)

#### Properties

##### cached\_upgrade\_steps

> **cached\_upgrade\_steps**: \[\] \| \[[`CachedUpgradeSteps`](#cachedupgradesteps)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L330)

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L338)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L349)

##### id\_to\_nervous\_system\_functions

> **id\_to\_nervous\_system\_functions**: \[`bigint`, [`NervousSystemFunction`](#nervoussystemfunction)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L331)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`string`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L345)

##### is\_finalizing\_disburse\_maturity

> **is\_finalizing\_disburse\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L337)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L340)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L343)

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L333)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L332)

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L335)

##### neurons

> **neurons**: \[`string`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L347)

##### parameters

> **parameters**: \[\] \| \[[`NervousSystemParameters`](#nervoussystemparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L336)

##### pending\_version

> **pending\_version**: \[\] \| \[[`PendingVersion`](#pendingversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L341)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L344)

##### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L328)

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L339)

##### sns\_metadata

> **sns\_metadata**: \[\] \| \[[`ManageSnsMetadata`](#managesnsmetadata)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L346)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L342)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L348)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L329)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L334)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L351)

#### Properties

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L358)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L363)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L366)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L365)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L367)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L354)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L355)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L357)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L364)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L362)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L356)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L353)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L368)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L359)

##### total\_supply\_governance\_tokens

> **total\_supply\_governance\_tokens**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L360)

##### treasury\_metrics

> **treasury\_metrics**: [`TreasuryMetrics`](#treasurymetrics)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L352)

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L361)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L370)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L371)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L372)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L374)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L375)

***

### ListNervousSystemFunctionsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L377)

#### Properties

##### functions

> **functions**: [`NervousSystemFunction`](#nervoussystemfunction)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L379)

##### reserved\_ids

> **reserved\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L378)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L381)

#### Properties

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L383)

##### of\_principal

> **of\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L382)

##### start\_page\_at

> **start\_page\_at**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L384)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L386)

#### Properties

##### neurons

> **neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L387)

***

### ListProposals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L389)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L391)

##### exclude\_type

> **exclude\_type**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L393)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L390)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L395)

##### include\_topics

> **include\_topics**: \[\] \| \[[`TopicSelector`](#topicselector)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L394)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L392)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L397)

#### Properties

##### include\_ballots\_by\_caller

> **include\_ballots\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L398)

##### include\_topic\_filtering

> **include\_topic\_filtering**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L400)

##### proposals

> **proposals**: [`ProposalData`](#proposaldata)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L399)

***

### ListTopicsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L403)

#### Properties

##### topics

> **topics**: \[\] \| \[[`TopicInfo`](#topicinfo)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L405)

##### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L404)

***

### ManageDappCanisterSettings

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L407)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L410)

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L416)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L408)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L412)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L415)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L411)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L413)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L414)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L409)

***

### ManageLedgerParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L418)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L421)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L422)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L419)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L420)

***

### ManageNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L424)

#### Properties

##### command

> **command**: \[\] \| \[[`Command`](#command-3)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L426)

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L425)

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L428)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L429)

***

### ManageSnsMetadata

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L431)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L435)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L433)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L434)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L432)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L437)

#### Properties

##### current\_basis\_points

> **current\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L438)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L439)

***

### MemoAndController

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L441)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L442)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L443)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L445)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L448)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L453)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L452)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L450)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L449)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L446)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L447)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L451)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L455)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L456)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L458)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L459)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L460)

***

### Metrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L462)

#### Properties

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L471)

##### last\_ledger\_block\_timestamp

> **last\_ledger\_block\_timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L468)

##### num\_recently\_executed\_proposals

> **num\_recently\_executed\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L469)

##### num\_recently\_submitted\_proposals

> **num\_recently\_submitted\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L470)

##### treasury\_metrics

> **treasury\_metrics**: \[\] \| \[[`TreasuryMetrics`](#treasurymetrics)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L466)

The metrics below are cached (albeit this is an implementation detail).

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L467)

***

### MintSnsTokens

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L473)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:477](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L477)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L476)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L474)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L475)

***

### MintSnsTokensActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L479)

#### Properties

##### valuation

> **valuation**: \[\] \| \[[`Valuation`](#valuation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L480)

***

### Motion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L482)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L483)

***

### NervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L485)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L488)

##### function\_type

> **function\_type**: \[\] \| \[[`FunctionType`](#functiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L489)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L486)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L487)

***

### NervousSystemParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L491)

#### Properties

##### automatically\_advance\_target\_version

> **automatically\_advance\_target\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L496)

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L507)

##### default\_followees

> **default\_followees**: \[\] \| \[[`DefaultFollowees`](#defaultfollowees)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L492)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L500)

##### maturity\_modulation\_disabled

> **maturity\_modulation\_disabled**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L512)

##### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L509)

##### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L494)

##### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L493)

##### max\_followees\_per\_function

> **max\_followees\_per\_function**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L495)

##### max\_neuron\_age\_for\_age\_bonus

> **max\_neuron\_age\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L499)

##### max\_number\_of\_neurons

> **max\_number\_of\_neurons**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L505)

##### max\_number\_of\_principals\_per\_neuron

> **max\_number\_of\_principals\_per\_neuron**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L513)

##### max\_number\_of\_proposals\_with\_ballots

> **max\_number\_of\_proposals\_with\_ballots**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L508)

##### max\_proposals\_to\_keep\_per\_action

> **max\_proposals\_to\_keep\_per\_action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L503)

##### neuron\_claimer\_permissions

> **neuron\_claimer\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L497)

##### neuron\_grantable\_permissions

> **neuron\_grantable\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L510)

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L501)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L498)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L502)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L506)

##### voting\_rewards\_parameters

> **voting\_rewards\_parameters**: \[\] \| \[[`VotingRewardsParameters`](#votingrewardsparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L511)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L504)

***

### Neuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L515)

#### Properties

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L527)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L526)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L520)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L521)

##### disburse\_maturity\_in\_progress

> **disburse\_maturity\_in\_progress**: [`DisburseMaturityInProgress`](#disbursematurityinprogress)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L532)

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L529)

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L533)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L516)

##### latest\_reward\_event\_participation

> **latest\_reward\_event\_participation**: \[\] \| \[[`RewardEventParticipation`](#rewardeventparticipation)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L528)

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L519)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L534)

##### permissions

> **permissions**: [`NeuronPermission`](#neuronpermission)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L518)

##### source\_nns\_neuron\_id

> **source\_nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L525)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L517)

##### topic\_followees

> **topic\_followees**: \[\] \| \[\{ `topic_id_to_followees`: \[`number`, [`FolloweesForTopic`](#followeesfortopic)\][]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L522)

##### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L531)

##### voting\_power\_percentage\_multiplier

> **voting\_power\_percentage\_multiplier**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L530)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L536)

#### Properties

##### id

> **id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L537)

***

### NeuronIds

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L539)

#### Properties

##### neuron\_ids

> **neuron\_ids**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L540)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L542)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L543)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L544)

***

### NeuronPermission

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L546)

#### Properties

##### permission\_type

> **permission\_type**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L548)

##### principal

> **principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L547)

***

### NeuronPermissionList

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L550)

#### Properties

##### permissions

> **permissions**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L551)

***

### NeuronRecipe

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L553)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L554)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L555)

##### followees

> **followees**: \[\] \| \[[`NeuronIds`](#neuronids)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L558)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L559)

##### participant

> **participant**: \[\] \| \[[`Participant`](#participant-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L556)

##### stake\_e8s

> **stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L557)

***

### NeuronRecipes

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L561)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: [`NeuronRecipe`](#neuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L562)

***

### NeuronsFund

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L564)

#### Properties

##### nns\_neuron\_controller

> **nns\_neuron\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L566)

##### nns\_neuron\_hotkeys

> **nns\_neuron\_hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L565)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L567)

***

### PendingVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L578)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L580)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L579)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L581)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L582)

***

### Percentage

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L584)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L585)

***

### Principals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L611)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L612)

***

### Proposal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:614](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L614)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L617)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L618)

##### title

> **title**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L616)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L615)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L620)

#### Properties

##### action

> **action**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L625)

##### action\_auxiliary

> **action\_auxiliary**: \[\] \| \[[`ActionAuxiliary`](#actionauxiliary)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L627)

##### ballots

> **ballots**: \[`string`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L628)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L638)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L644)

##### execution\_reply

> **execution\_reply**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L624)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L631)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L626)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L621)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L634)

##### is\_eligible\_for\_rewards

> **is\_eligible\_for\_rewards**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L643)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L636)

##### minimum\_yes\_proportion\_of\_exercised

> **minimum\_yes\_proportion\_of\_exercised**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L642)

##### minimum\_yes\_proportion\_of\_total

> **minimum\_yes\_proportion\_of\_total**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L629)

##### payload\_text\_rendering

> **payload\_text\_rendering**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L622)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:639](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L639)

##### proposal\_creation\_timestamp\_seconds

> **proposal\_creation\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L633)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L640)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L635)

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L632)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L630)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L623)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L637)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L641)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L646)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L647)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L649)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L652)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L651)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L653)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L650)

***

### RegisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:655](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L655)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L656)

***

### RegisteredExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L666)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L668)

##### spec

> **spec**: \[\] \| \[[`ExtensionOperationSpec`](#extensionoperationspec)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L667)

***

### RegisterExtension

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L658)

#### Properties

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L659)

##### extension\_init

> **extension\_init**: \[\] \| \[[`ExtensionInit`](#extensioninit)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:660](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L660)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L662)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L664)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:663](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L663)

***

### RemoveNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L670)

#### Properties

##### permissions\_to\_remove

> **permissions\_to\_remove**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L671)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L672)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L676)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L678)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L681)

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L679)

##### round

> **round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L682)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L677)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:683](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L683)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L680)

***

### RewardEventParticipation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L685)

#### Properties

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L686)

##### reward\_shares

> **reward\_shares**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:687](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L687)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L689)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:690](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L690)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L692)

#### Properties

##### topic\_following

> **topic\_following**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L693)

***

### SetMode

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:695](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L695)

#### Properties

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:696](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L696)

***

### SetTopicsForCustomProposals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:698](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L698)

#### Properties

##### custom\_function\_id\_to\_topic

> **custom\_function\_id\_to\_topic**: \[`bigint`, [`Topic`](#topic-6)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L699)

***

### SnsVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:701](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L701)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:702](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L702)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:706](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L706)

##### index\_wasm\_hash

> **index\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:707](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L707)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:705](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L705)

##### root\_wasm\_hash

> **root\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:703](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L703)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L704)

***

### Split

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L709)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L711)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L710)

***

### SplitResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L713)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:714](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L714)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:716](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L716)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L717)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:719](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L719)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:720](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L720)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L721)

***

### Subaccount

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L723)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L724)

***

### SwapNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L726)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L727)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L728)

***

### Tally

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L730)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L731)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L734)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:733](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L733)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L732)

***

### TargetVersionReset

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L736)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L737)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L739)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L738)

***

### TargetVersionSet

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L741)

#### Properties

##### is\_advanced\_automatically

> **is\_advanced\_automatically**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L744)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:743](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L743)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L742)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L746)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L748)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L747)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L749)

***

### Tokens

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L751)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L752)

***

### TopicInfo

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L762)

#### Properties

##### custom\_functions

> **custom\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L769)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L768)

##### extension\_operations

> **extension\_operations**: \[\] \| \[[`RegisteredExtensionOperationSpec`](#registeredextensionoperationspec)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L763)

##### is\_critical

> **is\_critical**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L766)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L767)

##### native\_functions

> **native\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L764)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:765](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L765)

***

### TopicSelector

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L771)

#### Properties

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L772)

***

### TransferSnsTreasuryFunds

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:774](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L774)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L779)

##### from\_treasury

> **from\_treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L775)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:778](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L778)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L776)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:777](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L777)

***

### TreasuryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:781](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L781)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:794](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L794)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L793)

The regularly updated amount of tokens in this treasury.

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:798](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L798)

The source of truth for the treasury balance is this ledger canister / account.

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L785)

A human-readable identified for this treasury, e.g., "ICP".

##### original\_amount\_e8s

> **original\_amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:789](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L789)

The amount of tokens in this treasury at the end of swap finalization.

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:806](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L806)

When the metrics were last updated.

##### treasury

> **treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:802](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L802)

Same as, e.g., `TransferSnsTreasuryFunds.from_treasury`.

***

### UpgradeExtension

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:808](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L808)

#### Properties

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[[`ExtensionUpgradeArg`](#extensionupgradearg)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L811)

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L809)

##### wasm

> **wasm**: \[\] \| \[[`Wasm`](#wasm-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:810](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L810)

***

### UpgradeInProgress

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:813](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L813)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:815](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L815)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:814](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L814)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:816](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L816)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:817](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L817)

***

### UpgradeJournal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:819](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L819)

#### Properties

##### entries

> **entries**: [`UpgradeJournalEntry`](#upgradejournalentry)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:820](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L820)

***

### UpgradeJournalEntry

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:822](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L822)

#### Properties

##### event

> **event**: \[\] \| \[\{ `TargetVersionSet`: [`TargetVersionSet`](#targetversionset); \} \| \{ `UpgradeStepsReset`: [`UpgradeStepsReset`](#upgradestepsreset); \} \| \{ `UpgradeOutcome`: [`UpgradeOutcome`](#upgradeoutcome); \} \| \{ `UpgradeStarted`: [`UpgradeStarted`](#upgradestarted); \} \| \{ `UpgradeStepsRefreshed`: [`UpgradeStepsRefreshed`](#upgradestepsrefreshed); \} \| \{ `TargetVersionReset`: [`TargetVersionReset`](#targetversionreset); \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:823](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L823)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:833](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L833)

***

### UpgradeOutcome

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:835](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L835)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L844)

##### status

> **status**: \[\] \| \[\{ `Success`: \{ \}; \} \| \{ `Timeout`: \{ \}; \} \| \{ `ExternalFailure`: \{ \}; \} \| \{ `InvalidState`: \{ `version`: \[\] \| \[[`Version`](#version)\]; \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:836](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L836)

***

### UpgradeSnsControlledCanister

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L846)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L849)

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:852](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L852)

##### canister\_upgrade\_options

> **canister\_upgrade\_options**: \[\] \| \[[`CanisterUpgradeOptions`](#canisterupgradeoptions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:850](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L850)

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:851](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L851)

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:848](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L848)

##### new\_canister\_wasm

> **new\_canister\_wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L847)

***

### UpgradeStarted

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L854)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:855](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L855)

##### expected\_version

> **expected\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L856)

##### reason

> **reason**: \[\] \| \[\{ `UpgradeSnsToNextVersionProposal`: [`ProposalId`](#proposalid); \} \| \{ `BehindTargetVersion`: \{ \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L857)

***

### UpgradeStepsRefreshed

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L864)

#### Properties

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:865](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L865)

***

### UpgradeStepsReset

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:867](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L867)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L868)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L869)

***

### Valuation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L871)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L873)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L875)

##### token

> **token**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L872)

##### valuation\_factors

> **valuation\_factors**: \[\] \| \[[`ValuationFactors`](#valuationfactors)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L874)

***

### ValuationFactors

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:877](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L877)

#### Properties

##### icps\_per\_token

> **icps\_per\_token**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L879)

##### tokens

> **tokens**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L880)

##### xdrs\_per\_icp

> **xdrs\_per\_icp**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:878](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L878)

***

### Version

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L882)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L883)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L887)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L888)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L886)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:884](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L884)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L885)

***

### Versions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L890)

#### Properties

##### versions

> **versions**: [`Version`](#version)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L891)

***

### VotingPowerMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L893)

#### Properties

##### governance\_total\_potential\_voting\_power

> **governance\_total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:894](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L894)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L898)

When the metrics were last updated.

***

### VotingRewardsParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L900)

#### Properties

##### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L901)

##### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L902)

##### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:903](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L903)

##### round\_duration\_seconds

> **round\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:904](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L904)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L906)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L907)

## Type Aliases

### Action

> **Action** = \{ `ManageNervousSystemParameters`: [`NervousSystemParameters`](#nervoussystemparameters); \} \| \{ `AddGenericNervousSystemFunction`: [`NervousSystemFunction`](#nervoussystemfunction); \} \| \{ `ManageDappCanisterSettings`: [`ManageDappCanisterSettings`](#managedappcanistersettings); \} \| \{ `ExecuteExtensionOperation`: [`ExecuteExtensionOperation`](#executeextensionoperation); \} \| \{ `UpgradeExtension`: [`UpgradeExtension`](#upgradeextension); \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: [`SetTopicsForCustomProposals`](#settopicsforcustomproposals); \} \| \{ `RegisterExtension`: [`RegisterExtension`](#registerextension); \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: [`RegisterDappCanisters`](#registerdappcanisters); \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](#transfersnstreasuryfunds); \} \| \{ `UpgradeSnsControlledCanister`: [`UpgradeSnsControlledCanister`](#upgradesnscontrolledcanister); \} \| \{ `DeregisterDappCanisters`: [`DeregisterDappCanisters`](#deregisterdappcanisters); \} \| \{ `MintSnsTokens`: [`MintSnsTokens`](#mintsnstokens); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersion`](#advancesnstargetversion); \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: [`ManageSnsMetadata`](#managesnsmetadata); \} \| \{ `ExecuteGenericNervousSystemFunction`: [`ExecuteGenericNervousSystemFunction`](#executegenericnervoussystemfunction); \} \| \{ `ManageLedgerParameters`: [`ManageLedgerParameters`](#manageledgerparameters); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L17)

***

### ActionAuxiliary

> **ActionAuxiliary** = \{ `TransferSnsTreasuryFunds`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `MintSnsTokens`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersionActionAuxiliary`](#advancesnstargetversionactionauxiliary); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L42)

***

### By

> **By** = \{ `MemoAndController`: [`MemoAndController`](#memoandcontroller); \} \| \{ `NeuronId`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L66)

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L82)

***

### ClaimSwapNeuronsResult

> **ClaimSwapNeuronsResult** = \{ `Ok`: [`ClaimedSwapNeurons`](#claimedswapneurons); \} \| \{ `Err`: `number`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L110)

***

### Command

> **Command** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L116)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Split`: [`SplitResponse`](#splitresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `SetFollowing`: \{ \}; \} \| \{ `MakeProposal`: [`GetProposal`](#getproposal); \} \| \{ `RemoveNeuronPermission`: \{ \}; \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \} \| \{ `AddNeuronPermission`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L130)

***

### Command\_2

> **Command\_2** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `FinalizeDisburseMaturity`: [`FinalizeDisburseMaturity`](#finalizedisbursematurity); \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L145)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L205)

***

### ExtensionOperationType

> **ExtensionOperationType** = \{ `TreasuryManagerWithdraw`: `null`; \} \| \{ `TreasuryManagerDeposit`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L229)

***

### ExtensionType

> **ExtensionType** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L232)

#### Properties

##### TreasuryManager

> **TreasuryManager**: `null`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L232)

***

### FunctionType

> **FunctionType** = \{ `NativeNervousSystemFunction`: \{ \}; \} \| \{ `GenericNervousSystemFunction`: [`GenericNervousSystemFunction`](#genericnervoussystemfunction); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L255)

***

### GetMetricsResult

> **GetMetricsResult** = \{ `Ok`: [`Metrics`](#metrics-1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L280)

***

### ListTopicsRequest

> **ListTopicsRequest** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L402)

***

### Operation

> **Operation** = \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L569)

***

### Participant

> **Participant** = \{ `NeuronsFund`: [`NeuronsFund`](#neuronsfund); \} \| \{ `Direct`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L577)

***

### PreciseValue

> **PreciseValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`PreciseValue`](#precisevalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`PreciseValue`](#precisevalue)[]; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L603)

This type is equivalant to `ICRC3Value`, but we give it another name since it is used here not
in the context of the ICRC-3 ledger standard. The justification is the same: The candid format
supports sharing information even when the client and the server involved do not have the same
schema (see the Upgrading and subtyping section of the candid spec). While this mechanism allows
to evolve services and clients independently without breaking them, it also means that a client
may not receive all the information that the server is sending, e.g. in case the client schema
lacks some fields that the server schema has.

This loss of information is not an option for SNS voters deciding if an extension with particular
init args should be installed or if an extension function with particular arguments should be
called. The client must receive the same exact data the server sent in order to verify it.

Verification of a priorly installed extension is done by hashing the extension's init arg data
and checking that the result is consistent with what has been certified by the SNS.

***

### Result

> **Result** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Neuron`: [`Neuron`](#neuron); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L674)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Proposal`: [`ProposalData`](#proposaldata); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:675](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L675)

***

### Topic

> **Topic** = \{ `DappCanisterManagement`: `null`; \} \| \{ `DaoCommunitySettings`: `null`; \} \| \{ `ApplicationBusinessLogic`: `null`; \} \| \{ `CriticalDappOperations`: `null`; \} \| \{ `TreasuryAssetManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsFrameworkManagement`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L754)

***

### Wasm

> **Wasm** = \{ `Chunked`: [`ChunkedCanisterWasm`](#chunkedcanisterwasm); \} \| \{ `Bytes`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L909)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L948)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance.d.ts#L949)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
