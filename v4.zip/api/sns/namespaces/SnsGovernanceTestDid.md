---
title: SnsGovernanceTestDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L928)

#### Properties

##### add\_maturity

> **add\_maturity**: `ActorMethod`\<\[[`AddMaturityRequest`](#addmaturityrequest)\], [`AddMaturityResponse`](#addmaturityresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L932)

The following are methods for feature = "test"

##### advance\_target\_version

> **advance\_target\_version**: `ActorMethod`\<\[[`AdvanceTargetVersionRequest`](#advancetargetversionrequest)\], [`AdvanceTargetVersionResponse`](#advancetargetversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L933)

##### claim\_swap\_neurons

> **claim\_swap\_neurons**: `ActorMethod`\<\[[`ClaimSwapNeuronsRequest`](#claimswapneuronsrequest)\], [`ClaimSwapNeuronsResponse`](#claimswapneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L937)

##### fail\_stuck\_upgrade\_in\_progress

> **fail\_stuck\_upgrade\_in\_progress**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:941](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L941)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:942](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L942)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L943)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[\{ \}\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:944](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L944)

##### get\_metadata

> **get\_metadata**: `ActorMethod`\<\[\{ \}\], [`GetMetadataResponse`](#getmetadataresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:945](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L945)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L946)

##### get\_metrics\_replicated

> **get\_metrics\_replicated**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:947](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L947)

##### get\_mode

> **get\_mode**: `ActorMethod`\<\[\{ \}\], [`GetModeResponse`](#getmoderesponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L948)

##### get\_nervous\_system\_parameters

> **get\_nervous\_system\_parameters**: `ActorMethod`\<\[`null`\], [`NervousSystemParameters`](#nervoussystemparameters)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L949)

##### get\_neuron

> **get\_neuron**: `ActorMethod`\<\[[`GetNeuron`](#getneuron)\], [`GetNeuronResponse`](#getneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:950](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L950)

##### get\_proposal

> **get\_proposal**: `ActorMethod`\<\[[`GetProposal`](#getproposal)\], [`GetProposalResponse`](#getproposalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L951)

##### get\_root\_canister\_status

> **get\_root\_canister\_status**: `ActorMethod`\<\[`null`\], [`CanisterStatusResultV2`](#canisterstatusresultv2)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:952](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L952)

##### get\_running\_sns\_version

> **get\_running\_sns\_version**: `ActorMethod`\<\[\{ \}\], [`GetRunningSnsVersionResponse`](#getrunningsnsversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:953](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L953)

##### get\_sns\_initialization\_parameters

> **get\_sns\_initialization\_parameters**: `ActorMethod`\<\[\{ \}\], [`GetSnsInitializationParametersResponse`](#getsnsinitializationparametersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:954](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L954)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:958](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L958)

##### get\_upgrade\_journal

> **get\_upgrade\_journal**: `ActorMethod`\<\[[`GetUpgradeJournalRequest`](#getupgradejournalrequest)\], [`GetUpgradeJournalResponse`](#getupgradejournalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L959)

##### list\_nervous\_system\_functions

> **list\_nervous\_system\_functions**: `ActorMethod`\<\[\], [`ListNervousSystemFunctionsResponse`](#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:963](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L963)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:967](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L967)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposals`](#listproposals)\], [`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L968)

##### list\_topics

> **list\_topics**: `ActorMethod`\<\[[`ListTopicsRequest`](#listtopicsrequest)\], [`ListTopicsResponse`](#listtopicsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:969](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L969)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuron`](#manageneuron)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:970](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L970)

##### mint\_tokens

> **mint\_tokens**: `ActorMethod`\<\[[`MintTokensRequest`](#minttokensrequest)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:971](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L971)

##### refresh\_cached\_upgrade\_steps

> **refresh\_cached\_upgrade\_steps**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:972](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L972)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:973](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L973)

##### set\_mode

> **set\_mode**: `ActorMethod`\<\[[`SetMode`](#setmode)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:974](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L974)

##### update\_neuron

> **update\_neuron**: `ActorMethod`\<\[[`Neuron`](#neuron)\], \[\] \| \[[`GovernanceError`](#governanceerror)\]\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:975](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L975)

***

### Account

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L15)

***

### AddMaturityRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L51)

The following types are for feature = "test"

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L53)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L52)

***

### AddMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L55)

#### Properties

##### new\_maturity\_e8s

> **new\_maturity\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L56)

***

### AddNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L58)

#### Properties

##### permissions\_to\_add

> **permissions\_to\_add**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L59)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L60)

***

### AdvanceSnsTargetVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L62)

#### Properties

##### new\_target

> **new\_target**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L63)

***

### AdvanceSnsTargetVersionActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L65)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L66)

***

### AdvanceTargetVersionRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L68)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L69)

***

### Amount

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L72)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L73)

***

### Ballot

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L75)

#### Properties

##### cast\_timestamp\_seconds

> **cast\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L77)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L76)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L78)

***

### CachedUpgradeSteps

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L81)

#### Properties

##### requested\_timestamp\_seconds

> **requested\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L84)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L83)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L82)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L86)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L90)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L93)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L87)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L89)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L94)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L92)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L91)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L88)

***

### CanisterUpgradeOptions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L100)

#### Properties

##### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L102)

##### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L101)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L104)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L105)

***

### ChunkedCanisterWasm

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L107)

#### Properties

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L109)

##### store\_canister\_id

> **store\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L110)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L108)

***

### ClaimedSwapNeurons

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L127)

#### Properties

##### swap\_neurons

> **swap\_neurons**: [`SwapNeuron`](#swapneuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L128)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L112)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L113)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L115)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L116)

***

### ClaimSwapNeuronsRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L118)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: \[\] \| \[[`NeuronRecipes`](#neuronrecipes)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L119)

***

### ClaimSwapNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L121)

#### Properties

##### claim\_swap\_neurons\_result

> **claim\_swap\_neurons\_result**: \[\] \| \[[`ClaimSwapNeuronsResult`](#claimswapneuronsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L122)

***

### Configure

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L174)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L175)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L177)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L178)

***

### Decimal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L180)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L181)

***

### DefaultFollowees

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L183)

#### Properties

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L184)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L186)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L192)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L189)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L187)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L191)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L190)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L188)

***

### DeregisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L194)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L195)

##### new\_controllers

> **new\_controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L196)

***

### Disburse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L198)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L200)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L199)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L202)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L204)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L203)

***

### DisburseMaturityInProgress

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L206)

#### Properties

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L209)

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L208)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L210)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L207)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L212)

#### Properties

##### amount\_deducted\_e8s

> **amount\_deducted\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L214)

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L213)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L216)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L217)

***

### ExecuteExtensionOperation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L222)

#### Properties

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L223)

##### operation\_arg

> **operation\_arg**: \[\] \| \[[`ExtensionOperationArg`](#extensionoperationarg)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L225)

##### operation\_name

> **operation\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L224)

***

### ExecuteGenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L227)

#### Properties

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L228)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L229)

***

### ExtensionInit

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L231)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L232)

***

### ExtensionOperationArg

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L234)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L235)

***

### ExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L237)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L240)

##### extension\_type

> **extension\_type**: \[\] \| \[[`ExtensionType`](#extensiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L241)

##### operation\_type

> **operation\_type**: \[\] \| \[[`ExtensionOperationType`](#extensionoperationtype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L239)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L238)

***

### ExtensionUpgradeArg

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L247)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L248)

***

### FinalizeDisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L250)

#### Properties

##### amount\_to\_be\_disbursed\_e8s

> **amount\_to\_be\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L251)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L252)

***

### Follow

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L254)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L256)

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L255)

***

### Followee

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L258)

#### Properties

##### alias

> **alias**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L259)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L260)

***

### Followees

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L262)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L263)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L265)

#### Properties

##### followees

> **followees**: [`Followee`](#followee)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L267)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L266)

***

### GenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L272)

#### Properties

##### target\_canister\_id

> **target\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L275)

##### target\_method\_name

> **target\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L277)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L273)

##### validator\_canister\_id

> **validator\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L274)

##### validator\_method\_name

> **validator\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L276)

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L279)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L280)

***

### GetMetadataResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L282)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L286)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L284)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L285)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L283)

***

### GetMetricsRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L288)

#### Properties

##### time\_window\_seconds

> **time\_window\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L289)

***

### GetMetricsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L291)

#### Properties

##### get\_metrics\_result

> **get\_metrics\_result**: \[\] \| \[[`GetMetricsResult`](#getmetricsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L292)

***

### GetModeResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L295)

#### Properties

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L296)

***

### GetNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L298)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L299)

***

### GetNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L301)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L302)

***

### GetProposal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L304)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L305)

***

### GetProposalResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L307)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L308)

***

### GetRunningSnsVersionResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L310)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L311)

##### pending\_version

> **pending\_version**: \[\] \| \[\{ `checking_upgrade_lock`: `bigint`; `mark_failed_at_seconds`: `bigint`; `proposal_id`: `bigint`; `target_version`: \[\] \| \[[`Version`](#version)\]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L312)

***

### GetSnsInitializationParametersResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L323)

#### Properties

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L324)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L326)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L327)

***

### GetUpgradeJournalRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L329)

#### Properties

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L331)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L330)

***

### GetUpgradeJournalResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L333)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L337)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L336)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L338)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L334)

##### upgrade\_journal\_entry\_count

> **upgrade\_journal\_entry\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L339)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L335)

***

### Governance

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L341)

#### Properties

##### cached\_upgrade\_steps

> **cached\_upgrade\_steps**: \[\] \| \[[`CachedUpgradeSteps`](#cachedupgradesteps)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L344)

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L352)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L363)

##### id\_to\_nervous\_system\_functions

> **id\_to\_nervous\_system\_functions**: \[`bigint`, [`NervousSystemFunction`](#nervoussystemfunction)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L345)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`string`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L359)

##### is\_finalizing\_disburse\_maturity

> **is\_finalizing\_disburse\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L351)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L354)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L357)

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L347)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L346)

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L349)

##### neurons

> **neurons**: \[`string`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L361)

##### parameters

> **parameters**: \[\] \| \[[`NervousSystemParameters`](#nervoussystemparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L350)

##### pending\_version

> **pending\_version**: \[\] \| \[[`PendingVersion`](#pendingversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L355)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L358)

##### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L342)

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L353)

##### sns\_metadata

> **sns\_metadata**: \[\] \| \[[`ManageSnsMetadata`](#managesnsmetadata)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L360)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L356)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L362)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L343)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L348)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L365)

#### Properties

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L372)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L377)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L380)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L379)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L381)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L368)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L369)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L371)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L378)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L376)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L370)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L367)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L382)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L373)

##### total\_supply\_governance\_tokens

> **total\_supply\_governance\_tokens**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L374)

##### treasury\_metrics

> **treasury\_metrics**: [`TreasuryMetrics`](#treasurymetrics)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L366)

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L375)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L384)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L385)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L386)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L388)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L389)

***

### ListNervousSystemFunctionsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L391)

#### Properties

##### functions

> **functions**: [`NervousSystemFunction`](#nervoussystemfunction)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L393)

##### reserved\_ids

> **reserved\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L392)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L395)

#### Properties

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L397)

##### of\_principal

> **of\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L396)

##### start\_page\_at

> **start\_page\_at**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L398)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L400)

#### Properties

##### neurons

> **neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L401)

***

### ListProposals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L403)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L405)

##### exclude\_type

> **exclude\_type**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L407)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L404)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L409)

##### include\_topics

> **include\_topics**: \[\] \| \[[`TopicSelector`](#topicselector)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L408)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L406)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L411)

#### Properties

##### include\_ballots\_by\_caller

> **include\_ballots\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L412)

##### include\_topic\_filtering

> **include\_topic\_filtering**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L414)

##### proposals

> **proposals**: [`ProposalData`](#proposaldata)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L413)

***

### ListTopicsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L417)

#### Properties

##### topics

> **topics**: \[\] \| \[[`TopicInfo`](#topicinfo)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L419)

##### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L418)

***

### ManageDappCanisterSettings

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L421)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L424)

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L430)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L422)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L426)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L429)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L425)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L427)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L428)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L423)

***

### ManageLedgerParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L432)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L435)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L436)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L433)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L434)

***

### ManageNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L438)

#### Properties

##### command

> **command**: \[\] \| \[[`Command`](#command-3)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L440)

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L439)

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L442)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L443)

***

### ManageSnsMetadata

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L445)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L449)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L447)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L448)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L446)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L451)

#### Properties

##### current\_basis\_points

> **current\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L452)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L453)

***

### MemoAndController

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L455)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L456)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L457)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L459)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L462)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L467)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L466)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L464)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L463)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L460)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L461)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L465)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L469)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L470)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L472)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L473)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L474)

***

### Metrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L476)

#### Properties

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L485)

##### last\_ledger\_block\_timestamp

> **last\_ledger\_block\_timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L482)

##### num\_recently\_executed\_proposals

> **num\_recently\_executed\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L483)

##### num\_recently\_submitted\_proposals

> **num\_recently\_submitted\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L484)

##### treasury\_metrics

> **treasury\_metrics**: \[\] \| \[[`TreasuryMetrics`](#treasurymetrics)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L480)

The metrics below are cached (albeit this is an implementation detail).

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L481)

***

### MintSnsTokens

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L487)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L491)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L490)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L488)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L489)

***

### MintSnsTokensActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L493)

#### Properties

##### valuation

> **valuation**: \[\] \| \[[`Valuation`](#valuation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L494)

***

### MintTokensRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L496)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L498)

##### recipient

> **recipient**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L497)

***

### Motion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L500)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L501)

***

### NervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L503)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L506)

##### function\_type

> **function\_type**: \[\] \| \[[`FunctionType`](#functiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L507)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L504)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L505)

***

### NervousSystemParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L509)

#### Properties

##### automatically\_advance\_target\_version

> **automatically\_advance\_target\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L514)

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L525)

##### default\_followees

> **default\_followees**: \[\] \| \[[`DefaultFollowees`](#defaultfollowees)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L510)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L518)

##### maturity\_modulation\_disabled

> **maturity\_modulation\_disabled**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L530)

##### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L527)

##### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L512)

##### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L511)

##### max\_followees\_per\_function

> **max\_followees\_per\_function**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L513)

##### max\_neuron\_age\_for\_age\_bonus

> **max\_neuron\_age\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L517)

##### max\_number\_of\_neurons

> **max\_number\_of\_neurons**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L523)

##### max\_number\_of\_principals\_per\_neuron

> **max\_number\_of\_principals\_per\_neuron**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L531)

##### max\_number\_of\_proposals\_with\_ballots

> **max\_number\_of\_proposals\_with\_ballots**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L526)

##### max\_proposals\_to\_keep\_per\_action

> **max\_proposals\_to\_keep\_per\_action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L521)

##### neuron\_claimer\_permissions

> **neuron\_claimer\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L515)

##### neuron\_grantable\_permissions

> **neuron\_grantable\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L528)

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L519)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L516)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L520)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L524)

##### voting\_rewards\_parameters

> **voting\_rewards\_parameters**: \[\] \| \[[`VotingRewardsParameters`](#votingrewardsparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L529)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L522)

***

### Neuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L533)

#### Properties

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L545)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L544)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L538)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L539)

##### disburse\_maturity\_in\_progress

> **disburse\_maturity\_in\_progress**: [`DisburseMaturityInProgress`](#disbursematurityinprogress)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L550)

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L547)

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L551)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L534)

##### latest\_reward\_event\_participation

> **latest\_reward\_event\_participation**: \[\] \| \[[`RewardEventParticipation`](#rewardeventparticipation)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L546)

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L537)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L552)

##### permissions

> **permissions**: [`NeuronPermission`](#neuronpermission)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L536)

##### source\_nns\_neuron\_id

> **source\_nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L543)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L535)

##### topic\_followees

> **topic\_followees**: \[\] \| \[\{ `topic_id_to_followees`: \[`number`, [`FolloweesForTopic`](#followeesfortopic)\][]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L540)

##### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L549)

##### voting\_power\_percentage\_multiplier

> **voting\_power\_percentage\_multiplier**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L548)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L554)

#### Properties

##### id

> **id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L555)

***

### NeuronIds

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L557)

#### Properties

##### neuron\_ids

> **neuron\_ids**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L558)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L560)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L561)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L562)

***

### NeuronPermission

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L564)

#### Properties

##### permission\_type

> **permission\_type**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L566)

##### principal

> **principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L565)

***

### NeuronPermissionList

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L568)

#### Properties

##### permissions

> **permissions**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L569)

***

### NeuronRecipe

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L571)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L572)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L573)

##### followees

> **followees**: \[\] \| \[[`NeuronIds`](#neuronids)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L576)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L577)

##### participant

> **participant**: \[\] \| \[[`Participant`](#participant-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L574)

##### stake\_e8s

> **stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L575)

***

### NeuronRecipes

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L579)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: [`NeuronRecipe`](#neuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L580)

***

### NeuronsFund

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L582)

#### Properties

##### nns\_neuron\_controller

> **nns\_neuron\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L584)

##### nns\_neuron\_hotkeys

> **nns\_neuron\_hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:583](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L583)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L585)

***

### PendingVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L596)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L598)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L597)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:599](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L599)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L600)

***

### Percentage

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L602)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L603)

***

### Principals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L629)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L630)

***

### Proposal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L632)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L635)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L636)

##### title

> **title**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L634)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L633)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L638)

#### Properties

##### action

> **action**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L643)

##### action\_auxiliary

> **action\_auxiliary**: \[\] \| \[[`ActionAuxiliary`](#actionauxiliary)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L645)

##### ballots

> **ballots**: \[`string`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L646)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L656)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L662)

##### execution\_reply

> **execution\_reply**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L642)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L649)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L644)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:639](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L639)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L652)

##### is\_eligible\_for\_rewards

> **is\_eligible\_for\_rewards**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L661)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L654)

##### minimum\_yes\_proportion\_of\_exercised

> **minimum\_yes\_proportion\_of\_exercised**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:660](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L660)

##### minimum\_yes\_proportion\_of\_total

> **minimum\_yes\_proportion\_of\_total**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L647)

##### payload\_text\_rendering

> **payload\_text\_rendering**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L640)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L657)

##### proposal\_creation\_timestamp\_seconds

> **proposal\_creation\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L651)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L658)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L653)

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L650)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L648)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L641)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:655](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L655)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L659)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L664)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:665](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L665)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L667)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L670)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:669](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L669)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L671)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L668)

***

### RegisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:673](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L673)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L674)

***

### RegisteredExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:684](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L684)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L686)

##### spec

> **spec**: \[\] \| \[[`ExtensionOperationSpec`](#extensionoperationspec)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L685)

***

### RegisterExtension

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L676)

#### Properties

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L677)

##### extension\_init

> **extension\_init**: \[\] \| \[[`ExtensionInit`](#extensioninit)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L678)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L680)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L682)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L681)

***

### RemoveNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L688)

#### Properties

##### permissions\_to\_remove

> **permissions\_to\_remove**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L689)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:690](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L690)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L694)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:696](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L696)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L699)

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:697](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L697)

##### round

> **round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:700](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L700)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:695](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L695)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:701](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L701)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:698](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L698)

***

### RewardEventParticipation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:703](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L703)

#### Properties

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L704)

##### reward\_shares

> **reward\_shares**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:705](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L705)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:707](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L707)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:708](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L708)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L710)

#### Properties

##### topic\_following

> **topic\_following**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L711)

***

### SetMode

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L713)

#### Properties

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:714](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L714)

***

### SetTopicsForCustomProposals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:716](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L716)

#### Properties

##### custom\_function\_id\_to\_topic

> **custom\_function\_id\_to\_topic**: \[`bigint`, [`Topic`](#topic-6)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L717)

***

### SnsVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:719](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L719)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:720](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L720)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L724)

##### index\_wasm\_hash

> **index\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L725)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L723)

##### root\_wasm\_hash

> **root\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L721)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L722)

***

### Split

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L727)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L729)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L728)

***

### SplitResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L731)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L732)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L734)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:735](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L735)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L737)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L738)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L739)

***

### Subaccount

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L741)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L742)

***

### SwapNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L744)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L745)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L746)

***

### Tally

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L748)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L749)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L752)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L751)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:750](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L750)

***

### TargetVersionReset

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L754)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L755)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L757)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L756)

***

### TargetVersionSet

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L759)

#### Properties

##### is\_advanced\_automatically

> **is\_advanced\_automatically**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L762)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L761)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:760](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L760)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L764)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L766)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:765](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L765)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L767)

***

### Tokens

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L769)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:770](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L770)

***

### TopicInfo

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:780](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L780)

#### Properties

##### custom\_functions

> **custom\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L787)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L786)

##### extension\_operations

> **extension\_operations**: \[\] \| \[[`RegisteredExtensionOperationSpec`](#registeredextensionoperationspec)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:781](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L781)

##### is\_critical

> **is\_critical**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L784)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L785)

##### native\_functions

> **native\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L782)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L783)

***

### TopicSelector

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:789](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L789)

#### Properties

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:790](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L790)

***

### TransferSnsTreasuryFunds

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:792](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L792)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L797)

##### from\_treasury

> **from\_treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L793)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:796](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L796)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:794](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L794)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:795](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L795)

***

### TreasuryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:799](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L799)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:812](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L812)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L811)

The regularly updated amount of tokens in this treasury.

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:816](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L816)

The source of truth for the treasury balance is this ledger canister / account.

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:803](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L803)

A human-readable identified for this treasury, e.g., "ICP".

##### original\_amount\_e8s

> **original\_amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L807)

The amount of tokens in this treasury at the end of swap finalization.

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:824](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L824)

When the metrics were last updated.

##### treasury

> **treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:820](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L820)

Same as, e.g., `TransferSnsTreasuryFunds.from_treasury`.

***

### UpgradeExtension

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:826](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L826)

#### Properties

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[[`ExtensionUpgradeArg`](#extensionupgradearg)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:829](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L829)

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:827](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L827)

##### wasm

> **wasm**: \[\] \| \[[`Wasm`](#wasm-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:828](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L828)

***

### UpgradeInProgress

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:831](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L831)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:833](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L833)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:832](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L832)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:834](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L834)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:835](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L835)

***

### UpgradeJournal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:837](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L837)

#### Properties

##### entries

> **entries**: [`UpgradeJournalEntry`](#upgradejournalentry)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:838](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L838)

***

### UpgradeJournalEntry

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L840)

#### Properties

##### event

> **event**: \[\] \| \[\{ `TargetVersionSet`: [`TargetVersionSet`](#targetversionset); \} \| \{ `UpgradeStepsReset`: [`UpgradeStepsReset`](#upgradestepsreset); \} \| \{ `UpgradeOutcome`: [`UpgradeOutcome`](#upgradeoutcome); \} \| \{ `UpgradeStarted`: [`UpgradeStarted`](#upgradestarted); \} \| \{ `UpgradeStepsRefreshed`: [`UpgradeStepsRefreshed`](#upgradestepsrefreshed); \} \| \{ `TargetVersionReset`: [`TargetVersionReset`](#targetversionreset); \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L841)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:851](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L851)

***

### UpgradeOutcome

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L853)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:862](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L862)

##### status

> **status**: \[\] \| \[\{ `Success`: \{ \}; \} \| \{ `Timeout`: \{ \}; \} \| \{ `ExternalFailure`: \{ \}; \} \| \{ `InvalidState`: \{ `version`: \[\] \| \[[`Version`](#version)\]; \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L854)

***

### UpgradeSnsControlledCanister

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L864)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:867](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L867)

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:870](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L870)

##### canister\_upgrade\_options

> **canister\_upgrade\_options**: \[\] \| \[[`CanisterUpgradeOptions`](#canisterupgradeoptions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L868)

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L869)

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:866](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L866)

##### new\_canister\_wasm

> **new\_canister\_wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:865](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L865)

***

### UpgradeStarted

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L872)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L873)

##### expected\_version

> **expected\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L874)

##### reason

> **reason**: \[\] \| \[\{ `UpgradeSnsToNextVersionProposal`: [`ProposalId`](#proposalid); \} \| \{ `BehindTargetVersion`: \{ \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L875)

***

### UpgradeStepsRefreshed

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L882)

#### Properties

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L883)

***

### UpgradeStepsReset

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L885)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L886)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L887)

***

### Valuation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L889)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L891)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L893)

##### token

> **token**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L890)

##### valuation\_factors

> **valuation\_factors**: \[\] \| \[[`ValuationFactors`](#valuationfactors)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L892)

***

### ValuationFactors

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L895)

#### Properties

##### icps\_per\_token

> **icps\_per\_token**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:897](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L897)

##### tokens

> **tokens**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L898)

##### xdrs\_per\_icp

> **xdrs\_per\_icp**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:896](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L896)

***

### Version

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L900)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L901)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L905)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L906)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:904](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L904)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L902)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:903](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L903)

***

### Versions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L908)

#### Properties

##### versions

> **versions**: [`Version`](#version)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L909)

***

### VotingPowerMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L911)

#### Properties

##### governance\_total\_potential\_voting\_power

> **governance\_total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:912](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L912)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L916)

When the metrics were last updated.

***

### VotingRewardsParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L918)

#### Properties

##### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L919)

##### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L920)

##### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:921](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L921)

##### round\_duration\_seconds

> **round\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L922)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:924](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L924)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:925](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L925)

## Type Aliases

### Action

> **Action** = \{ `ManageNervousSystemParameters`: [`NervousSystemParameters`](#nervoussystemparameters); \} \| \{ `AddGenericNervousSystemFunction`: [`NervousSystemFunction`](#nervoussystemfunction); \} \| \{ `ManageDappCanisterSettings`: [`ManageDappCanisterSettings`](#managedappcanistersettings); \} \| \{ `ExecuteExtensionOperation`: [`ExecuteExtensionOperation`](#executeextensionoperation); \} \| \{ `UpgradeExtension`: [`UpgradeExtension`](#upgradeextension); \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: [`SetTopicsForCustomProposals`](#settopicsforcustomproposals); \} \| \{ `RegisterExtension`: [`RegisterExtension`](#registerextension); \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: [`RegisterDappCanisters`](#registerdappcanisters); \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](#transfersnstreasuryfunds); \} \| \{ `UpgradeSnsControlledCanister`: [`UpgradeSnsControlledCanister`](#upgradesnscontrolledcanister); \} \| \{ `DeregisterDappCanisters`: [`DeregisterDappCanisters`](#deregisterdappcanisters); \} \| \{ `MintSnsTokens`: [`MintSnsTokens`](#mintsnstokens); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersion`](#advancesnstargetversion); \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: [`ManageSnsMetadata`](#managesnsmetadata); \} \| \{ `ExecuteGenericNervousSystemFunction`: [`ExecuteGenericNervousSystemFunction`](#executegenericnervoussystemfunction); \} \| \{ `ManageLedgerParameters`: [`ManageLedgerParameters`](#manageledgerparameters); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L17)

***

### ActionAuxiliary

> **ActionAuxiliary** = \{ `TransferSnsTreasuryFunds`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `MintSnsTokens`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersionActionAuxiliary`](#advancesnstargetversionactionauxiliary); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L42)

***

### AdvanceTargetVersionResponse

> **AdvanceTargetVersionResponse** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L71)

***

### By

> **By** = \{ `MemoAndController`: [`MemoAndController`](#memoandcontroller); \} \| \{ `NeuronId`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L80)

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L96)

***

### ClaimSwapNeuronsResult

> **ClaimSwapNeuronsResult** = \{ `Ok`: [`ClaimedSwapNeurons`](#claimedswapneurons); \} \| \{ `Err`: `number`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L124)

***

### Command

> **Command** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L130)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Split`: [`SplitResponse`](#splitresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `SetFollowing`: \{ \}; \} \| \{ `MakeProposal`: [`GetProposal`](#getproposal); \} \| \{ `RemoveNeuronPermission`: \{ \}; \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \} \| \{ `AddNeuronPermission`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L144)

***

### Command\_2

> **Command\_2** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `FinalizeDisburseMaturity`: [`FinalizeDisburseMaturity`](#finalizedisbursematurity); \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L159)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L219)

***

### ExtensionOperationType

> **ExtensionOperationType** = \{ `TreasuryManagerWithdraw`: `null`; \} \| \{ `TreasuryManagerDeposit`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L243)

***

### ExtensionType

> **ExtensionType** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L246)

#### Properties

##### TreasuryManager

> **TreasuryManager**: `null`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L246)

***

### FunctionType

> **FunctionType** = \{ `NativeNervousSystemFunction`: \{ \}; \} \| \{ `GenericNervousSystemFunction`: [`GenericNervousSystemFunction`](#genericnervoussystemfunction); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L269)

***

### GetMetricsResult

> **GetMetricsResult** = \{ `Ok`: [`Metrics`](#metrics-1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L294)

***

### ListTopicsRequest

> **ListTopicsRequest** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L416)

***

### Operation

> **Operation** = \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L587)

***

### Participant

> **Participant** = \{ `NeuronsFund`: [`NeuronsFund`](#neuronsfund); \} \| \{ `Direct`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L595)

***

### PreciseValue

> **PreciseValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`PreciseValue`](#precisevalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`PreciseValue`](#precisevalue)[]; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L621)

This type is equivalant to `ICRC3Value`, but we give it another name since it is used here not
in the context of the ICRC-3 ledger standard. The justification is the same: The candid format
supports sharing information even when the client and the server involved do not have the same
schema (see the Upgrading and subtyping section of the candid spec). While this mechanism allows
to evolve services and clients independently without breaking them, it also means that a client
may not receive all the information that the server is sending, e.g. in case the client schema
lacks some fields that the server schema has.

This loss of information is not an option for SNS voters deciding if an extension with particular
init args should be installed or if an extension function with particular arguments should be
called. The client must receive the same exact data the server sent in order to verify it.

Verification of a priorly installed extension is done by hashing the extension's init arg data
and checking that the result is consistent with what has been certified by the SNS.

***

### Result

> **Result** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Neuron`: [`Neuron`](#neuron); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L692)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Proposal`: [`ProposalData`](#proposaldata); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L693)

***

### Topic

> **Topic** = \{ `DappCanisterManagement`: `null`; \} \| \{ `DaoCommunitySettings`: `null`; \} \| \{ `ApplicationBusinessLogic`: `null`; \} \| \{ `CriticalDappOperations`: `null`; \} \| \{ `TreasuryAssetManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsFrameworkManagement`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L772)

***

### Wasm

> **Wasm** = \{ `Chunked`: [`ChunkedCanisterWasm`](#chunkedcanisterwasm); \} \| \{ `Bytes`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L927)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:977](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L977)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:978](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/sns/governance_test.d.ts#L978)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
