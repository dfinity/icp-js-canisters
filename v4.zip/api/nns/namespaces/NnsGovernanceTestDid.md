---
title: NnsGovernanceTestDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1491](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1491)

#### Properties

##### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](#neuronid-1)[]\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1492](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1492)

##### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount)\], [`ClaimOrRefreshNeuronFromAccountResponse`](#claimorrefreshneuronfromaccountresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1493](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1493)

##### create\_neuron

> **create\_neuron**: `ActorMethod`\<\[[`CreateNeuronRequest`](#createneuronrequest)\], [`CreateNeuronResponse`](#createneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1497](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1497)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1498](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1498)

##### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1499](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1499)

##### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1500)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1504](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1504)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[[`GetMaturityModulationRequest`](#getmaturitymodulationrequest)\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1505](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1505)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](#result_3)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1509](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1509)

##### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](#result_4)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1510](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1510)

##### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1511](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1511)

##### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](#networkeconomics)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1515](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1515)

##### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1516](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1516)

##### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](#getneuronindexrequest)\], [`GetNeuronIndexResult`](#getneuronindexresult)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1517](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1517)

##### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1518](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1518)

##### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1519](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1519)

##### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](#getneuronsfundauditinforequest)\], [`GetNeuronsFundAuditInfoResponse`](#getneuronsfundauditinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1523](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1523)

##### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](#result_7)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1527](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1527)

##### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](#getpendingproposalsrequest)\]\], [`ProposalInfo`](#proposalinfo)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1528](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1528)

##### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](#proposalinfo)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1532](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1532)

##### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](#restoreagingsummary)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1533](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1533)

##### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](#listknownneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1534](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1534)

##### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](#listneuronvotesrequest)\], [`ListNeuronVotesResponse`](#listneuronvotesresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1535](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1535)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1539](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1539)

##### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](#listnodeproviderrewardsrequest)\], [`ListNodeProviderRewardsResponse`](#listnodeproviderrewardsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1540](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1540)

##### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](#listnodeprovidersresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1544](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1544)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](#listproposalinforequest)\], [`ListProposalInfoResponse`](#listproposalinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1545](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1545)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1549](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1549)

##### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](#settlecommunityfundparticipation)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1550](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1550)

##### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](#settleneuronsfundparticipationrequest)\], [`SettleNeuronsFundParticipationResponse`](#settleneuronsfundparticipationresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1554](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1554)

##### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1558](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1558)

##### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](#neuronid-1), [`NeuronId`](#neuronid-1)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1562](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1562)

##### update\_neuron

> **update\_neuron**: `ActorMethod`\<\[[`Neuron`](#neuron)\], \[\] \| \[[`GovernanceError`](#governanceerror)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1566](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1566)

The following are methods for feature = "test"

##### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](#updatenodeprovider)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1567](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1567)

***

### Account

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L15)

***

### AccountIdentifier

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L17)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L18)

***

### AddHotKey

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L46)

#### Properties

##### new\_hot\_key

> **new\_hot\_key**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L47)

***

### AddOrRemoveNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L49)

#### Properties

##### change

> **change**: \[\] \| \[[`Change`](#change-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L50)

***

### Amount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L52)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L53)

***

### ApproveGenesisKyc

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L55)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L56)

***

### Ballot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L58)

#### Properties

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L59)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L60)

***

### BallotInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L62)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L64)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L63)

***

### BlessAlternativeGuestOsVersion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L70)

Declares an approved set of alternative replica virtual machine software for
disaster recovery purposes.

#### Properties

##### base\_guest\_launch\_measurements

> **base\_guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurements`](#guestlaunchmeasurements)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L87)

The version being replaced by this (alternative version) must match this
field (or one of the possibilities therein).

(Here, we refer to the version being replaced as the "base" version.)

##### chip\_ids

> **chip\_ids**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L80)

AMD Secure Processor chip IDs that are allowed to run this software.
Each chip ID must be exactly 64 bytes.

##### rootfs\_hash

> **rootfs\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L75)

Hexadecimal fingerprint of the recovery rootfs.
Must contain only hexadecimal characters (0-9, A-F, a-f).

***

### Canister

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L93)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L94)

***

### CanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L96)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L105)

##### controllers

> **controllers**: \[\] \| \[[`Controllers`](#controllers-2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L99)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L97)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L101)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L104)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L100)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L102)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L103)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L98)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L107)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L110)

##### cycles

> **cycles**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L112)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L109)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L113)

##### memory\_size

> **memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L111)

##### module\_hash

> **module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L114)

##### status

> **status**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L108)

***

### CanisterSummary

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L116)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L118)

##### status

> **status**: \[\] \| \[[`CanisterStatusResultV2`](#canisterstatusresultv2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L117)

***

### CanisterUpgradeOptions

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L120)

#### Properties

##### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L122)

##### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L121)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L125)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L126)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L128)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L129)

***

### ClaimOrRefreshNeuronFromAccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L131)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L132)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L133)

***

### ClaimOrRefreshNeuronFromAccountResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L135)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L136)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L138)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L139)

***

### Committed

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L168)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L171)

##### total\_direct\_contribution\_icp\_e8s

> **total\_direct\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L169)

##### total\_neurons\_fund\_contribution\_icp\_e8s

> **total\_neurons\_fund\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L170)

***

### Committed\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L173)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L176)

##### total\_direct\_participation\_icp\_e8s

> **total\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L174)

##### total\_neurons\_fund\_participation\_icp\_e8s

> **total\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L175)

***

### Configure

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L178)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L179)

***

### Controllers

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L181)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L182)

***

### Countries

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L184)

#### Properties

##### iso\_codes

> **iso\_codes**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L185)

***

### CreateCanisterAndInstallCode

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L187)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L189)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L191)

##### install\_arg\_hash

> **install\_arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L190)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L188)

***

### CreateCanisterAndInstallCodeOk

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L193)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L194)

***

### CreateCanisterAndInstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L196)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L198)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L200)

##### install\_arg

> **install\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L199)

##### wasm\_module

> **wasm\_module**: \[\] \| \[[`WasmModule`](#wasmmodule)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L197)

***

### CreatedNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L251)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L252)

***

### CreateNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L206)

Request to create a new neuron using ICRC-2 transfer_from.
The caller must have previously approved the governance canister to spend the specified amount.

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L226)

Required. The amount of ICP to stake in e8s.

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L222)

Whether to automatically stake maturity. Defaults to false.

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L210)

The controller of the new neuron. Defaults to the caller.

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L218)

The dissolve delay in seconds. Defaults to 7 days. Clamped to [0, 8 years].

##### dissolving

> **dissolving**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L234)

Whether the neuron should start dissolving immediately. Defaults to false.

##### followees

> **followees**: \[\] \| \[[`SetFollowing`](#setfollowing)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L230)

The followees to set for the new neuron. Defaults to the network's default followees.

##### source\_subaccount

> **source\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L214)

The subaccount of the caller to transfer ICP from. Defaults to the default subaccount.

***

### CreateServiceNervousSystem

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L239)

#### Properties

##### dapp\_canisters

> **dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L247)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L246)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L242)

##### governance\_parameters

> **governance\_parameters**: \[\] \| \[[`GovernanceParameters`](#governanceparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L241)

##### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](#initialtokendistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L249)

##### ledger\_parameters

> **ledger\_parameters**: \[\] \| \[[`LedgerParameters`](#ledgerparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L245)

##### logo

> **logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L243)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L244)

##### swap\_parameters

> **swap\_parameters**: \[\] \| \[[`SwapParameters`](#swapparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L248)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L240)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L254)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: \[\] \| \[`BigUint64Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L255)

***

### DateRangeFilter

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L257)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L259)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L258)

***

### DateUtc

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L261)

#### Properties

##### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L262)

##### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L263)

##### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L264)

***

### Decimal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L266)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L267)

***

### DeregisterKnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L269)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L270)

***

### DerivedProposalInformation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L272)

#### Properties

##### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](#swapbackgroundinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L273)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L275)

#### Properties

##### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L276)

***

### Disburse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L278)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L280)

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L279)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L282)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L285)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L284)

##### to\_account\_identifier

> **to\_account\_identifier**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L283)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L287)

#### Properties

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L288)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L290)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L291)

***

### DisburseToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L293)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L296)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L294)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L295)

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L297)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L298)

***

### Duration

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L303)

#### Properties

##### seconds

> **seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L304)

***

### ExecuteNnsFunction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L306)

#### Properties

##### nns\_function

> **nns\_function**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L307)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L308)

***

### Follow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L310)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L312)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L311)

***

### Followees

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L314)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L315)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L317)

#### Properties

##### followees

> **followees**: \[\] \| \[[`NeuronId`](#neuronid-1)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L319)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L318)

***

### FulfillSubnetRentalRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L325)

Creates a rented subnet from a rental request (in the Subnet Rental
canister).

#### Properties

##### initial\_dkg\_subnet\_id

> **initial\_dkg\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L330)

Optional subnet that should handle `setup_initial_dkg` for subnet creation.
If not set, handling defaults to the NNS subnet.

##### node\_ids

> **node\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L361)

Which nodes will be members of the subnet.

##### replica\_version\_id

> **replica\_version\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L357)

What software the nodes will run.

This must be approved by a prior proposal to bless an IC OS version.

This is a FULL git commit ID in the ic repo. (Therefore, it must be a 40
character hexidecimal string, not an abbreviated git commit ID.)

One way to find a suitable value is with the following command:

ic-admin \
get-subnet 0 \
--nns-urls https://nns.ic0.app \
| grep replica_version_id

Where to obtain a recent version of ic-admin:

https://github.com/dfinity/ic/releases/latest

##### user

> **user**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L337)

Identifies which rental request to fulfill.

(Identifying the rental request by user works, because a user can have at
most one rental request in the Subnet Rental canister).

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L364)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L365)

***

### GetNeuronIndexRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L367)

#### Properties

##### exclusive\_start\_neuron\_id

> **exclusive\_start\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L369)

##### page\_size

> **page\_size**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L368)

***

### GetNeuronsFundAuditInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L374)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L375)

***

### GetNeuronsFundAuditInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L377)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_6`](#result_6)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L378)

***

### GetPendingProposalsRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L380)

#### Properties

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L381)

***

### GlobalTimeOfDay

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L383)

#### Properties

##### seconds\_after\_utc\_midnight

> **seconds\_after\_utc\_midnight**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L384)

***

### Governance

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L386)

#### Properties

##### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L394)

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L387)

##### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](#networkeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L395)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L405)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L403)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L398)

##### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L389)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L391)

##### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L388)

##### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L392)

##### neurons

> **neurons**: \[`bigint`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L404)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L393)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L401)

##### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](#restoreagingsummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L396)

##### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L400)

##### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L397)

##### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](#neuronstaketransfer)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L399)

##### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L390)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L402)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L407)

#### Properties

##### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L421)

##### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L459)

##### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L441)

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L420)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L444)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L456)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L451)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L457)

##### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L452)

##### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L446)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L412)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L410)

##### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L417)

##### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L433)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L411)

##### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L436)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L415)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L419)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L447)

##### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L453)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L434)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L416)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L409)

##### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L439)

##### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L460)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L448)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L443)

##### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L461)

##### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L463)

##### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L440)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L462)

##### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L435)

##### total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent

> **total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L431)

SDK DIVERGENCE: the backend declares this as `nat64` (required) since
ic@3ef6b6f876 (2026-03-06). We keep it `opt nat64` here so the SDK can
still decode responses from canister versions (e.g. bundled dfx wasms,
rolling-release mainnet) that predate the field. Revert to `nat64` once
every consumed canister version is guaranteed to include it.

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L408)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L432)

##### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L442)

##### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L445)

##### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L422)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L438)

##### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L423)

##### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L458)

##### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L418)

##### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L437)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L465)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L466)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L467)

***

### GovernanceParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L469)

#### Properties

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L478)

##### neuron\_maximum\_age\_bonus

> **neuron\_maximum\_age\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L474)

##### neuron\_maximum\_age\_for\_age\_bonus

> **neuron\_maximum\_age\_for\_age\_bonus**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L471)

##### neuron\_maximum\_dissolve\_delay

> **neuron\_maximum\_dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L472)

##### neuron\_maximum\_dissolve\_delay\_bonus

> **neuron\_maximum\_dissolve\_delay\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L470)

##### neuron\_minimum\_dissolve\_delay\_to\_vote

> **neuron\_minimum\_dissolve\_delay\_to\_vote**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L473)

##### neuron\_minimum\_stake

> **neuron\_minimum\_stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L475)

##### proposal\_initial\_voting\_period

> **proposal\_initial\_voting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:477](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L477)

##### proposal\_rejection\_fee

> **proposal\_rejection\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L479)

##### proposal\_wait\_for\_quiet\_deadline\_increase

> **proposal\_wait\_for\_quiet\_deadline\_increase**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L476)

##### voting\_reward\_parameters

> **voting\_reward\_parameters**: \[\] \| \[[`VotingRewardParameters`](#votingrewardparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L480)

***

### GuestLaunchMeasurement

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L482)

#### Properties

##### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L490)

SEV-SNP measurement (48 bytes).

##### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](#guestlaunchmeasurementmetadata-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L486)

Metadata associated with the measurement.

***

### GuestLaunchMeasurementMetadata

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L492)

#### Properties

##### kernel\_cmdline

> **kernel\_cmdline**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L496)

Kernel command line used for this measurement.

##### vcpu\_type

> **vcpu\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L500)

Virtual CPU type used for this measurement.

***

### GuestLaunchMeasurements

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L502)

#### Properties

##### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](#guestlaunchmeasurement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L503)

***

### IdealMatchedParticipationFunction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L505)

#### Properties

##### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L506)

***

### Image

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L508)

#### Properties

##### base64\_encoding

> **base64\_encoding**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L509)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L511)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L512)

***

### InitialTokenDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L514)

#### Properties

##### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](#developerdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L516)

##### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L517)

##### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L515)

***

### InstallCode

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L519)

#### Properties

##### arg\_hash

> **arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L523)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L522)

##### canister\_upgrade\_options

> **canister\_upgrade\_options**: \[\] \| \[[`CanisterUpgradeOptions`](#canisterupgradeoptions)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L524)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L525)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L520)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L521)

***

### InstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L527)

#### Properties

##### arg

> **arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L528)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L536)

##### canister\_upgrade\_options

> **canister\_upgrade\_options**: \[\] \| \[[`CanisterUpgradeOptions`](#canisterupgradeoptions)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L537)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L538)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L535)

##### wasm\_module

> **wasm\_module**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L534)

If we add support for chunked WASMs later, the WasmModule type should
probably be used in place of this field in order to be consistent with
CreateCanisterAndInstallCodeRequest.

***

### KnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L540)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L541)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L542)

***

### KnownNeuronData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L544)

#### Properties

##### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](#topictofollow)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L552)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L553)

##### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L557)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L545)

***

### LedgerParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L559)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L562)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L563)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L561)

##### transaction\_fee

> **transaction\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L560)

***

### ListKnownNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L565)

#### Properties

##### known\_neurons

> **known\_neurons**: [`KnownNeuron`](#knownneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L566)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:605](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L605)

Parameters of the list_neurons method.

#### Properties

##### include\_empty\_neurons\_readable\_by\_caller

> **include\_empty\_neurons\_readable\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L621)

Only has an effect when include_neurons_readable_by_caller.

##### include\_neurons\_readable\_by\_caller

> **include\_neurons\_readable\_by\_caller**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L623)

##### include\_public\_neurons\_in\_full\_neurons

> **include\_public\_neurons\_in\_full\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L612)

When a public neuron is a member of the result set, include it in the
full_neurons field (of ListNeuronsResponse). This does not affect which
neurons are part of the result set.

##### neuron\_ids

> **neuron\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L616)

These fields select neurons to be in the result set.

##### neuron\_subaccounts

> **neuron\_subaccounts**: \[\] \| \[[`NeuronSubaccount`](#neuronsubaccount)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L622)

##### page\_number

> **page\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L617)

##### page\_size

> **page\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L606)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L628)

Output of the list_neurons method.

#### Properties

##### full\_neurons

> **full\_neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L641)

If the caller has the necessary special privileges (or the neuron is
public, and the request sets include_public_neurons_in_full_neurons to
true), then all the information about the neurons in the result set is made
available here.

##### neuron\_infos

> **neuron\_infos**: \[`bigint`, [`NeuronInfo`](#neuroninfo)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L634)

Per the NeuronInfo type, this is a redacted view of the neurons in the
result set consisting of information that require no special privileges to
view.

##### total\_pages\_available

> **total\_pages\_available**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L642)

***

### ListNeuronVotesRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L568)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L573)

Only fetch the voting history for proposal whose id `< before_proposal`. This can be used as a
pagination token - pass the minimum proposal id as `before_proposal` for the next page.

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L578)

The maximum number of votes to fetch. The maximum number allowed is 500, and 500 will be used
if is set as either null or > 500.

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:583](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L583)

The neuron id for which the voting history will be returned. Currently, the voting history is
only recorded for known neurons.

***

### ListNodeProviderRewardsRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L644)

#### Properties

##### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](#daterangefilter)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L645)

***

### ListNodeProviderRewardsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L647)

#### Properties

##### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L648)

***

### ListNodeProvidersResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L650)

#### Properties

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L651)

***

### ListProposalInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L653)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L657)

##### exclude\_topic

> **exclude\_topic**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L659)

##### include\_all\_manage\_neuron\_proposals

> **include\_all\_manage\_neuron\_proposals**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:660](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L660)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:655](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L655)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L661)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L658)

##### omit\_large\_fields

> **omit\_large\_fields**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L656)

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L654)

***

### ListProposalInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:663](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L663)

#### Properties

##### proposal\_info

> **proposal\_info**: [`ProposalInfo`](#proposalinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L664)

***

### LoadCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L666)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L667)

##### snapshot\_id

> **snapshot\_id**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L668)

***

### MakeProposalRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L670)

#### Properties

##### action

> **action**: \[\] \| \[[`ProposalActionRequest`](#proposalactionrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:673](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L673)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L674)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L672)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L671)

***

### MakeProposalResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L676)

#### Properties

##### message

> **message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L677)

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L678)

***

### ManageNeuronProposal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:703](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L703)

Not to be confused with ManageNeuronRequest. This is only used to represent a manage neuron proposal.
(Yes, this is very structurally similar to that, but not actually exactly equivalent)

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronProposalCommand`](#manageneuronproposalcommand-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:705](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L705)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L704)

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:706](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L706)

***

### ManageNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L730)

Parameters of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](#manageneuroncommandrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L738)

What operation to perform on the neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L734)

Deprecated. Use neuron_id_or_subaccount instead.

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L742)

Which neuron to operate on.

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L747)

Output of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L752)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.

***

### MaturityDisbursement

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L754)

#### Properties

##### account\_identifier\_to\_disburse\_to

> **account\_identifier\_to\_disburse\_to**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L755)

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:758](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L758)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L757)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L759)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L756)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L761)

#### Properties

##### current\_value\_permyriad

> **current\_value\_permyriad**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L762)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L763)

***

### Merge

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:765](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L765)

#### Properties

##### source\_neuron\_id

> **source\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L766)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L768)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L769)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L771)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L772)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L773)

***

### MergeResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L775)

#### Properties

##### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:777](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L777)

##### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L779)

##### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L776)

##### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:778](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L778)

***

### MonthlyNodeProviderRewards

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:781](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L781)

#### Properties

##### algorithm\_version

> **algorithm\_version**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L782)

##### end\_date

> **end\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L784)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:791](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L791)

##### minimum\_xdr\_permyriad\_per\_icp

> **minimum\_xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L783)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L786)

##### registry\_version

> **registry\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L785)

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:789](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L789)

##### start\_date

> **start\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L787)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:788](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L788)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:790](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L790)

***

### Motion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L793)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:794](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L794)

***

### NetworkEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:796](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L796)

#### Properties

##### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:802](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L802)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:808](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L808)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L807)

##### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:803](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L803)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L797)

##### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:806](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L806)

##### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](#neuronsfundeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L809)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:804](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L804)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:805](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L805)

##### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](#votingpowereconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:801](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L801)

Parameters that affect the voting power of neurons.

***

### Neuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L811)

#### Properties

##### account

> **account**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L885)

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L883)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L882)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L880)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:814](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L814)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:881](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L881)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L879)

The amount of "sway" this neuron has when voting on proposals.

When a proposal is created, each eligible neuron gets a "blank" ballot. The
amount of voting power in that ballot is set to the neuron's deciding
voting power at the time of proposal creation. There are two ways that a
proposal can become decided:

1. Early: Either more than half of the total voting power in the ballots
votes in favor (then the proposal is approved), or at least half of the
votal voting power in the ballots votes against (then, the proposal is
rejected).

2. The proposal's voting deadline is reached. At that point, if there is
more voting power in favor than against, and at least 3% of the total
voting power voted in favor, then the proposal is approved. Otherwise, it
is rejected.

If a neuron regularly refreshes its voting power, this has the same value
as potential_voting_power. Actions that cause a refresh are as follows:

1. voting directly (not via following)
2. set following
3. refresh voting power

(All of these actions are performed via the manage_neuron method.)

However, if a neuron has not refreshed in a "long" time, this will be less
than potential voting power. See VotingPowerEconomics. As a further result
of less deciding voting power, not only does it have less influence on the
outcome of proposals, the neuron receives less voting rewards (when it
votes indirectly via following).

For details, see https://dashboard.internetcomputer.org/proposal/132411.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:899](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L899)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L893)

Base value (in e8s) used for the "8-year gang" dissolve delay bonus. For neurons that had the
maximum dissolve delay of 8 years before the maximum was reduced, this is set to the total
staked value net of fees (including staked maturity) captured at the time of migration.
For all other neurons, this is 0.

##### followees

> **followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L900)

##### hot\_keys

> **hot\_keys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:884](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L884)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:812](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L812)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L886)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:904](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L904)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:817](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L817)

##### maturity\_disbursements\_in\_progress

> **maturity\_disbursements\_in\_progress**: \[\] \| \[[`MaturityDisbursement`](#maturitydisbursement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L898)

The maturity disbursements in progress, i.e. the disbursements that are initiated but not
finalized. The finalization happens 7 days after the disbursement is initiated.

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L841)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L901)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L839)

##### not\_for\_profit

> **not\_for\_profit**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L840)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:838](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L838)

The amount of "sway" this neuron can have if it refreshes its voting power
frequently enough.

Unlike deciding_voting_power, this does NOT take refreshing into account.
Rather, this only takes three factors into account:

1. (Net) staked amount - This is the "base" of a neuron's voting power.
This primarily consists of the neuron's ICP balance.

2. Age - Neurons with more age have more voting power (all else being
equal).

3. Dissolve delay - Neurons with longer dissolve delay have more voting
power (all else being equal). Neurons with a dissolve delay of less
than six months are not eligible to vote. Therefore, such neurons
are considered to have 0 voting power.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:815](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L815)

##### spawn\_at\_timestamp\_seconds

> **spawn\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L905)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:813](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L813)

##### transfer

> **transfer**: \[\] \| \[[`NeuronStakeTransfer`](#neuronstaketransfer)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:903](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L903)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L902)

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:816](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L816)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L907)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L909)

##### dissolve\_delay\_interval

> **dissolve\_delay\_interval**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L908)

***

### NeuronBasketConstructionParameters\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L911)

#### Properties

##### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L913)

##### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:912](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L912)

***

### NeuronDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L915)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L916)

##### dissolve\_delay

> **dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L917)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L918)

##### stake

> **stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L920)

##### vesting\_period

> **vesting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L919)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L922)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:923](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L923)

***

### NeuronIndexData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L932)

#### Properties

##### neurons

> **neurons**: [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L933)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L928)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:929](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L929)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L930)

***

### NeuronInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L943)

A limit view of Neuron that allows some aspects of all neurons to be read by
anyone (i.e. without having to be the neuron's controller nor one of its
hotkeys).

As such, the meaning of each field in this type is generally the same as the
one of the same (or at least similar) name in Neuron.

#### Properties

##### age\_seconds

> **age\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:983](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L983)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:955](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L955)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:954](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L954)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L949)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:969](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L969)

See analogous field in Neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:944](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L944)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:965](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L965)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:972](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L972)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:953](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L953)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:952](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L952)

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:950](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L950)

##### retrieved\_at\_timestamp\_seconds

> **retrieved\_at\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:970](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L970)

##### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L964)

The amount of ICP (and staked maturity) locked in this neuron.

This is the foundation of the neuron's voting power.

cached_neuron_stake_e8s - neuron_fees_e8s + staked_maturity_e8s_equivalent

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L948)

See analogous field in Neuron.

##### state

> **state**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:956](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L956)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:971](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L971)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:982](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L982)

Deprecated. Use either deciding_voting_power or potential_voting_power
instead. Has the same value as deciding_voting_power.

Previously, if a neuron had < 6 months dissolve delay (making it ineligible
to vote), this would not get set to 0 (zero). That was pretty confusing.
Now that this is set to deciding_voting_power, this actually does get
zeroed out.

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L951)

***

### NeuronsFundAuditInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1020)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1021](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1021)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1022](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1022)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1023](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1023)

***

### NeuronsFundData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1025](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1025)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1026](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1026)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1027](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1027)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1028](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1028)

***

### NeuronsFundEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1030](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1030)

#### Properties

##### max\_theoretical\_neurons\_fund\_participation\_amount\_xdr

> **max\_theoretical\_neurons\_fund\_participation\_amount\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1035](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1035)

##### maximum\_icp\_xdr\_rate

> **maximum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1031](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1031)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1036](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1036)

##### neurons\_fund\_matched\_funding\_curve\_coefficients

> **neurons\_fund\_matched\_funding\_curve\_coefficients**: \[\] \| \[[`NeuronsFundMatchedFundingCurveCoefficients`](#neuronsfundmatchedfundingcurvecoefficients)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1032](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1032)

***

### NeuronsFundMatchedFundingCurveCoefficients

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1038](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1038)

#### Properties

##### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1039](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1039)

##### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1041](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1041)

##### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1040](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1040)

***

### NeuronsFundNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1043](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1043)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1048](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1048)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1044)

##### hotkeys

> **hotkeys**: \[\] \| \[[`Principals`](#principals-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1045](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1045)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1046](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1046)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1047](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1047)

***

### NeuronsFundNeuronPortion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1050)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1056](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1056)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1051)

##### hotkeys

> **hotkeys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1052)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1053)

##### maturity\_equivalent\_icp\_e8s

> **maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1054](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1054)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1055](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1055)

***

### NeuronsFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1058](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1058)

#### Properties

##### allocated\_neurons\_fund\_participation\_icp\_e8s

> **allocated\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1068](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1068)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1061](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1061)

##### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](#idealmatchedparticipationfunction)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1065)

##### intended\_neurons\_fund\_participation\_icp\_e8s

> **intended\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1060)

##### max\_neurons\_fund\_swap\_participation\_icp\_e8s

> **max\_neurons\_fund\_swap\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1063](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1063)

##### neurons\_fund\_reserves

> **neurons\_fund\_reserves**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1064](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1064)

##### swap\_participation\_limits

> **swap\_participation\_limits**: \[\] \| \[[`SwapParticipationLimits`](#swapparticipationlimits)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1062](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1062)

##### total\_maturity\_equivalent\_icp\_e8s

> **total\_maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1059](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1059)

***

### NeuronsFundSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1070](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1070)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuronPortion`](#neuronsfundneuronportion)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1071](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1071)

***

### NeuronStakeTransfer

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:985](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L985)

#### Properties

##### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:992](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L992)

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L988)

##### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:990](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L990)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:989](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L989)

##### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:987](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L987)

##### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:986](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L986)

##### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:991](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L991)

***

### NeuronSubaccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:994](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L994)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:995](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L995)

***

### NeuronSubsetMetrics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:997](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L997)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1002](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1002)

##### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1011)

##### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1003](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1003)

##### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:999](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L999)

##### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1010](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1010)

##### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1008](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1008)

##### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1007)

##### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1006)

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:998](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L998)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1005)

##### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1001](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1001)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1004](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1004)

##### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1009)

##### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1000](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1000)

***

### NeuronVote

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1013](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1013)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1018](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1018)

##### vote

> **vote**: \[\] \| \[[`Vote`](#vote-4)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1017](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1017)

The vote of the neuron on the specific proposal id.

***

### NodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1073)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1074)

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1075)

***

### Ok

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1077](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1077)

#### Properties

##### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](#neuronsfundauditinfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1078)

***

### Ok\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1080](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1080)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](#neuronsfundneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1081](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1081)

***

### OpenSnsTokenSwap

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1083](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1083)

#### Properties

##### community\_fund\_investment\_e8s

> **community\_fund\_investment\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1084](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1084)

##### params

> **params**: \[\] \| \[[`Params`](#params-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1086](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1086)

##### target\_swap\_canister\_id

> **target\_swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1085](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1085)

***

### Params

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1099](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1099)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1112](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1112)

##### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1104](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1104)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1109)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1110)

##### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1111](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1111)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1100](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1100)

##### min\_participants

> **min\_participants**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1106](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1106)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters_1`](#neuronbasketconstructionparameters_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1101)

##### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1108](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1108)

##### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1107)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1105)

***

### Percentage

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1114](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1114)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1115](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1115)

***

### Principals

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1117](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1117)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1118](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1118)

***

### Proposal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1120](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1120)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-3)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1123](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1123)

##### self\_describing\_action

> **self\_describing\_action**: \[\] \| \[[`SelfDescribingProposalAction`](#selfdescribingproposalaction)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1125](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1125)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1124)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1122](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1122)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1121](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1121)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1150](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1150)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1154](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1154)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1165](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1165)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1161](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1161)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1169](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1169)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1157](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1157)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1153](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1153)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1151](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1151)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1162](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1162)

##### neurons\_fund\_data

> **neurons\_fund\_data**: \[\] \| \[[`NeuronsFundData`](#neuronsfunddata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1159](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1159)

##### original\_total\_community\_fund\_maturity\_e8s\_equivalent

> **original\_total\_community\_fund\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1170](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1170)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1166](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1166)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1155)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1167](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1167)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1160)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1156](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1156)

##### sns\_token\_swap\_lifecycle

> **sns\_token\_swap\_lifecycle**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1164)

##### success\_value

> **success\_value**: \[\] \| \[[`SuccessfulProposalExecutionValue`](#successfulproposalexecutionvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1158](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1158)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1152](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1152)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1163](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1163)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1168](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1168)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1172](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1172)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1173](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1173)

***

### ProposalInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1175](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1175)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1180](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1180)

##### deadline\_timestamp\_seconds

> **deadline\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1183](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1183)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1191)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1187](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1187)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1194)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1184)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1179](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1179)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1176](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1176)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1188](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1188)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1192](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1192)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1181)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1193](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1193)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1186](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1186)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1182](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1182)

##### reward\_status

> **reward\_status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1190)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1177](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1177)

##### success\_value

> **success\_value**: \[\] \| \[[`SuccessfulProposalExecutionValue`](#successfulproposalexecutionvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1185](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1185)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1178)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1189)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1203](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1203)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1205)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1204](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1204)

***

### RemoveHotKey

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1207](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1207)

#### Properties

##### hot\_key\_to\_remove

> **hot\_key\_to\_remove**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1208](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1208)

***

### RestoreAgingNeuronGroup

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1210)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1211](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1211)

##### current\_total\_stake\_e8s

> **current\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1213](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1213)

##### group\_type

> **group\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1214)

##### previous\_total\_stake\_e8s

> **previous\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1212](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1212)

***

### RestoreAgingSummary

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1216](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1216)

#### Properties

##### groups

> **groups**: [`RestoreAgingNeuronGroup`](#restoreagingneurongroup)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1217](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1217)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1218)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1235](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1235)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1238](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1238)

##### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1237](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1237)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1241](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1241)

##### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1240](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1240)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1236](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1236)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1242](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1242)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1239](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1239)

***

### RewardNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1247](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1247)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1250](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1250)

##### node\_provider

> **node\_provider**: \[\] \| \[[`NodeProvider`](#nodeprovider)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1248](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1248)

##### reward\_mode

> **reward\_mode**: \[\] \| \[[`RewardMode`](#rewardmode)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1249](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1249)

***

### RewardNodeProviders

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1252)

#### Properties

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1254](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1254)

##### use\_registry\_derived\_rewards

> **use\_registry\_derived\_rewards**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1253](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1253)

***

### RewardToAccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1256](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1256)

#### Properties

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1257](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1257)

***

### RewardToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1259](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1259)

#### Properties

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1260](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1260)

***

### SelfDescribingProposalAction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1262)

#### Properties

##### type\_description

> **type\_description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1263](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1263)

##### type\_name

> **type\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1264](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1264)

##### value

> **value**: \[\] \| \[[`SelfDescribingValue`](#selfdescribingvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1265](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1265)

***

### SetDefaultFollowees

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1276](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1276)

#### Properties

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1277](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1277)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1279](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1279)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1280](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1280)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1282)

#### Properties

##### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](#followeesfortopic)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1283](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1283)

***

### SetOpenTimeWindowRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1286](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1286)

#### Properties

##### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](#timewindow)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1287)

***

### SetSnsTokenSwapOpenTimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1289](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1289)

#### Properties

##### request

> **request**: \[\] \| \[[`SetOpenTimeWindowRequest`](#setopentimewindowrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1290](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1290)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1291)

***

### SettleCommunityFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1296](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1296)

#### Properties

##### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1298](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1298)

##### result

> **result**: \[\] \| \[[`Result_8`](#result_8)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1297](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1297)

***

### SettleNeuronsFundParticipationRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1300](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1300)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1302](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1302)

##### result

> **result**: \[\] \| \[[`Result_9`](#result_9)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1301](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1301)

***

### SettleNeuronsFundParticipationResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1304](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1304)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_10`](#result_10)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1305](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1305)

***

### SetVisibility

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1293](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1293)

#### Properties

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1294](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1294)

***

### Spawn

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1307)

#### Properties

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1309](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1309)

##### nonce

> **nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1310](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1310)

##### percentage\_to\_spawn

> **percentage\_to\_spawn**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1308](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1308)

***

### SpawnResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1312](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1312)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1313](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1313)

***

### Split

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1315](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1315)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1317](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1317)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1316](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1316)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1319](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1319)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1320](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1320)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1322](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1322)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1323](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1323)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1324](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1324)

***

### StopOrStartCanister

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1326](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1326)

#### Properties

##### action

> **action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1327](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1327)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1328](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1328)

***

### SwapBackgroundInformation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1335](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1335)

#### Properties

##### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1343](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1343)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1337)

##### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1341](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1341)

##### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1338](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1338)

##### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1339](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1339)

##### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1336](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1336)

##### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1342](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1342)

##### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1340](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1340)

***

### SwapDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1345](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1345)

#### Properties

##### total

> **total**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1346](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1346)

***

### SwapParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1348)

#### Properties

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1355](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1355)

##### duration

> **duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1351](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1351)

##### maximum\_direct\_participation\_icp

> **maximum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1361](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1361)

##### maximum\_icp

> **maximum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1362](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1362)

##### maximum\_participant\_icp

> **maximum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1356](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1356)

##### minimum\_direct\_participation\_icp

> **minimum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1358](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1358)

##### minimum\_icp

> **minimum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1357](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1357)

##### minimum\_participant\_icp

> **minimum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1359](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1359)

##### minimum\_participants

> **minimum\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1349](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1349)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1352](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1352)

##### neurons\_fund\_investment\_icp

> **neurons\_fund\_investment\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1363](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1363)

##### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1350](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1350)

##### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](#countries)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1364](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1364)

##### start\_time

> **start\_time**: \[\] \| \[[`GlobalTimeOfDay`](#globaltimeofday)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1360](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1360)

***

### SwapParticipationLimits

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1366](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1366)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1370](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1370)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1368](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1368)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1369](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1369)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1367](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1367)

***

### TakeCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1372](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1372)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1374](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1374)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1373](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1373)

***

### TakeCanisterSnapshotOk

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1376](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1376)

#### Properties

##### snapshot\_id

> **snapshot\_id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1377](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1377)

***

### Tally

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1379](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1379)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1380](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1380)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1383](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1383)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1382](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1382)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1381](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1381)

***

### TimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1385](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1385)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1387](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1387)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1386](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1386)

***

### Tokens

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1389)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1390](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1390)

***

### UpdateCanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1417](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1417)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1418](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1418)

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1419](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1419)

***

### UpdateNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1421](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1421)

#### Properties

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1422](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1422)

***

### UpdateStandardEngineReplicaVersion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1427](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1427)

Changes what replica version(s) are run by Cloud Engines.

#### Properties

##### deployment\_progress

> **deployment\_progress**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1430](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1430)

##### new\_replica\_version\_id

> **new\_replica\_version\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1428](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1428)

##### old\_replica\_version\_id

> **old\_replica\_version\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1429](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1429)

***

### VotingPowerEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1444](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1444)

Parameters that affect the voting power of neurons.

#### Properties

##### clear\_following\_after\_seconds

> **clear\_following\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1476)

After a neuron has experienced voting power reduction for this amount of
time, a couple of things happen:

1. Deciding voting power reaches 0.

2. Its following on topics other than NeuronManagement are cleared.

Initially, set to 1/12 years.

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1465](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1465)

The minimum dissolve delay a neuron must have in order to be eligible to vote.

Neurons with a dissolve delay lower than this threshold will not have
voting power, even if they are otherwise active.

This value is an essential part of the staking mechanism, promoting
long-term alignment with the network's governance.

##### start\_reducing\_voting\_power\_after\_seconds

> **start\_reducing\_voting\_power\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1455](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1455)

If a neuron has not "refreshed" its voting power after this amount of time,
its deciding voting power starts decreasing linearly. See also
clear_following_after_seconds.

For explanation of what "refresh" means in this context, see
https://dashboard.internetcomputer.org/proposal/132411

Initially, set to 0.5 years. (The nominal length of a year is 365.25 days).

***

### VotingRewardParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1478](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1478)

#### Properties

##### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1481](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1481)

##### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1480](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1480)

##### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1479](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1479)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1483](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1483)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1484](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1484)

***

### XdrConversionRate

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1487](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1487)

#### Properties

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1489](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1489)

##### xdr\_permyriad\_per\_icp

> **xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1488](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1488)

## Type Aliases

### Action

> **Action** = \{ `UpdateStandardEngineReplicaVersion`: [`UpdateStandardEngineReplicaVersion`](#updatestandardenginereplicaversion); \} \| \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronProposal`](#manageneuronproposal); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCode`](#installcode); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCode`](#createcanisterandinstallcode); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](#opensnstokenswap); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](#setsnstokenswapopentimewindow); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](#setdefaultfollowees); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L20)

***

### By

> **By** = \{ `NeuronIdOrSubaccount`: \{ \}; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L89)

***

### Change

> **Change** = \{ `ToRemove`: [`NodeProvider`](#nodeprovider); \} \| \{ `ToAdd`: [`NodeProvider`](#nodeprovider); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L124)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Spawn`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Split`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](#refreshvotingpowerresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](#mergeresponse); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](#spawnresponse); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](#setfollowingresponse); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](#makeproposalresponse); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L141)

***

### Command\_2

> **Command\_2** = \{ `Spawn`: [`NeuronId`](#neuronid-1); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L158)

***

### CreateNeuronResponse

> **CreateNeuronResponse** = \{ `Ok`: [`CreatedNeuron`](#createdneuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L236)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L300)

***

### GetMaturityModulationRequest

> **GetMaturityModulationRequest** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L363)

***

### GetNeuronIndexResult

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](#neuronindexdata); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L371)

***

### ListNeuronVotesResponse

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](#proposalid)\]; `votes`: \[\] \| \[[`NeuronVote`](#neuronvote)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L585)

***

### ManageNeuronCommandRequest

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](#makeproposalrequest); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:683](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L683)

KEEP THIS IN SYNC WITH COMMAND!

***

### ManageNeuronProposalCommand

> **ManageNeuronProposalCommand** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L711)

KEEP THIS IN SYNC WITH ManageNeuronCommandRequest!

***

### NeuronIdOrSubaccount

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:925](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L925)

***

### Operation

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](#removehotkey); \} \| \{ `AddHotKey`: [`AddHotKey`](#addhotkey); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetVisibility`: [`SetVisibility`](#setvisibility); \} \| \{ `JoinCommunityFund`: \{ \}; \} \| \{ `LeaveCommunityFund`: \{ \}; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1088](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1088)

***

### ProposalActionRequest

> **ProposalActionRequest** = \{ `UpdateStandardEngineReplicaVersion`: [`UpdateStandardEngineReplicaVersion`](#updatestandardenginereplicaversion); \} \| \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](#manageneuronrequest); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCodeRequest`](#installcoderequest); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCodeRequest`](#createcanisterandinstallcoderequest); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1127](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1127)

***

### RefreshVotingPower

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1201](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1201)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.

***

### RefreshVotingPowerResponse

> **RefreshVotingPowerResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1202)

***

### Result

> **Result** = \{ `Ok`: `null`; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1220](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1220)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1221](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1221)

***

### Result\_10

> **Result\_10** = \{ `Ok`: [`Ok_1`](#ok_1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1222](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1222)

***

### Result\_2

> **Result\_2** = \{ `Ok`: [`Neuron`](#neuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1223)

***

### Result\_3

> **Result\_3** = \{ `Ok`: [`GovernanceCachedMetrics`](#governancecachedmetrics); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1224](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1224)

***

### Result\_4

> **Result\_4** = \{ `Ok`: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1227](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1227)

***

### Result\_5

> **Result\_5** = \{ `Ok`: [`NeuronInfo`](#neuroninfo); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1230](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1230)

***

### Result\_6

> **Result\_6** = \{ `Ok`: [`Ok`](#ok); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1231](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1231)

***

### Result\_7

> **Result\_7** = \{ `Ok`: [`NodeProvider`](#nodeprovider); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1232](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1232)

***

### Result\_8

> **Result\_8** = \{ `Committed`: [`Committed`](#committed); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1233](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1233)

***

### Result\_9

> **Result\_9** = \{ `Committed`: [`Committed_1`](#committed_1); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1234](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1234)

***

### RewardMode

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](#rewardtoneuron); \} \| \{ `RewardToAccount`: [`RewardToAccount`](#rewardtoaccount); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1244](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1244)

***

### SelfDescribingValue

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`SelfDescribingValue`](#selfdescribingvalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`SelfDescribingValue`](#selfdescribingvalue)[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1267](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1267)

***

### SetFollowingResponse

> **SetFollowingResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1285](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1285)

***

### SuccessfulProposalExecutionValue

> **SuccessfulProposalExecutionValue** = \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshotOk`](#takecanistersnapshotok); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCodeOk`](#createcanisterandinstallcodeok); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1330](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1330)

***

### TopicToFollow

> **TopicToFollow** = \{ `Kyc`: `null`; \} \| \{ `ServiceNervousSystemManagement`: `null`; \} \| \{ `ApiBoundaryNodeManagement`: `null`; \} \| \{ `ApplicationCanisterManagement`: `null`; \} \| \{ `SubnetRental`: `null`; \} \| \{ `NeuronManagement`: `null`; \} \| \{ `NodeProviderRewards`: `null`; \} \| \{ `SubnetManagement`: `null`; \} \| \{ `ExchangeRate`: `null`; \} \| \{ `CatchAll`: `null`; \} \| \{ `NodeAdmin`: `null`; \} \| \{ `IcOsVersionElection`: `null`; \} \| \{ `ProtocolCanisterManagement`: `null`; \} \| \{ `NetworkEconomics`: `null`; \} \| \{ `IcOsVersionDeployment`: `null`; \} \| \{ `ParticipantManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsAndCommunityFund`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1398)

A topic that can be followed. It is almost the same as the topic on the
proposal, except that the `CatchAll` is a special value and following on this
`topic` will let the neuron follow the votes on all topics except for
Governance and SnsAndCommunityFund.

***

### Vote

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1432](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1432)

#### Type Declaration

\{ `No`: `null`; \}

##### No

> **No**: `null`

\{ `Yes`: `null`; \}

##### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

##### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.

***

### WasmModule

> **WasmModule** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1486](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1486)

#### Properties

##### Inlined

> **Inlined**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1486](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1486)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1569](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1569)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1570](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/declarations/nns/governance_test.d.ts#L1570)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
