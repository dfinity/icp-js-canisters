---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [NnsGenesisTokenDid](namespaces/NnsGenesisTokenDid.md)
- [NnsGovernanceDid](namespaces/NnsGovernanceDid.md)
- [NnsGovernanceTestDid](namespaces/NnsGovernanceTestDid.md)
- [SnsWasmDid](namespaces/SnsWasmDid.md)

## Enumerations

### CanisterAction

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L173)

#### Enumeration Members

##### Start

> **Start**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L178)

##### Stop

> **Stop**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L176)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L174)

***

### CanisterInstallMode

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L189)

#### Enumeration Members

##### Install

> **Install**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L191)

##### Reinstall

> **Reinstall**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L192)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L190)

##### Upgrade

> **Upgrade**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L193)

***

### LogVisibility

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L164)

#### Enumeration Members

##### Controllers

> **Controllers**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:167](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L167)

##### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:169](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L169)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:165](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L165)

***

### NeuronState

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L7)

#### Enumeration Members

##### Dissolved

> **Dissolved**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:11](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L11)

##### Dissolving

> **Dissolving**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:10](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L10)

##### Locked

> **Locked**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:9](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L9)

##### Spawning

> **Spawning**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L12)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:8](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L8)

***

### NeuronType

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:151](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L151)

#### Enumeration Members

##### Ect

> **Ect**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L160)

##### Seed

> **Seed**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:157](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L157)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:154](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L154)

***

### NeuronVisibility

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:182](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L182)

#### Enumeration Members

##### Private

> **Private**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L184)

##### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:185](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L185)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:183](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L183)

***

### NnsFunction

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L88)

#### Enumeration Members

##### AddApiBoundaryNodes

> **AddApiBoundaryNodes**: `43`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:132](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L132)

##### AddFirewallRules

> **AddFirewallRules**: `25`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:114](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L114)

##### AddNodeToSubnet

> **AddNodeToSubnet**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:91](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L91)

##### AddOrRemoveDataCenters

> **AddOrRemoveDataCenters**: `21`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L110)

##### AddSnsWasm

> **AddSnsWasm**: `30`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:119](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L119)

##### AssignNoid

> **AssignNoid**: `8`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:97](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L97)

##### BitcoinSetConfig

> **BitcoinSetConfig**: `39`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:128](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L128)

##### BlessReplicaVersion

> **BlessReplicaVersion**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:94](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L94)

##### ChangeSubnetMembership

> **ChangeSubnetMembership**: `31`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:120](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L120)

##### ChangeSubnetTypeAssignment

> **ChangeSubnetTypeAssignment**: `33`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:122](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L122)

##### ClearProvisionalWhitelist

> **ClearProvisionalWhitelist**: `12`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L101)

##### CompleteCanisterMigration

> **CompleteCanisterMigration**: `29`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:118](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L118)

##### CreateSubnet

> **CreateSubnet**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L90)

##### DeployGuestosToAllSubnetNodes

> **DeployGuestosToAllSubnetNodes**: `11`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:100](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L100)

##### DeployGuestosToAllUnassignedNodes

> **DeployGuestosToAllUnassignedNodes**: `48`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:140](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L140)

##### DeployGuestosToSomeApiBoundaryNodes

> **DeployGuestosToSomeApiBoundaryNodes**: `47`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:139](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L139)

##### DeployHostosToSomeNodes

> **DeployHostosToSomeNodes**: `51`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:143](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L143)

##### HardResetNnsRootToVersion

> **HardResetNnsRootToVersion**: `42`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:131](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L131)

##### IcpXdrConversionRate

> **IcpXdrConversionRate**: `10`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:99](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L99)

##### InsertSnsWasmUpgradePathEntries

> **InsertSnsWasmUpgradePathEntries**: `37`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:126](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L126)

##### NnsCanisterInstall

> **NnsCanisterInstall**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:92](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L92)

##### NnsCanisterUpgrade

> **NnsCanisterUpgrade**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:93](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L93)

##### NnsRootUpgrade

> **NnsRootUpgrade**: `9`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:98](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L98)

##### PauseCanisterMigrations

> **PauseCanisterMigrations**: `53`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:145](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L145)

##### PrepareCanisterMigration

> **PrepareCanisterMigration**: `28`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:117](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L117)

##### RecoverSubnet

> **RecoverSubnet**: `6`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:95](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L95)

##### RemoveApiBoundaryNodes

> **RemoveApiBoundaryNodes**: `44`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:133](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L133)

##### RemoveFirewallRules

> **RemoveFirewallRules**: `26`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:115](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L115)

##### RemoveNodeOperators

> **RemoveNodeOperators**: `23`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:112](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L112)

##### RemoveNodes

> **RemoveNodes**: `18`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L107)

##### RemoveNodesFromSubnet

> **RemoveNodesFromSubnet**: `13`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:102](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L102)

##### RerouteCanisterRanges

> **RerouteCanisterRanges**: `24`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L113)

##### RetireReplicaVersion

> **RetireReplicaVersion**: `36`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:125](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L125)

##### ReviseElectedGuestosVersions

> **ReviseElectedGuestosVersions**: `38`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:127](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L127)

##### ReviseElectedHostosVersions

> **ReviseElectedHostosVersions**: `50`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:142](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L142)

##### SetAuthorizedSubnetworks

> **SetAuthorizedSubnetworks**: `14`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:103](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L103)

##### SetFirewallConfig

> **SetFirewallConfig**: `15`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:104](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L104)

##### SetSubnetOperationalLevel

> **SetSubnetOperationalLevel**: `55`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:147](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L147)

##### StopOrStartNnsCanister

> **StopOrStartNnsCanister**: `17`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:106](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L106)

##### SubnetRentalRequest

> **SubnetRentalRequest**: `52`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:144](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L144)

##### UninstallCode

> **UninstallCode**: `19`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:108](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L108)

##### UnpauseCanisterMigrations

> **UnpauseCanisterMigrations**: `54`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:146](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L146)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L89)

##### UpdateAllowedPrincipals

> **UpdateAllowedPrincipals**: `35`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L124)

##### ~~UpdateApiBoundaryNodeDomain~~

> **UpdateApiBoundaryNodeDomain**: `45`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:137](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L137)

###### Deprecated

##### UpdateApiBoundaryNodesVersion

> **UpdateApiBoundaryNodesVersion**: `46`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:138](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L138)

##### UpdateConfigOfSubnet

> **UpdateConfigOfSubnet**: `7`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:96](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L96)

##### UpdateElectedHostosVersions

> **UpdateElectedHostosVersions**: `40`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:129](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L129)

##### UpdateFirewallRules

> **UpdateFirewallRules**: `27`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:116](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L116)

##### UpdateNodeOperatorConfig

> **UpdateNodeOperatorConfig**: `16`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L105)

##### UpdateNodeRewardsTable

> **UpdateNodeRewardsTable**: `20`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L109)

##### UpdateNodesHostosVersion

> **UpdateNodesHostosVersion**: `41`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L130)

##### UpdateSnsWasmSnsSubnetIds

> **UpdateSnsWasmSnsSubnetIds**: `34`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:123](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L123)

##### UpdateSshReadOnlyAccessForAllUnassignedNodes

> **UpdateSshReadOnlyAccessForAllUnassignedNodes**: `49`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:141](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L141)

##### UpdateSubnetType

> **UpdateSubnetType**: `32`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:121](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L121)

##### UpdateUnassignedNodesConfig

> **UpdateUnassignedNodesConfig**: `22`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:111](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L111)

***

### ProposalRewardStatus

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:42](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L42)

#### Enumeration Members

##### AcceptVotes

> **AcceptVotes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:47](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L47)

##### Ineligible

> **Ineligible**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:57](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L57)

##### ReadyToSettle

> **ReadyToSettle**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:51](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L51)

##### Settled

> **Settled**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:54](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L54)

##### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:43](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L43)

***

### ProposalStatus

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:62](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L62)

#### Enumeration Members

##### Accepted

> **Accepted**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:73](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L73)

##### Executed

> **Executed**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:76](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L76)

##### Failed

> **Failed**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:79](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L79)

##### Open

> **Open**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:66](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L66)

##### Rejected

> **Rejected**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:69](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L69)

##### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:63](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L63)

***

### Topic

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L15)

#### Enumeration Members

##### ApiBoundaryNodeManagement

> **ApiBoundaryNodeManagement**: `15`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L34)

##### ExchangeRate

> **ExchangeRate**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:18](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L18)

##### Governance

> **Governance**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:20](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L20)

##### IcOsVersionDeployment

> **IcOsVersionDeployment**: `12`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:31](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L31)

##### IcOsVersionElection

> **IcOsVersionElection**: `13`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:32](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L32)

##### Kyc

> **Kyc**: `9`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:25](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L25)

##### NetworkCanisterManagement

> **NetworkCanisterManagement**: `8`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:24](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L24)

##### NetworkEconomics

> **NetworkEconomics**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:19](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L19)

##### NeuronManagement

> **NeuronManagement**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:17](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L17)

##### NodeAdmin

> **NodeAdmin**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L21)

##### NodeProviderRewards

> **NodeProviderRewards**: `10`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:26](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L26)

##### ParticipantManagement

> **ParticipantManagement**: `6`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:22](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L22)

##### ProtocolCanisterManagement

> **ProtocolCanisterManagement**: `17`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:36](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L36)

##### ServiceNervousSystemManagement

> **ServiceNervousSystemManagement**: `18`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:37](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L37)

##### SnsAndCommunityFund

> **SnsAndCommunityFund**: `14`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:33](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L33)

##### ~~SnsDecentralizationSale~~

> **SnsDecentralizationSale**: `11`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:30](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L30)

###### Deprecated

##### SubnetManagement

> **SubnetManagement**: `7`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:23](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L23)

##### SubnetRental

> **SubnetRental**: `16`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:35](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L35)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:16](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L16)

***

### Vote

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L82)

#### Enumeration Members

##### No

> **No**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L85)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L83)

##### Yes

> **Yes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/enums/governance.enums.ts#L84)

## Classes

### CouldNotClaimNeuronError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L5)

#### Extends

- [`StakeNeuronError`](#stakeneuronerror)

#### Constructors

##### Constructor

> **new CouldNotClaimNeuronError**(`message?`): [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

##### Constructor

> **new CouldNotClaimNeuronError**(`message?`, `options?`): [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`message`](#message-3)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### GovernanceError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:14](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L14)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new GovernanceError**(`detail`): [`GovernanceError`](#governanceerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L15)

###### Parameters

###### detail

[`GovernanceError`](namespaces/NnsGovernanceDid.md#governanceerror)

###### Returns

[`GovernanceError`](#governanceerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### detail

> `readonly` **detail**: [`GovernanceError`](namespaces/NnsGovernanceDid.md#governanceerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L15)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### InsufficientAmountError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L7)

#### Extends

- [`StakeNeuronError`](#stakeneuronerror)

#### Constructors

##### Constructor

> **new InsufficientAmountError**(`minimumAmount`): [`InsufficientAmountError`](#insufficientamounterror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L8)

###### Parameters

###### minimumAmount

`bigint`

###### Returns

[`InsufficientAmountError`](#insufficientamounterror)

###### Overrides

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`message`](#message-3)

##### minimumAmount

> `readonly` **minimumAmount**: `bigint`

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L8)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### NnsGenesisTokenCanister

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:11](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/genesis_token.canister.ts#L11)

#### Methods

##### claimNeurons()

> **claimNeurons**(`__namedParameters`): `Promise`\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/genesis_token.canister.ts#L29)

###### Parameters

###### \_\_namedParameters

###### hexPubKey

`string`

###### Returns

`Promise`\<`bigint`[]\>

##### create()

> `static` **create**(`options`): [`NnsGenesisTokenCanister`](#nnsgenesistokencanister)

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/genesis_token.canister.ts#L16)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/NnsGenesisTokenDid.md#_service)\> = `{}`

###### Returns

[`NnsGenesisTokenCanister`](#nnsgenesistokencanister)

***

### NnsGovernanceCanister

Defined in: [packages/canisters/src/nns/governance.canister.ts:97](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L97)

#### Methods

##### addHotkey()

> **addHotkey**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:917](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L917)

Add hotkey to neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### principal

`Principal`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:508](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L508)

Changes auto-stake maturity for this Neuron. While on, auto-stake maturity will cause all the maturity generated by voting rewards to this neuron to be automatically staked and contribute to the voting power of the neuron.

###### Parameters

###### params

###### autoStake

`boolean`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### claimOrRefreshNeuron()

> **claimOrRefreshNeuron**(`request`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:986](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L986)

Refreshes neuron and returns neuronId when successful
Uses query call only.

###### Parameters

###### request

[`ClaimOrRefreshNeuronRequest`](#claimorrefreshneuronrequest)

###### Returns

`Promise`\<`bigint` \| `undefined`\>

###### Throws

[UnrecognizedTypeError](#unrecognizedtypeerror)

##### claimOrRefreshNeuronFromAccount()

> **claimOrRefreshNeuronFromAccount**(`__namedParameters`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:955](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L955)

Gets the NeuronID of a newly created neuron.

###### Parameters

###### \_\_namedParameters

###### controller?

`Principal`

###### memo

`bigint`

###### Returns

`Promise`\<`bigint` \| `undefined`\>

##### disburse()

> **disburse**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:761](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L761)

Disburse neuron on Account

###### Parameters

###### \_\_namedParameters

###### amount?

`bigint`

###### neuronId

`bigint`

###### toAccountId?

`string`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidAccountIDError

##### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1078)

Disburses a neuron's maturity (always certified).
Reference: https://github.com/dfinity/ic/blob/ca2be53acf413bb92478ee7694ac0fb92af07030/rs/sns/governance/src/governance.rs#L1614

###### Parameters

###### params

###### neuronId

`bigint`

The id of the neuron for which to disburse maturity

###### percentageToDisburse

`number`

The percentage of the neuron's maturity to disburse, between 1 and 100 (inclusive).

###### toAccount?

[`Account`](#account)

Optional. The ICRC account to which the maturity will be disbursed. If not provided, the maturity will be disbursed to the caller's Main account.

###### toAccountIdentifier?

`string`

Optional. The account identifier to which the maturity will be disbursed. If not provided, the maturity will be disbursed to the caller's Main account.

###### Returns

`Promise`\<`void`\>

###### Preconditions

- The neuron exists
- The caller is authorized to perform this neuron operation (NeuronPermissionType::DisburseMaturity)
- The given percentage_to_merge is between 1 and 100 (inclusive)
- The neuron's id is not yet in the list of neurons with ongoing operations
- The e8s equivalent of the amount of maturity to disburse is more than the transaction fee.

##### getLatestRewardEvent()

> **getLatestRewardEvent**(`certified`): `Promise`\<[`RewardEvent`](namespaces/NnsGovernanceDid.md#rewardevent)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:318](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L318)

Returns the latest reward event.

If `certified` is true, the request is fetched as an update call, otherwise
it's fetched using a query call.

###### Parameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`RewardEvent`](namespaces/NnsGovernanceDid.md#rewardevent)\>

##### getMaturityModulation()

> **getMaturityModulation**(`__namedParameters`): `Promise`\<[`MaturityModulation`](#maturitymodulation) \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1050)

Return the current maturity modulation applied when maturity is disbursed or spawned.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`MaturityModulation`](#maturitymodulation) \| `undefined`\>

##### getMetrics()

> **getMetrics**(`__namedParameters`): `Promise`\<[`GovernanceCachedMetrics`](#governancecachedmetrics)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1124](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1124)

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`GovernanceCachedMetrics`](#governancecachedmetrics)\>

##### getNetworkEconomicsParameters()

> **getNetworkEconomicsParameters**(`__namedParameters`): `Promise`\<[`NetworkEconomics`](#networkeconomics-2)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1032](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1032)

Return the [Network Economics](https://github.com/dfinity/ic/blob/d90e934eb440c730d44d9d9b1ece2cc3f9505d05/rs/nns/governance/proto/ic_nns_governance/pb/v1/governance.proto#L1847).

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`NetworkEconomics`](#networkeconomics-2)\>

##### getNeuron()

> **getNeuron**(`__namedParameters`): `Promise`\<[`NeuronInfo`](#neuroninfo) \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1011)

Return the data of the neuron provided as id.

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### neuronId

`bigint`

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo) \| `undefined`\>

##### getProposal()

> **getProposal**(`__namedParameters`): `Promise`\<[`ProposalInfo`](#proposalinfo) \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:683](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L683)

Returns single proposal info

If `certified` is true (default), the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### \_\_namedParameters

###### certified?

`boolean` = `true`

###### proposalId

`bigint`

###### Returns

`Promise`\<[`ProposalInfo`](#proposalinfo) \| `undefined`\>

##### increaseDissolveDelay()

> **increaseDissolveDelay**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:413](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L413)

Increases dissolve delay of a neuron

###### Parameters

###### \_\_namedParameters

###### additionalDissolveDelaySeconds

`number`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### joinCommunityFund()

> **joinCommunityFund**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:490](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L490)

Neuron joins the community fund

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### leaveCommunityFund()

> **leaveCommunityFund**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:523](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L523)

Neuron leaves the community fund

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### listKnownNeurons()

> **listKnownNeurons**(`certified`): `Promise`\<[`KnownNeuron`](#knownneuron)[]\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L291)

Returns the list of neurons who have been approved by the community to
appear as the default followee options.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`KnownNeuron`](#knownneuron)[]\>

##### listNeurons()

> **listNeurons**(`__namedParameters`): `Promise`\<[`NeuronInfo`](#neuroninfo)[]\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:158](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L158)

Returns the list of neurons controlled by the caller.

If an array of neuron IDs is provided, precisely those neurons will be fetched.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

The backend treats `includeEmptyNeurons` as false if absent.

The response from the canister might be paginated. In this case, all pages will be fetched in parallel and
combined into a single return value.

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### includeEmptyNeurons?

`boolean`

###### includePublicNeurons?

`boolean`

###### neuronIds?

`bigint`[]

###### neuronSubaccounts?

[`NeuronSubaccount`](namespaces/NnsGovernanceDid.md#neuronsubaccount)[]

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo)[]\>

##### listProposals()

> **listProposals**(`request`): `Promise`\<[`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:333](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L333)

Returns the list of proposals made for the community to vote on,
paginated and filtered by the request.

If `certified` is true (default), the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### request

the options to list the proposals (limit number of results, topics to search for, etc.)

###### certified?

`boolean` = `true`

###### request

[`ListProposalsRequest`](#listproposalsrequest)

###### Returns

`Promise`\<[`ListProposalsResponse`](#listproposalsresponse)\>

##### makeProposal()

> **makeProposal**(`request`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:703](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L703)

Create new proposal

###### Parameters

###### request

[`MakeProposalRequest`](#makeproposalrequest)

###### Returns

`Promise`\<`bigint` \| `undefined`\>

The newly created proposal ID or undefined if the success response returned by the Governance canister does not provide such information.

###### Throws

[GovernanceError](#governanceerror)

##### mergeMaturity()

> **mergeMaturity**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:819](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L819)

Merge Maturity of a neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### percentageToMerge

`number`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### mergeNeurons()

> **mergeNeurons**(`request`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:578](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L578)

Merge two neurons

###### Parameters

###### request

###### sourceNeuronId

`bigint`

###### targetNeuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### refreshVotingPower()

> **refreshVotingPower**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:797](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L797)

Refreshes voting power of a neuron
(Resets the `votingPowerRefreshedTimestampSeconds`
parameter of the neuron to the current time).

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### registerVote()

> **registerVote**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:724](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L724)

Registers vote for a proposal from the neuron passed.

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### proposalId

`bigint`

###### vote

[`Vote`](#vote)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### removeHotkey()

> **removeHotkey**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:937](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L937)

Remove hotkey to neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### principal

`Principal`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setDissolveDelay()

> **setDissolveDelay**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:439](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L439)

Sets dissolve delay of a neuron.
The new date is now + dissolveDelaySeconds.

###### Parameters

###### neuronId

###### dissolveDelaySeconds

`number`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setFollowees()

> **setFollowees**(`followRequest`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:746](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L746)

Edit neuron followees per topic

###### Parameters

###### followRequest

[`FollowRequest`](#followrequest)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L1109)

Set the following topics for a neuron.

###### Parameters

###### params

###### neuronId

`bigint`

The id of the neuron for which to set the following topics

###### topicFollowing

[`FolloweesForTopic`](#followeesfortopic)[]

The topics and the followees for each topic that the neuron should follow.

###### Returns

`Promise`\<`void`\>

##### setNodeProviderAccount()

> **setNodeProviderAccount**(`accountIdentifier`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:558](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L558)

Sets node provider reward account.
Where the reward is paid to.

###### Parameters

###### accountIdentifier

`string`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidAccountIDError

##### setVisibility()

> **setVisibility**(`neuronId`, `visibility`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:538](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L538)

Set visibility of a neuron

###### Parameters

###### neuronId

`bigint`

###### visibility

[`NeuronVisibility`](#neuronvisibility)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### simulateMergeNeurons()

> **simulateMergeNeurons**(`request`): `Promise`\<[`NeuronInfo`](#neuroninfo)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:595](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L595)

Simulate merging two neurons

###### Parameters

###### request

###### sourceNeuronId

`bigint`

###### targetNeuronId

`bigint`

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo)\>

###### Throws

[GovernanceError](#governanceerror)

##### spawnNeuron()

> **spawnNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:870](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L870)

Merge Maturity of a neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### newController?

`Principal`

###### nonce?

`bigint`

###### percentageToSpawn?

`number`

###### Returns

`Promise`\<`bigint`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### splitNeuron()

> **splitNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:640](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L640)

Splits a neuron creating a new one

###### Parameters

###### \_\_namedParameters

###### amount

`bigint`

###### memo?

`bigint`

###### neuronId

`bigint`

###### Returns

`Promise`\<`bigint`\>

newNeuronId

###### Throws

[GovernanceError](#governanceerror)

##### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:848](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L848)

Stake the maturity of a neuron.

###### Parameters

###### params

###### neuronId

`bigint`

###### percentageToStake?

`number`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### stakeNeuron()

> **stakeNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:352](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L352)

###### Parameters

###### \_\_namedParameters

###### createdAt?

`bigint`

###### fee?

`bigint`

###### fromSubAccount?

`number`[]

###### ledgerCanister

[`IcpLedgerCanister`](../ledger/icp/index.md#icpledgercanister)

###### principal

`Principal`

###### stake

`bigint`

###### Returns

`Promise`\<`bigint`\>

###### Throws

[InsufficientAmountError](#insufficientamounterror)

###### Throws

StakeNeuronTransferError

###### Throws

[CouldNotClaimNeuronError](#couldnotclaimneuronerror)

###### Throws

TransferError

##### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:462](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L462)

Start dissolving process of a neuron

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L476)

Stop dissolving process of a neuron

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### create()

> `static` **create**(`options`): [`NnsGovernanceCanister`](#nnsgovernancecanister)

Defined in: [packages/canisters/src/nns/governance.canister.ts:112](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance.canister.ts#L112)

###### Parameters

###### options

[`NnsGovernanceCanisterOptions`](#nnsgovernancecanisteroptions) = `{}`

###### Returns

[`NnsGovernanceCanister`](#nnsgovernancecanister)

***

### NnsGovernanceTestCanister

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:19](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance_test.canister.ts#L19)

#### Methods

##### updateNeuron()

> **updateNeuron**(`neuron`): `Promise`\<\[\] \| \[[`GovernanceError`](namespaces/NnsGovernanceTestDid.md#governanceerror)\]\>

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:51](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance_test.canister.ts#L51)

Test method to update fields of a neuron.

Only available in the governance test canister.

###### Parameters

###### neuron

[`Neuron`](#neuron)

###### Returns

`Promise`\<\[\] \| \[[`GovernanceError`](namespaces/NnsGovernanceTestDid.md#governanceerror)\]\>

##### create()

> `static` **create**(`options`): [`NnsGovernanceTestCanister`](#nnsgovernancetestcanister)

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:28](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/governance_test.canister.ts#L28)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/NnsGovernanceTestDid.md#_service)\> = `{}`

###### Returns

[`NnsGovernanceTestCanister`](#nnsgovernancetestcanister)

***

### SnsWasmCanister

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/sns_wasm.canister.ts#L10)

#### Methods

##### listSnses()

> **listSnses**(`__namedParameters`): `Promise`\<[`DeployedSns`](namespaces/SnsWasmDid.md#deployedsns)[]\>

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/sns_wasm.canister.ts#L29)

###### Parameters

###### \_\_namedParameters

###### certified?

`boolean` = `true`

###### Returns

`Promise`\<[`DeployedSns`](namespaces/SnsWasmDid.md#deployedsns)[]\>

##### create()

> `static` **create**(`options`): [`SnsWasmCanister`](#snswasmcanister)

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/sns_wasm.canister.ts#L16)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/SnsWasmDid.md#_service)\> = `{}`

###### Returns

[`SnsWasmCanister`](#snswasmcanister)

***

### `abstract` StakeNeuronError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:3](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L3)

#### Extends

- `Error`

#### Extended by

- [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)
- [`InsufficientAmountError`](#insufficientamounterror)

#### Constructors

##### Constructor

> **new StakeNeuronError**(`message?`): [`StakeNeuronError`](#stakeneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`StakeNeuronError`](#stakeneuronerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new StakeNeuronError**(`message?`, `options?`): [`StakeNeuronError`](#stakeneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`StakeNeuronError`](#stakeneuronerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### UnrecognizedTypeError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:13](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L13)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnrecognizedTypeError**(`message?`): [`UnrecognizedTypeError`](#unrecognizedtypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`UnrecognizedTypeError`](#unrecognizedtypeerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new UnrecognizedTypeError**(`message?`, `options?`): [`UnrecognizedTypeError`](#unrecognizedtypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`UnrecognizedTypeError`](#unrecognizedtypeerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### UnsupportedValueError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:23](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L23)

An error used to ensure at compile-time that it's never reached.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnsupportedValueError**(`value`): [`UnsupportedValueError`](#unsupportedvalueerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:24](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/errors/governance.errors.ts#L24)

###### Parameters

###### value

`never`

###### Returns

[`UnsupportedValueError`](#unsupportedvalueerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

## Interfaces

### Account

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:189](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L189)

#### Properties

##### owner

> **owner**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:190](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L190)

##### subaccount

> **subaccount**: [`Option`](#option)\<`number`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:191](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L191)

***

### AddHotKey

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:73](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L73)

#### Properties

##### newHotKey

> **newHotKey**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:74](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L74)

***

### AddHotKeyRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:628](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L628)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:629](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L629)

##### principal

> **principal**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:630](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L630)

***

### AddOrRemoveNodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:76](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L76)

#### Properties

##### change

> **change**: [`Option`](#option)\<[`Change`](#change-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:77](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L77)

***

### ApproveGenesisKyc

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:79](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L79)

#### Properties

##### principals

> **principals**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:80](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L80)

***

### Ballot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:85](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L85)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:86](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L86)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:87](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L87)

##### votingPower

> **votingPower**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:88](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L88)

***

### BallotInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:90](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L90)

#### Properties

##### proposalId

> **proposalId**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:92](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L92)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:91](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L91)

***

### BlessAlternativeGuestOsVersion

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:347](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L347)

#### Properties

##### baseGuestLaunchMeasurements

> **baseGuestLaunchMeasurements**: [`Option`](#option)\<[`GuestLaunchMeasurements`](#guestlaunchmeasurements)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:350](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L350)

##### chipIds

> **chipIds**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:349](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L349)

##### rootfsHash

> **rootfsHash**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:348](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L348)

***

### CanisterAuthzInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:98](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L98)

#### Properties

##### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](#methodauthzinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:99](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L99)

***

### CanisterSettings

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:313](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L313)

#### Properties

##### computeAllocation

> **computeAllocation**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L320)

##### controllers

> **controllers**: [`Option`](#option)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:315](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L315)

##### freezingThreshold

> **freezingThreshold**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:314](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L314)

##### logVisibility

> **logVisibility**: [`Option`](#option)\<[`LogVisibility`](#logvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:316](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L316)

##### memoryAllocation

> **memoryAllocation**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L319)

##### reservedCyclesLimit

> **reservedCyclesLimit**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:322](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L322)

##### snapshotVisibility

> **snapshotVisibility**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:317](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L317)

##### wasmMemoryLimit

> **wasmMemoryLimit**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:318](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L318)

##### wasmMemoryThreshold

> **wasmMemoryThreshold**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:321](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L321)

***

### CanisterUpgradeOptions

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:289](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L289)

#### Properties

##### skipPreUpgrade

> **skipPreUpgrade**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:290](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L290)

##### wasmMemoryPersistence

> **wasmMemoryPersistence**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:291](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L291)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:223](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L223)

#### Properties

##### requestedSettingForAutoStakeMaturity

> **requestedSettingForAutoStakeMaturity**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:224](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L224)

***

### ClaimNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:598](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L598)

#### Properties

##### dissolveDelayInSecs

> **dissolveDelayInSecs**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:601](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L601)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:600](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L600)

##### publicKey

> **publicKey**: `DerEncodedPublicKey`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:599](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L599)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:102](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L102)

#### Properties

##### by

> **by**: [`Option`](#option)\<[`By`](#by-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:103](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L103)

***

### ClaimOrRefreshNeuronFromAccount

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:105](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L105)

#### Properties

##### controller

> **controller**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:106](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L106)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:107](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L107)

***

### ClaimOrRefreshNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:109](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L109)

#### Properties

##### by

> **by**: [`Option`](#option)\<[`By`](#by-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:111](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L111)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:110](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L110)

***

### Configure

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:145](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L145)

#### Properties

##### operation

> **operation**: [`Option`](#option)\<[`Operation`](#operation-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:146](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L146)

***

### Countries

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:760](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L760)

#### Properties

##### isoCodes

> **isoCodes**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:761](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L761)

***

### CreateCanisterAndInstallCode

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:363](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L363)

#### Properties

##### canisterSettings

> **canisterSettings**: [`Option`](#option)\<[`CanisterSettings`](#canistersettings)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:365](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L365)

##### hostSubnetId

> **hostSubnetId**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L367)

##### installArgHash

> **installArgHash**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:366](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L366)

##### wasmModuleHash

> **wasmModuleHash**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:364](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L364)

***

### CreateServiceNervousSystem

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:846](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L846)

#### Properties

##### dappCanisters

> **dappCanisters**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:854](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L854)

##### description

> **description**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:853](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L853)

##### fallbackControllerPrincipalIds

> **fallbackControllerPrincipalIds**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:849](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L849)

##### governanceParameters

> **governanceParameters**: [`Option`](#option)\<[`GovernanceParameters`](#governanceparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:848](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L848)

##### initialTokenDistribution

> **initialTokenDistribution**: [`Option`](#option)\<[`InitialTokenDistribution`](#initialtokendistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:856](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L856)

##### ledgerParameters

> **ledgerParameters**: [`Option`](#option)\<[`LedgerParameters`](#ledgerparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:852](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L852)

##### logo

> **logo**: [`Option`](#option)\<[`Image`](#image)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:850](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L850)

##### name

> **name**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:851](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L851)

##### swapParameters

> **swapParameters**: [`Option`](#option)\<[`SwapParameters`](#swapparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:855](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L855)

##### url

> **url**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:847](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L847)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:799](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L799)

#### Properties

##### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](#option)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:800](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L800)

***

### Decimal

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:475](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L475)

#### Properties

##### humanReadable

> **humanReadable**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:476](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L476)

***

### DeregisterKnownNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:217](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L217)

#### Properties

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:218](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L218)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:836](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L836)

#### Properties

##### developerNeurons

> **developerNeurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:837](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L837)

***

### Disburse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:152](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L152)

#### Properties

##### amount

> **amount**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:154](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L154)

##### toAccountId

> **toAccountId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:153](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L153)

***

### DisburseMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:193](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L193)

#### Properties

##### percentageToDisburse

> **percentageToDisburse**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:196](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L196)

##### toAccount

> **toAccount**: [`Option`](#option)\<[`Account`](#account)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:194](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L194)

##### toAccountIdentifier

> **toAccountIdentifier**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:195](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L195)

***

### DisburseRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:674](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L674)

#### Properties

##### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:677](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L677)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:675](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L675)

##### toAccountId?

> `optional` **toAccountId**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:676](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L676)

***

### DisburseResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L156)

#### Properties

##### transferBlockHeight

> **transferBlockHeight**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L157)

***

### DisburseToNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:159](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L159)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:162](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L162)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:160](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L160)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:161](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L161)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:163](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L163)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:164](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L164)

***

### DisburseToNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:680](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L680)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:684](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L684)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:682](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L682)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:683](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L683)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:681](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L681)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:685](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L685)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:686](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L686)

***

### Duration

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:752](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L752)

#### Properties

##### seconds

> **seconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:753](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L753)

***

### ExecuteNnsFunction

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:176](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L176)

#### Properties

##### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:177](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L177)

##### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:178](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L178)

***

### Follow

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:180](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L180)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:182](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L182)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:181](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L181)

***

### Followees

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:184](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L184)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:186](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L186)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:185](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L185)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L166)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:168](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L168)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L167)

***

### FollowRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:651](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L651)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:654](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L654)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:652](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L652)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:653](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L653)

***

### FulfillSubnetRentalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:328](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L328)

#### Properties

##### nodeIds

> **nodeIds**: `Principal`[] \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:331](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L331)

##### replicaVersionId

> **replicaVersionId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:330](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L330)

##### user

> **user**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:329](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L329)

***

### GlobalTimeOfDay

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:756](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L756)

#### Properties

##### secondsAfterUtcMidnight

> **secondsAfterUtcMidnight**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:757](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L757)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:876](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L876)

#### Properties

##### communityFundTotalMaturityE8sEquivalent

> **communityFundTotalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:888](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L888)

##### communityFundTotalStakedE8s

> **communityFundTotalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:916](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L916)

##### decliningVotingPowerNeuronSubsetMetrics

> **decliningVotingPowerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:900](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L900)

##### dissolvedNeuronsCount

> **dissolvedNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:887](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L887)

##### dissolvedNeuronsE8s

> **dissolvedNeuronsE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:903](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L903)

##### dissolvingNeuronsCount

> **dissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:913](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L913)

##### dissolvingNeuronsCountBuckets

> **dissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:910](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L910)

##### dissolvingNeuronsE8sBuckets

> **dissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:914](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L914)

##### dissolvingNeuronsE8sBucketsEct

> **dissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:911](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L911)

##### dissolvingNeuronsE8sBucketsSeed

> **dissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:905](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L905)

##### dissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **dissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:881](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L881)

##### dissolvingNeuronsStakedMaturityE8sEquivalentSum

> **dissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:879](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L879)

##### ectNeuronCount

> **ectNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:884](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L884)

##### fullyLostVotingPowerNeuronSubsetMetrics

> **fullyLostVotingPowerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:892](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L892)

##### garbageCollectableNeuronsCount

> **garbageCollectableNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:880](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L880)

##### neuronsFundTotalActiveNeurons

> **neuronsFundTotalActiveNeurons**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:895](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L895)

##### neuronsWithInvalidStakeCount

> **neuronsWithInvalidStakeCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:882](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L882)

##### neuronsWithLessThan6MonthsDissolveDelayCount

> **neuronsWithLessThan6MonthsDissolveDelayCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:886](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L886)

##### neuronsWithLessThan6MonthsDissolveDelayE8s

> **neuronsWithLessThan6MonthsDissolveDelayE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:906](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L906)

##### nonSelfAuthenticatingControllerNeuronSubsetMetrics

> **nonSelfAuthenticatingControllerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:912](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L912)

##### notDissolvingNeuronsCount

> **notDissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:893](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L893)

##### notDissolvingNeuronsCountBuckets

> **notDissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:883](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L883)

##### notDissolvingNeuronsE8sBuckets

> **notDissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:878](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L878)

##### notDissolvingNeuronsE8sBucketsEct

> **notDissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:898](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L898)

##### notDissolvingNeuronsE8sBucketsSeed

> **notDissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:917](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L917)

##### notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:907](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L907)

##### notDissolvingNeuronsStakedMaturityE8sEquivalentSum

> **notDissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:902](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L902)

##### publicNeuronSubsetMetrics

> **publicNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:918](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L918)

##### seedNeuronCount

> **seedNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:920](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L920)

##### spawningNeuronsCount

> **spawningNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:899](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L899)

##### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:919](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L919)

##### totalLockedE8s

> **totalLockedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:894](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L894)

##### totalMaturityDisbursementsInProgressE8sEquivalent

> **totalMaturityDisbursementsInProgressE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:927](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L927)

SDK DIVERGENCE: optional here even though the backend declares the
underlying Candid field as required, so the SDK can decode responses from
canister versions that predate the field (e.g. bundled dfx wasms,
rolling-release mainnet). See the comment on `governance.did`.

##### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:877](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L877)

##### totalStakedE8s

> **totalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:891](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L891)

##### totalStakedE8sEct

> **totalStakedE8sEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:901](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L901)

##### totalStakedE8sNonSelfAuthenticatingController

> **totalStakedE8sNonSelfAuthenticatingController**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:904](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L904)

##### totalStakedE8sSeed

> **totalStakedE8sSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:889](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L889)

##### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:897](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L897)

##### totalStakedMaturityE8sEquivalentEct

> **totalStakedMaturityE8sEquivalentEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:890](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L890)

##### totalStakedMaturityE8sEquivalentSeed

> **totalStakedMaturityE8sEquivalentSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:915](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L915)

##### totalSupplyIcp

> **totalSupplyIcp**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:885](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L885)

##### totalVotingPowerNonSelfAuthenticatingController

> **totalVotingPowerNonSelfAuthenticatingController**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:896](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L896)

***

### GovernanceParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:785](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L785)

#### Properties

##### customProposalCriticality

> **customProposalCriticality**: [`Option`](#option)\<[`CustomProposalCriticality`](#customproposalcriticality)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:796](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L796)

##### neuronMaximumAgeBonus

> **neuronMaximumAgeBonus**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:790](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L790)

##### neuronMaximumAgeForAgeBonus

> **neuronMaximumAgeForAgeBonus**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:787](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L787)

##### neuronMaximumDissolveDelay

> **neuronMaximumDissolveDelay**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:788](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L788)

##### neuronMaximumDissolveDelayBonus

> **neuronMaximumDissolveDelayBonus**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:786](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L786)

##### neuronMinimumDissolveDelayToVote

> **neuronMinimumDissolveDelayToVote**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:789](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L789)

##### neuronMinimumStake

> **neuronMinimumStake**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:791](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L791)

##### proposalInitialVotingPeriod

> **proposalInitialVotingPeriod**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:793](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L793)

##### proposalRejectionFee

> **proposalRejectionFee**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:794](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L794)

##### proposalWaitForQuietDeadlineIncrease

> **proposalWaitForQuietDeadlineIncrease**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:792](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L792)

##### votingRewardParameters

> **votingRewardParameters**: [`Option`](#option)\<[`VotingRewardParameters`](#votingrewardparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:795](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L795)

***

### GuestLaunchMeasurement

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:337](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L337)

#### Properties

##### measurement

> **measurement**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:342](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L342)

SEV-SNP measurement (48 bytes).

##### metadata

> **metadata**: [`Option`](#option)\<[`GuestLaunchMeasurementMetadata`](#guestlaunchmeasurementmetadata-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:338](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L338)

***

### GuestLaunchMeasurementMetadata

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:333](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L333)

#### Properties

##### kernelCmdline

> **kernelCmdline**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L334)

##### vcpuType

> **vcpuType**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L335)

***

### GuestLaunchMeasurements

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:344](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L344)

#### Properties

##### guestLaunchMeasurements

> **guestLaunchMeasurements**: [`Option`](#option)\<[`GuestLaunchMeasurement`](#guestlaunchmeasurement)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:345](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L345)

***

### Image

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:768](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L768)

#### Properties

##### base64Encoding

> **base64Encoding**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:769](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L769)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:207](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L207)

#### Properties

##### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:208](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L208)

***

### IncreaseDissolveDelayRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:646](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L646)

#### Properties

##### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:648](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L648)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:647](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L647)

***

### InitialTokenDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:840](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L840)

#### Properties

##### developerDistribution

> **developerDistribution**: [`Option`](#option)\<[`DeveloperDistribution`](#developerdistribution)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:842](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L842)

##### swapDistribution

> **swapDistribution**: [`Option`](#option)\<[`SwapDistribution`](#swapdistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:843](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L843)

##### treasuryDistribution

> **treasuryDistribution**: [`Option`](#option)\<[`SwapDistribution`](#swapdistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:841](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L841)

***

### InstallCode

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:293](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L293)

#### Properties

##### argHash

> **argHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:294](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L294)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:297](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L297)

##### canisterUpgradeOptions

> **canisterUpgradeOptions**: [`Option`](#option)\<[`CanisterUpgradeOptions`](#canisterupgradeoptions)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:299](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L299)

##### installMode

> **installMode**: [`Option`](#option)\<[`CanisterInstallMode`](#canisterinstallmode)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:298](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L298)

##### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:296](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L296)

##### wasmModuleHash

> **wasmModuleHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:295](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L295)

***

### InstallCodeRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:301](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L301)

#### Properties

##### arg

> **arg**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:302](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L302)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:305](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L305)

##### canisterUpgradeOptions

> **canisterUpgradeOptions**: [`Option`](#option)\<[`CanisterUpgradeOptions`](#canisterupgradeoptions)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:307](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L307)

##### installMode

> **installMode**: [`Option`](#option)\<[`CanisterInstallMode`](#canisterinstallmode)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:306](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L306)

##### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:304](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L304)

##### wasmModule

> **wasmModule**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:303](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L303)

***

### JoinCommunityFundRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:689](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L689)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:690](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L690)

***

### KnownNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:210](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L210)

#### Properties

##### committed\_topics

> **committed\_topics**: [`Option`](#option)\<(\[\] \| \[[`TopicToFollow`](namespaces/NnsGovernanceDid.md#topictofollow)\])[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:215](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L215)

##### description

> **description**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:213](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L213)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:211](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L211)

##### links

> **links**: [`Option`](#option)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:214](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L214)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:212](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L212)

***

### LedgerParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:772](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L772)

#### Properties

##### tokenLogo

> **tokenLogo**: [`Option`](#option)\<[`Image`](#image)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:775](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L775)

##### tokenName

> **tokenName**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:776](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L776)

##### tokenSymbol

> **tokenSymbol**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:774](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L774)

##### transactionFee

> **transactionFee**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:773](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L773)

***

### ListNodeProvidersResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:744](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L744)

#### Properties

##### nodeProviders

> **nodeProviders**: [`NodeProvider`](#nodeprovider-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:745](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L745)

***

### ListProposalsRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:229](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L229)

#### Properties

##### beforeProposal

> **beforeProposal**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:238](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L238)

##### excludeTopic

> **excludeTopic**: [`Topic`](#topic)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:252](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L252)

##### includeAllManageNeuronProposals

> **includeAllManageNeuronProposals**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:257](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L257)

##### includeRewardStatus

> **includeRewardStatus**: [`ProposalRewardStatus`](#proposalrewardstatus)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:246](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L246)

##### includeStatus

> **includeStatus**: [`ProposalStatus`](#proposalstatus)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:262](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L262)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:233](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L233)

##### omitLargeFields?

> `optional` **omitLargeFields**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:268](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L268)

##### returnSelfDescribingAction?

> `optional` **returnSelfDescribingAction**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:271](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L271)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:273](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L273)

#### Properties

##### proposals

> **proposals**: [`ProposalInfo`](#proposalinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:274](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L274)

***

### LoadCanisterSnapshot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:358](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L358)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:359](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L359)

##### snapshotId

> **snapshotId**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:360](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L360)

***

### MakeExecuteNnsFunctionProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:735](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L735)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:736](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L736)

##### nnsFunction

> **nnsFunction**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:740](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L740)

##### payload

> **payload**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:741](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L741)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:738](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L738)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:737](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L737)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:739](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L739)

***

### MakeMotionProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:701](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L701)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:702](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L702)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:706](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L706)

##### text

> **text**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:705](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L705)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:703](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L703)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:704](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L704)

***

### MakeNetworkEconomicsProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:709](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L709)

#### Properties

##### networkEconomics

> **networkEconomics**: [`NetworkEconomics`](#networkeconomics-2)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:714](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L714)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:710](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L710)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:712](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L712)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:711](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L711)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:713](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L713)

***

### MakeProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:693](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L693)

#### Properties

##### action

> **action**: [`ProposalActionRequest`](#proposalactionrequest)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:698](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L698)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:694](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L694)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:697](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L697)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:695](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L695)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:696](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L696)

***

### MakeProposalResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:276](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L276)

#### Properties

##### proposalId

> **proposalId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:277](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L277)

***

### MakeRewardNodeProviderProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:717](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L717)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:723](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L723)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:718](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L718)

##### nodeProvider

> **nodeProvider**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:722](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L722)

##### rewardMode

> **rewardMode**: [`Option`](#option)\<[`RewardMode`](#rewardmode-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:724](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L724)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:720](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L720)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:719](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L719)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:721](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L721)

***

### MakeSetDefaultFolloweesProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:727](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L727)

#### Properties

##### followees

> **followees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:732](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L732)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:728](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L728)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:730](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L730)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:729](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L729)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:731](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L731)

***

### ManageNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:279](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L279)

#### Properties

##### command

> **command**: [`Option`](#option)\<[`Command`](#command-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:281](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L281)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:280](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L280)

##### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](#option)\<[`NeuronIdOrSubaccount`](#neuronidorsubaccount-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:282](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L282)

***

### ManageNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:284](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L284)

#### Properties

##### command

> **command**: [`Option`](#option)\<[`ManageNeuronCommandRequest`](#manageneuroncommandrequest)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:286](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L286)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:285](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L285)

##### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](#option)\<[`NeuronIdOrSubaccount`](#neuronidorsubaccount-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:287](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L287)

***

### MaturityDisbursement

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:199](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L199)

#### Properties

##### accountIdentifierToDisburseTo

> **accountIdentifierToDisburseTo**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:203](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L203)

##### accountToDisburseTo

> **accountToDisburseTo**: [`Option`](#option)\<[`Account`](#account)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:202](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L202)

##### amountE8s

> **amountE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:201](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L201)

##### finalizeDisbursementTimestampSeconds

> **finalizeDisbursementTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:204](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L204)

##### timestampOfDisbursementSeconds

> **timestampOfDisbursementSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:200](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L200)

***

### MaturityModulation

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:455](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L455)

#### Properties

##### currentValuePermyriad

> **currentValuePermyriad**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:456](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L456)

##### updatedAtTimestampSeconds

> **updatedAtTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:457](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L457)

***

### Merge

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:379](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L379)

#### Properties

##### sourceNeuronId

> **sourceNeuronId**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:380](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L380)

***

### MergeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:389](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L389)

#### Properties

##### percentageToMerge

> **percentageToMerge**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:390](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L390)

***

### MergeMaturityRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:392](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L392)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:393](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L393)

##### percentageToMerge

> **percentageToMerge**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:394](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L394)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:396](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L396)

#### Properties

##### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:397](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L397)

##### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:398](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L398)

***

### MergeRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:382](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L382)

#### Properties

##### sourceNeuronId

> **sourceNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:383](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L383)

##### targetNeuronId

> **targetNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:384](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L384)

***

### MethodAuthzChange

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:400](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L400)

#### Properties

##### canister

> **canister**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:403](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L403)

##### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:402](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L402)

##### operation

> **operation**: [`AuthzChangeOp`](#authzchangeop)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:404](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L404)

##### principal

> **principal**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:401](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L401)

***

### MethodAuthzInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:406](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L406)

#### Properties

##### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:407](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L407)

##### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:408](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L408)

***

### Motion

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:410](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L410)

#### Properties

##### motionText

> **motionText**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:411](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L411)

***

### NetworkEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:443](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L443)

#### Properties

##### maximumNodeProviderRewards

> **maximumNodeProviderRewards**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:451](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L451)

##### maxProposalsToKeepPerTopic

> **maxProposalsToKeepPerTopic**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:445](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L445)

##### minimumIcpXdrRate

> **minimumIcpXdrRate**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:450](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L450)

##### neuronManagementFeePerProposal

> **neuronManagementFeePerProposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:446](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L446)

##### neuronMinimumStake

> **neuronMinimumStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:444](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L444)

##### neuronsFundEconomics

> **neuronsFundEconomics**: [`Option`](#option)\<[`NeuronsFundEconomics`](#neuronsfundeconomics-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:452](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L452)

##### neuronSpawnDissolveDelaySeconds

> **neuronSpawnDissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:449](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L449)

##### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:447](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L447)

##### transactionFee

> **transactionFee**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:448](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L448)

##### votingPowerEconomics

> **votingPowerEconomics**: [`Option`](#option)\<[`VotingPowerEconomics`](#votingpowereconomics-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:453](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L453)

***

### Neuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:478](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L478)

#### Properties

##### accountIdentifier

> **accountIdentifier**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:494](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L494)

##### agingSinceTimestampSeconds

> **agingSinceTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:490](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L490)

##### autoStakeMaturity

> **autoStakeMaturity**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:488](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L488)

##### cachedNeuronStake

> **cachedNeuronStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:486](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L486)

##### controller

> **controller**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:482](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L482)

##### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:487](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L487)

##### decidingVotingPower

> **decidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:502](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L502)

##### dissolveState

> **dissolveState**: [`Option`](#option)\<[`DissolveState`](#dissolvestate-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:497](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L497)

##### eightYearGangBonusBaseE8s

> **eightYearGangBonusBaseE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:503](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L503)

##### followees

> **followees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:498](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L498)

##### hotKeys

> **hotKeys**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:493](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L493)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:479](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L479)

##### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:495](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L495)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:484](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L484)

##### maturityDisbursementsInProgress

> **maturityDisbursementsInProgress**: [`Option`](#option)\<[`MaturityDisbursement`](#maturitydisbursement)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:496](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L496)

##### maturityE8sEquivalent

> **maturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:489](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L489)

##### neuronFees

> **neuronFees**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:492](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L492)

##### neuronType

> **neuronType**: [`Option`](#option)\<[`NeuronType`](#neurontype)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:480](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L480)

##### notForProfit

> **notForProfit**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:485](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L485)

##### potentialVotingPower

> **potentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:501](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L501)

##### recentBallots

> **recentBallots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:483](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L483)

##### spawnAtTimesSeconds

> **spawnAtTimesSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:491](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L491)

##### stakedMaturityE8sEquivalent

> **stakedMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:481](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L481)

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:499](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L499)

##### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:500](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L500)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:803](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L803)

#### Properties

##### count

> **count**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:805](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L805)

##### dissolveDelayInterval

> **dissolveDelayInterval**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:804](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L804)

***

### NeuronDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:828](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L828)

#### Properties

##### controller

> **controller**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:829](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L829)

##### dissolveDelay

> **dissolveDelay**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:830](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L830)

##### memo

> **memo**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:831](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L831)

##### stake

> **stake**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:833](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L833)

##### vestingPeriod

> **vestingPeriod**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:832](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L832)

***

### NeuronInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:508](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L508)

#### Properties

##### ageSeconds

> **ageSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:522](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L522)

##### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:513](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L513)

##### decidingVotingPower

> **decidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:519](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L519)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:510](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L510)

##### eightYearGangBonusBaseE8s

> **eightYearGangBonusBaseE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:521](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L521)

##### fullNeuron

> **fullNeuron**: [`Option`](#option)\<[`Neuron`](#neuron)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:523](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L523)

##### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:515](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L515)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:509](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L509)

##### neuronType

> **neuronType**: [`Option`](#option)\<[`NeuronType`](#neurontype)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:512](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L512)

##### potentialVotingPower

> **potentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:520](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L520)

##### recentBallots

> **recentBallots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:511](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L511)

##### retrievedAtTimestampSeconds

> **retrievedAtTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:516](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L516)

##### state

> **state**: [`NeuronState`](#neuronstate)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:514](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L514)

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:524](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L524)

##### votingPower

> **votingPower**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:517](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L517)

##### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:518](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L518)

***

### NeuronsFundEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:464](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L464)

#### Properties

##### maximumIcpXdrRate

> **maximumIcpXdrRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:465](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L465)

##### maxTheoreticalNeuronsFundParticipationAmountXdr

> **maxTheoreticalNeuronsFundParticipationAmountXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:467](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L467)

##### minimumIcpXdrRate

> **minimumIcpXdrRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:468](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L468)

##### neuronsFundMatchedFundingCurveCoefficients

> **neuronsFundMatchedFundingCurveCoefficients**: [`Option`](#option)\<[`NeuronsFundMatchedFundingCurveCoefficients`](#neuronsfundmatchedfundingcurvecoefficients-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:466](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L466)

***

### NeuronsFundMatchedFundingCurveCoefficients

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:470](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L470)

#### Properties

##### contributionThresholdXdr

> **contributionThresholdXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:471](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L471)

##### fullParticipationMilestoneXdr

> **fullParticipationMilestoneXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:473](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L473)

##### oneThirdParticipationMilestoneXdr

> **oneThirdParticipationMilestoneXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:472](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L472)

***

### NeuronSubsetMetrics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:859](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L859)

#### Properties

##### count

> **count**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:864](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L864)

##### countBuckets

> **countBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:873](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L873)

##### decidingVotingPowerBuckets

> **decidingVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:865](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L865)

##### maturityE8sEquivalentBuckets

> **maturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:861](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L861)

##### potentialVotingPowerBuckets

> **potentialVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:872](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L872)

##### stakedE8sBuckets

> **stakedE8sBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:870](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L870)

##### stakedMaturityE8sEquivalentBuckets

> **stakedMaturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:869](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L869)

##### totalDecidingVotingPower

> **totalDecidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:868](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L868)

##### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:860](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L860)

##### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:867](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L867)

##### totalStakedE8s

> **totalStakedE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:863](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L863)

##### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:866](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L866)

##### totalVotingPower

> **totalVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:871](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L871)

##### votingPowerBuckets

> **votingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:862](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L862)

***

### NnsGovernanceCanisterOptions

Defined in: [packages/canisters/src/nns/types/governance.options.ts:5](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance.options.ts#L5)

#### Extends

- `CanisterOptions`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

`CanisterOptions.agent`

##### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: packages/utils/dist/types/canister.options.d.ts:5

###### Inherited from

`CanisterOptions.canisterId`

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`CanisterOptions.certifiedServiceOverride`

##### hardwareWallet?

> `optional` **hardwareWallet**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance.options.ts:8](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance.options.ts#L8)

##### oldListNeuronsServiceOverride?

> `optional` **oldListNeuronsServiceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: [packages/canisters/src/nns/types/governance.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance.options.ts#L9)

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`CanisterOptions.serviceOverride`

***

### NodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:527](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L527)

#### Properties

##### id

> **id**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:528](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L528)

##### rewardAccount

> **rewardAccount**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:529](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L529)

***

### OpenSnsTokenSwap

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:413](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L413)

#### Properties

##### communityFundInvestmentE8s

> **communityFundInvestmentE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:414](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L414)

##### params

> **params**: [`Option`](#option)\<\{ `maxDirectParticipationIcpE8s`: [`Option`](#option)\<`bigint`\>; `maxIcpE8s`: `bigint`; `maxParticipantIcpE8s`: `bigint`; `minDirectParticipationIcpE8s`: [`Option`](#option)\<`bigint`\>; `minIcpE8s`: `bigint`; `minParticipantIcpE8s`: `bigint`; `minParticipants`: `number`; `neuronBasketConstructionParameters`: [`Option`](#option)\<\{ `count`: `bigint`; `dissolve_delay_interval_seconds`: `bigint`; \}\>; `saleDelaySeconds`: [`Option`](#option)\<`bigint`\>; `snsTokenE8s`: `bigint`; `swapDueTimestampSeconds`: `bigint`; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:416](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L416)

##### targetSwapCanisterId

> **targetSwapCanisterId**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:415](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L415)

***

### Percentage

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:748](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L748)

#### Properties

##### basisPoints

> **basisPoints**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:749](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L749)

***

### Proposal

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:549](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L549)

#### Properties

##### action

> **action**: [`Option`](#option)\<[`Action`](#action-3)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:552](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L552)

##### selfDescribingAction

> **selfDescribingAction**: [`Option`](#option)\<[`SelfDescribingProposalAction`](#selfdescribingproposalaction)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:554](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L554)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:553](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L553)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:550](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L550)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:551](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L551)

***

### ProposalInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:558](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L558)

#### Properties

##### ballots

> **ballots**: [`Ballot`](#ballot)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:560](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L560)

##### deadlineTimestampSeconds

> **deadlineTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:566](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L566)

##### decidedTimestampSeconds

> **decidedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:565](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L565)

##### executedTimestampSeconds

> **executedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:570](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L570)

##### failedTimestampSeconds

> **failedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:564](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L564)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:559](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L559)

##### latestTally

> **latestTally**: [`Option`](#option)\<[`Tally`](#tally)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:567](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L567)

##### proposal

> **proposal**: [`Option`](#option)\<[`Proposal`](#proposal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:568](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L568)

##### proposalTimestampSeconds

> **proposalTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:562](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L562)

##### proposer

> **proposer**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:569](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L569)

##### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:561](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L561)

##### rewardEventRound

> **rewardEventRound**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:563](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L563)

##### rewardStatus

> **rewardStatus**: [`ProposalRewardStatus`](#proposalrewardstatus)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:573](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L573)

##### status

> **status**: [`ProposalStatus`](#proposalstatus)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:572](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L572)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:571](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L571)

##### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:574](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L574)

***

### RefreshVotingPower

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:149](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L149)

***

### RegisterVote

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:577](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L577)

#### Properties

##### proposal

> **proposal**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:579](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L579)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:578](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L578)

***

### RegisterVoteRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:657](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L657)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:658](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L658)

##### proposal

> **proposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:660](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L660)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:659](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L659)

***

### RemoveHotKey

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:581](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L581)

#### Properties

##### hotKeyToRemove

> **hotKeyToRemove**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:582](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L582)

***

### RemoveHotKeyRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:633](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L633)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:634](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L634)

##### principal

> **principal**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:635](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L635)

***

### RewardNodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:604](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L604)

#### Properties

##### amountE8s

> **amountE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:607](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L607)

##### nodeProvider

> **nodeProvider**: [`Option`](#option)\<[`NodeProvider`](#nodeprovider-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:605](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L605)

##### rewardMode

> **rewardMode**: [`Option`](#option)\<[`RewardMode`](#rewardmode-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:606](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L606)

***

### RewardNodeProviders

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:587](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L587)

#### Properties

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:589](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L589)

##### useRegistryDerivedRewards

> **useRegistryDerivedRewards**: `boolean` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:588](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L588)

***

### RewardToAccount

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:591](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L591)

#### Properties

##### toAccount

> **toAccount**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:592](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L592)

***

### RewardToNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:594](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L594)

#### Properties

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:595](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L595)

***

### SelfDescribingProposalAction

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:543](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L543)

#### Properties

##### typeDescription

> **typeDescription**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:544](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L544)

##### typeName

> **typeName**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:545](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L545)

##### value

> **value**: [`Option`](#option)\<[`SelfDescribingValue`](namespaces/NnsGovernanceDid.md#selfdescribingvalue)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:546](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L546)

***

### SetDefaultFollowees

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:609](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L609)

#### Properties

##### defaultFollowees

> **defaultFollowees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:610](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L610)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:220](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L220)

#### Properties

##### dissolveTimestampSeconds

> **dissolveTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:221](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L221)

***

### SetFollowing

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:170](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L170)

#### Properties

##### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:171](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L171)

***

### SetSnsTokenSwapOpenTimeWindow

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:434](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L434)

#### Properties

##### request

> **request**: [`Option`](#option)\<\{ `openTimeWindow`: [`Option`](#option)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:435](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L435)

##### swapCanisterId

> **swapCanisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:441](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L441)

***

### SetVisibility

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:226](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L226)

#### Properties

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:227](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L227)

***

### Spawn

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:612](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L612)

#### Properties

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:613](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L613)

##### percentageToSpawn

> **percentageToSpawn**: `number` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:614](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L614)

***

### SpawnRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:663](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L663)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:664](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L664)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:665](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L665)

##### percentageToSpawn?

> `optional` **percentageToSpawn**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:666](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L666)

***

### Split

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:617](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L617)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:618](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L618)

##### memo

> **memo**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:619](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L619)

***

### SplitRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:669](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L669)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:671](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L671)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:670](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L670)

***

### StakeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:386](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L386)

#### Properties

##### percentageToStake

> **percentageToStake**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:387](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L387)

***

### StartDissolvingRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:638](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L638)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:639](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L639)

***

### StopDissolvingRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:642](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L642)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:643](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L643)

***

### StopOrStartCanister

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:309](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L309)

#### Properties

##### action

> **action**: [`Option`](#option)\<[`CanisterAction`](#canisteraction)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:311](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L311)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:310](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L310)

***

### SwapDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:824](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L824)

#### Properties

##### total

> **total**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:825](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L825)

***

### SwapParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:807](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L807)

#### Properties

##### confirmationText

> **confirmationText**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:811](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L811)

##### duration

> **duration**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:809](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L809)

##### maxDirectParticipationIcp

> **maxDirectParticipationIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:819](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L819)

##### maximumIcp

> **maximumIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:817](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L817)

##### maximumParticipantIcp

> **maximumParticipantIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:812](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L812)

##### minDirectParticipationIcp

> **minDirectParticipationIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:820](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L820)

##### minimumIcp

> **minimumIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:814](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L814)

##### minimumParticipantIcp

> **minimumParticipantIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:815](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L815)

##### minimumParticipants

> **minimumParticipants**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:808](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L808)

##### neuronBasketConstructionParameters

> **neuronBasketConstructionParameters**: [`Option`](#option)\<[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:810](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L810)

##### neuronsFundInvestmentIcp

> **neuronsFundInvestmentIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:813](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L813)

##### neuronsFundParticipation

> **neuronsFundParticipation**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:821](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L821)

##### restrictedCountries

> **restrictedCountries**: [`Option`](#option)\<[`Countries`](#countries)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:818](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L818)

##### startTime

> **startTime**: [`Option`](#option)\<[`GlobalTimeOfDay`](#globaltimeofday)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:816](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L816)

***

### TakeCanisterSnapshot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:353](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L353)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:355](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L355)

##### replaceSnapshot

> **replaceSnapshot**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:354](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L354)

***

### Tally

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:621](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L621)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:622](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L622)

##### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:625](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L625)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:624](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L624)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:623](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L623)

***

### Tokens

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L764)

#### Properties

##### e8s

> **e8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:765](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L765)

***

### UpdateCanisterSettings

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:324](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L324)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:325](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L325)

##### settings

> **settings**: [`Option`](#option)\<[`CanisterSettings`](#canistersettings)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:326](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L326)

***

### UpdateStandardEngineReplicaVersion

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:373](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L373)

Changes what replica version(s) are run by Cloud Engines.

#### Properties

##### deploymentProgress

> **deploymentProgress**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:376](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L376)

##### newReplicaVersionId

> **newReplicaVersionId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L374)

##### oldReplicaVersionId

> **oldReplicaVersionId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:375](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L375)

***

### VotingPowerEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:459](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L459)

#### Properties

##### clearFollowingAfterSeconds

> **clearFollowingAfterSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:462](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L462)

##### neuronMinimumDissolveDelayToVoteSeconds

> **neuronMinimumDissolveDelayToVoteSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:461](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L461)

##### startReducingVotingPowerAfterSeconds

> **startReducingVotingPowerAfterSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:460](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L460)

***

### VotingRewardParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:779](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L779)

#### Properties

##### finalRewardRate

> **finalRewardRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:782](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L782)

##### initialRewardRate

> **initialRewardRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:781](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L781)

##### rewardRateTransitionDuration

> **rewardRateTransitionDuration**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:780](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L780)

## Type Aliases

### Action

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ManageNeuron`: [`ManageNeuron`](#manageneuron); \} \| \{ `InstallCode`: [`InstallCode`](#installcode); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](#approvegenesiskyc); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics-2); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](#setdefaultfollowees); \} \| \{ `Motion`: [`Motion`](#motion); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](#setsnstokenswapopentimewindow); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](#opensnstokenswap); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCode`](#createcanisterandinstallcode); \} \| \{ `UpdateStandardEngineReplicaVersion`: [`UpdateStandardEngineReplicaVersion`](#updatestandardenginereplicaversion); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:25](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L25)

***

### AuthzChangeOp

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:82](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L82)

***

### By

> **By** = \{ `NeuronIdOrSubaccount`: `Record`\<`string`, `never`\>; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount-2); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:94](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L94)

***

### CanisterIdString

> **CanisterIdString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L1)

***

### Change

> **Change** = \{ `ToRemove`: [`NodeProvider`](#nodeprovider-1); \} \| \{ `ToAdd`: [`NodeProvider`](#nodeprovider-1); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L101)

***

### Command

> **Command** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote-2); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing-2); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity-2); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity-2); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `Disburse`: [`Disburse`](#disburse-2); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower-2); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:113](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L113)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:173](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L173)

***

### E8s

> **E8s** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L3)

***

### ManageNeuronCommandRequest

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote-2); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing-2); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity-2); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity-2); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](#makeproposalrequest); \} \| \{ `Disburse`: [`Disburse`](#disburse-2); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:130](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L130)

***

### Memo

> **Memo** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:4](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L4)

***

### NeuronId

> **NeuronId** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L2)

***

### NeuronIdOrSubaccount

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `number`[]; \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-23); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:505](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L505)

***

### Operation

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](#removehotkey-2); \} \| \{ `AddHotKey`: [`AddHotKey`](#addhotkey-2); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay-2); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `SetVisibility`: [`SetVisibility`](#setvisibility-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:531](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L531)

***

### Option

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/canisters/src/nns/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L7)

#### Type Parameters

##### T

`T`

***

### PrincipalString

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/common.ts#L5)

***

### ProposalActionRequest

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](#manageneuronrequest); \} \| \{ `InstallCode`: [`InstallCodeRequest`](#installcoderequest); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](#approvegenesiskyc); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics-2); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:53](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L53)

***

### ProposalId

> **ProposalId** = `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:556](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L556)

***

### RewardMode

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](#rewardtoneuron); \} \| \{ `RewardToAccount`: [`RewardToAccount`](#rewardtoaccount); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:584](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/governance_converters.ts#L584)

***

### SnsWasmCanisterOptions

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](namespaces/SnsWasmDid.md#_service)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)

## Functions

### accountIdentifierFromBytes()

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/account_identifier.utils.ts#L19)

#### Parameters

##### accountIdentifier

`Uint8Array`

#### Returns

`string`

***

### accountIdentifierToBytes()

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/account_identifier.utils.ts#L15)

#### Parameters

##### accountIdentifier

`string`

#### Returns

`Uint8Array`

***

### ineligibleNeurons()

> **ineligibleNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:37](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/neurons.utils.ts#L37)

Filter the neurons that are ineligible to vote to a proposal.

This feature needs the ballots of the proposal to contains accurate data.
If the proposal has settled, as the ballots of the proposal are emptied for archive purpose, the function might return a list of ineligible neurons that are actually neurons that have not voted but would have been eligible.

Long story short, check the status of the proposal before using this function.

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal to match against the selected neurons.

#### Returns

[`NeuronInfo`](#neuroninfo)[]

***

### memoToNeuronAccountIdentifier()

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../ledger/icp/index.md#accountidentifier)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

#### Parameters

##### \_\_namedParameters

###### controller

`Principal`

###### governanceCanisterId

`Principal`

###### memo

`bigint`

#### Returns

[`AccountIdentifier`](../ledger/icp/index.md#accountidentifier)

***

### memoToNeuronSubaccount()

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../ledger/icp/index.md#subaccount)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

#### Parameters

##### \_\_namedParameters

###### controller

`Principal`

###### memo

`bigint`

#### Returns

[`SubAccount`](../ledger/icp/index.md#subaccount)

***

### principalToAccountIdentifier()

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

#### Parameters

##### principal

`Principal`

##### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

#### Returns

`string`

***

### votableNeurons()

> **votableNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:66](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/neurons.utils.ts#L66)

Filter the neurons that can vote for a proposal - i.e. the neurons that have not voted yet and are eligible

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal to match against the selected neurons.

#### Returns

[`NeuronInfo`](#neuroninfo)[]

***

### votedNeurons()

> **votedNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/844e6a6ccb95d4576c483186a9404f3abfce12c3/packages/canisters/src/nns/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal for which some neurons might have already voted.

#### Returns

[`NeuronInfo`](#neuroninfo)[]
